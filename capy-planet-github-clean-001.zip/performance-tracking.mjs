// Camera ownership follows actual playback state, not the currently selected tab.
// Ambient looping inhabitants do not block tracking forever. Explicit previews do.
export function performanceReasons({experiment,cast,flight,satellite,fable,runner,spider,mage,weather,marine,observer,stages=[],guides,ray,heroCloseup=false,marineFollow=false}){
 const reasons=[],add=(busy,label)=>{if(busy)reasons.push(label)};
 add(experiment?.active||cast?.active,'實驗演出');
 add(stages.some(stage=>stage?.releasing),'演出收尾');
 add(guides?.clockEnabled||ray?.group.visible,'時鐘與光路觀察');
 add(observer?.enabled,'地表觀測');
 add(flight?.launchActive,'火箭發射與回收');
 add(flight?.voyage!==null&&flight?.voyage!==undefined&&flight.voyage<1,'太空船往返');
 add(flight?.spacewalk?.performanceActive,'太空人出艙');
 add(flight?.returnBroadcastNormal,'衛星轉播收尾');
 const sim=satellite?.sim;
 add(sim?.syncRemaining>0,'衛星校時');
 // Includes the coast between the two impulses. Do not test flame visibility.
 add(sim?.burnRemaining>0,'衛星升軌');
 add(sim?.rescueRemaining>0,'超拉救援');
 add(sim?.crashed&&sim.crashAge<3,'衛星墜落收尾');
 add(heroCloseup||fable?.performanceActive,'卡皮英雄表演');
 add(runner?.performanceActive,'電俠歲月重逢');
 add(spider?.performanceActive,'卡皮蜘豬維修');
 add(mage?.performanceActive,'奇異巴拉出訪表演');
 add(weather?.performanceActive,'林果山降雪');
 add(marine?.foreheadStorm?.performanceActive,'潮汐衛星風暴');
 add(marine?.whirlpool?.performanceActive,'海上旋渦表演');
 add(marineFollow,'航船跟拍');
 return reasons;
}

export class PerformanceTrackingGuard{
 constructor(settleSeconds=1.5){this.settleSeconds=settleSeconds;this.remaining=0;this.reasons=[];this.suspended=false}
 update(reasons,dt=0){
  this.reasons=[...new Set(reasons)];
  if(this.reasons.length)this.remaining=this.settleSeconds;
  else this.remaining=Math.max(0,this.remaining-Math.max(0,dt));
  this.suspended=this.reasons.length>0||this.remaining>1e-8;
  this.reason=this.reasons.length?this.reasons.join('、'):this.suspended?'等待鏡頭收尾':'';
  return this.suspended;
 }
}
