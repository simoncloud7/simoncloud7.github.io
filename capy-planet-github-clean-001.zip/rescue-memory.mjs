const clamp=x=>Math.max(0,Math.min(1,x));
const smooth=(a,b,x)=>{const t=clamp((x-a)/(b-a));return t*t*(3-2*t)};
// This is a recording's playhead, never the present scene's clock.
export function rescueMemoryState(elapsed){
 const history=1-smooth(2,15,elapsed),fall=smooth(.43,.61,history);
 return {history,fall,ufoX:4.8-13.5*history,ufoY:1.55+.6*(1-smooth(.10,.35,history))+2*smooth(.57,.95,history),ufoOpacity:smooth(.02,.08,history)*(1-smooth(.85,.97,history)),impact:history>.41&&history<.49,opacity:1-smooth(16.5,20,elapsed),memorialOpacity:smooth(17,18.5,elapsed),finished:elapsed>=20,caption:elapsed<2?'過去影像 · 小芭在 UFO 碰撞後倒下':elapsed<15?'倒放 UFO 碰撞的回憶 · 不是時間倒流':elapsed<17?'影像中的小芭站起來了':'倒放結束，紀念像仍在；小芭沒有復生。'};
}
