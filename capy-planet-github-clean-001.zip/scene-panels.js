import {FloatingPanels,LEGACY_PANELS} from './floating-panels.mjs?v=996321243fec';
import {deviceViewport} from './device-viewport.mjs?v=996321243fec';
const KEY='planet-scene-panels-v2';
export function showScenePanel(key){document.dispatchEvent(new CustomEvent('scene-panel-toggle',{detail:{key,collapsed:false}}))}

export class ScenePanels{
 constructor(){
  this.entries=new Map();this.preferences={};try{const saved=JSON.parse(sessionStorage.getItem(KEY)||'{}');if(saved&&typeof saved==='object'&&!Array.isArray(saved))this.preferences=saved}catch{}
  const configs=[];
  for(const spec of [{key:'controls',selector:'#controls-dock',label:'實驗',title:'實驗與場景設定',edge:'right',tabY:.26},{key:'navigation',selector:'nav[aria-label="宇宙視角"]',label:'主選單',title:'景點與主選單',edge:'bottom',tabY:1},{key:'identity',selector:'.intro.scene-intro',label:'卡皮星',title:'標題與操作說明',edge:'left',tabY:.12}]){
   const panel=document.querySelector(spec.selector);if(!panel)continue;if(!panel.id)panel.id='scene-'+spec.key;
   panel.classList.add('scene-panel','scene-panel-'+spec.key);
   const content=document.createElement('div');content.className='scene-panel-content';while(panel.firstChild)content.append(panel.firstChild);panel.append(content);
   const bar=document.createElement('div');bar.className='scene-panel-bar';const title=document.createElement('span');title.textContent=spec.title;bar.append(title);
   const close=document.createElement('button');close.type='button';close.dataset.panelCollapse=spec.key;close.textContent='×';close.setAttribute('aria-label','將'+spec.label+'收成標籤');bar.append(close);panel.prepend(bar);
   const tab=document.createElement('div');tab.id='scene-tab-'+spec.key;tab.className='scene-panel-tab scene-tab-'+spec.key;tab.dataset.edge=spec.edge;tab.hidden=true;tab.inert=document.body.dataset.ready!=='true';
   const open=document.createElement('button');open.type='button';open.textContent=spec.label;open.setAttribute('aria-controls',panel.id);open.setAttribute('aria-expanded','false');open.setAttribute('aria-label','展開'+spec.label);tab.append(open);document.body.append(tab);
   const entry={...spec,panel,bar,content,tab,open};this.entries.set(spec.key,entry);close.onclick=()=>this.collapse(spec.key,true);open.onclick=()=>this.collapse(spec.key,false);
   configs.push({key:'scene-'+spec.key,selector:'#'+panel.id,handle:':scope > .scene-panel-bar',label:spec.label},{key:'tab-'+spec.key,selector:'#'+tab.id,handle:':scope',label:spec.label+'標籤',noReset:true,dockEdge:spec.edge,dockY:spec.tabY});
  }
  this.floating=new FloatingPanels({configs:[...LEGACY_PANELS,...configs]});
  for(const entry of this.entries.values()){
   entry.float=this.floating.entries.find(e=>e.key==='scene-'+entry.key);entry.tabFloat=this.floating.entries.find(e=>e.key==='tab-'+entry.key);
  }
  document.addEventListener('scene-panel-toggle',event=>{if(this.entries.has(event.detail?.key))this.collapse(event.detail.key,!!event.detail.collapsed)});
  this.readyObserver=new MutationObserver(()=>{if(document.body.dataset.ready==='true'){for(const e of this.entries.values())e.tab.inert=false;this.readyObserver.disconnect()}});if(document.body.dataset.ready!=='true')this.readyObserver.observe(document.body,{attributes:true,attributeFilter:['data-ready']});
  document.querySelectorAll('.nav-category').forEach(menu=>menu.addEventListener('toggle',()=>{if(menu.open)this.fitMenu(menu)}));
  document.addEventListener('floating-panels-layout',()=>{for(const menu of document.querySelectorAll('.nav-category[open]'))this.fitMenu(menu)});
  document.addEventListener('scene-viewport-change',()=>this.reflow());this.reflow();
  this.report();
 }
 reflow(){
  const view=deviceViewport(),mode=view.width<view.height?'portrait':'landscape';document.body.dataset.sceneLayout=mode;
  // Apply defaults and migrate old orientation-specific choices only once.
  // A resize must preserve the current panel and open submenu state.
  if(!this.layoutMode){
   const nav=this.entries.get('navigation'),navHeight=nav?.panel.getBoundingClientRect().height||0,shared={};
   for(const [key] of this.entries){
    const preferred=[this.preferences.shared?.[key],this.preferences[mode]?.[key],this.preferences[mode==='portrait'?'landscape':'portrait']?.[key]].find(value=>typeof value==='boolean');
    const collapsed=typeof preferred==='boolean'?preferred:key==='identity'&&(mode==='portrait'||view.width<290+390+view.width*.3)||key==='navigation'&&navHeight>view.height*.23;
    shared[key]=collapsed;this.collapse(key,collapsed,{initial:true});
   }
   this.preferences.shared=shared;this.savePreferences();
  }
  this.layoutMode=mode;
  this.floating.schedule();
 }
 collapse(key,collapsed,{initial=false}={}){
  const e=this.entries.get(key);if(!e||e.panel.hidden===collapsed)return;const view=deviceViewport();
  if(collapsed){for(const menu of e.panel.querySelectorAll('.nav-category[open]'))menu.open=false;e.panel.hidden=true;e.tab.hidden=false;this.floating.place(e.tabFloat,this.floating.positions[e.tabFloat.key]||{x:e.edge==='bottom'?(view.width-e.tab.getBoundingClientRect().width)/2:0,y:view.height*e.tabY,edge:e.edge},true)}
  else{e.tab.hidden=true;e.panel.hidden=false;const position=this.floating.positions[e.float.key];if(position)this.floating.place(e.float,position,true);else this.floating.reset(e.float);if(!initial)e.bar.focus({preventScroll:true})}
  e.open.setAttribute('aria-expanded',String(!collapsed));this.floating.schedule();this.floating.save();
  if(!initial){this.preferences.shared??={};this.preferences.shared[key]=collapsed;this.savePreferences()}
  this.report();
 }
 savePreferences(){try{sessionStorage.setItem(KEY,JSON.stringify(this.preferences))}catch{}}
 fitMenu(menu){
  const popup=menu.querySelector('.nav-menu-list');if(!popup)return;popup.style.marginLeft='';menu.classList.remove('opens-down');const view=deviceViewport();
  const anchor=menu.getBoundingClientRect(),above=anchor.top-view.top-24,below=view.top+view.height-anchor.bottom-24;if(below>above)menu.classList.add('opens-down');popup.style.maxHeight=Math.max(44,Math.max(above,below))+'px';const r=popup.getBoundingClientRect(),shift=r.left<view.left+12?view.left+12-r.left:r.right>view.left+view.width-12?view.left+view.width-12-r.right:0;popup.style.marginLeft=shift+'px';
 }
 report(){document.body.dataset.scenePanels=JSON.stringify(Object.fromEntries([...this.entries].map(([key,e])=>[key,{collapsed:e.panel.hidden,panel:e.panel.id,tab:e.tab.id}])))}
}
