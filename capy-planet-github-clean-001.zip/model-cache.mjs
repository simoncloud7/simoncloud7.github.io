const DB_NAME='capy-models-v1',STORE='models';

// Binary bytes survive page reloads. Parsed scenes and GPU resources do not.
export class ModelStore{
 constructor({indexedDB=globalThis.indexedDB,timeout=1800}={}){this.api=indexedDB;this.timeout=timeout}
 open(){
  if(this.connection)return this.connection;
  this.connection=new Promise((resolve,reject)=>{
   if(!this.api){reject(Error('Browser storage unavailable'));return}
   const timer=setTimeout(()=>reject(Error('Browser storage timed out')),this.timeout);let request;
   try{request=this.api.open(DB_NAME,1)}catch(error){clearTimeout(timer);reject(error);return}
   request.onupgradeneeded=()=>{if(!request.result.objectStoreNames.contains(STORE))request.result.createObjectStore(STORE)};
   request.onsuccess=()=>{clearTimeout(timer);request.result.onversionchange=()=>request.result.close();resolve(request.result)};request.onerror=()=>{clearTimeout(timer);reject(request.error)};
  });return this.connection;
 }
 async transact(mode,operate){
  const db=await this.open();return new Promise((resolve,reject)=>{const transaction=db.transaction(STORE,mode),request=operate(transaction.objectStore(STORE)),timer=setTimeout(()=>{try{transaction.abort()}catch{}reject(Error('Browser storage timed out'))},this.timeout);let value;
   request.onsuccess=()=>{value=request.result};transaction.oncomplete=()=>{clearTimeout(timer);resolve(value)};transaction.onerror=transaction.onabort=()=>{clearTimeout(timer);reject(transaction.error||Error('Browser storage failed'))};
  });
 }
 get(key){return this.transact('readonly',store=>store.get(key))}
 put(key,bytes){return this.transact('readwrite',store=>store.put(bytes,key))}
 delete(key){return this.transact('readwrite',store=>store.delete(key))}
}

export class ModelCache{
 constructor({store=new ModelStore(),fetcher=(...args)=>fetch(...args),report=()=>{}}={}){Object.assign(this,{store,fetcher,report});this.pending=new Map();this.stats={hits:0,downloads:0,stored:0,bytesReused:0,bytesRead:0,storageAvailable:true}}
 publish(){this.report({...this.stats})}
 key(url,item){return /^[a-f0-9]{64}$/i.test(item?.sha256||'')?'sha256:'+item.sha256.toLowerCase():null}
 async bytes(url,item,{refresh=false}={}){
  const key=this.key(url,item),requestKey=key||url;
  if(!refresh&&this.pending.has(requestKey))return this.pending.get(requestKey);
  const task=(async()=>{
   if(key&&!refresh&&this.stats.storageAvailable){try{const bytes=await this.store.get(key);if(bytes instanceof ArrayBuffer&&bytes.byteLength){this.stats.hits++;this.stats.bytesReused+=bytes.byteLength;this.publish();return {bytes,source:'cache',key}}}catch{this.stats.storageAvailable=false;this.publish()}}
   const response=await this.fetcher(url,{cache:refresh?'reload':'default'});if(!response.ok)throw Error('Model '+response.status+': '+url);const bytes=await response.arrayBuffer();this.stats.downloads++;this.stats.bytesRead+=bytes.byteLength;
   if(key&&this.stats.storageAvailable){try{await this.store.put(key,bytes);this.stats.stored++}catch{this.stats.storageAvailable=false}}
   this.publish();return {bytes,source:'origin',key};
  })();this.pending.set(requestKey,task);try{return await task}finally{if(this.pending.get(requestKey)===task)this.pending.delete(requestKey)}
 }
 async evict(key){if(key)try{await this.store.delete(key)}catch{}}
}

export const modelCache=new ModelCache({report:stats=>{if(globalThis.document?.body)document.body.dataset.modelCache=JSON.stringify(stats)}});
export async function loadCachedModel(loader,url,item,cache=modelCache){
 const resourcePath=url.slice(0,url.lastIndexOf('/')+1),record=await cache.bytes(url,item);
 try{return await loader.parseAsync(record.bytes,resourcePath)}catch(error){
  if(record.source!=='cache')throw error;await cache.evict(record.key);const fresh=await cache.bytes(url,item,{refresh:true});return loader.parseAsync(fresh.bytes,resourcePath);
 }
}
