import * as THREE from 'three';
import {exteriorCamera} from './exterior-camera.mjs?v=093e498326f7';
export class CameraSurfaceGuard{
 constructor({camera,controls,canvas,bodies}){Object.assign(this,{camera,controls,bodies});this.previous=null;this.zoomUntil=0;this.ray=new THREE.Raycaster();this.samples=new Map();canvas.addEventListener('wheel',()=>this.zoomUntil=performance.now()+180,{capture:true,passive:true})}
 reset(){this.previous=null;this.zoomUntil=0;this.samples.clear()}
 update(enabled=true){if(!enabled){this.reset();return null}const before=this.camera.position.clone();let position=before.toArray(),blocked=false,clearance=Infinity;
  for(const body of this.bodies()){
   const center=body.center,dir=new THREE.Vector3(...position).sub(center).normalize();let radius=body.radius;const meshes=body.surfaces||[];
   if(meshes.length){let sample=this.samples.get(body.key),now=performance.now();if(!sample||now-sample.time>100||sample.direction.angleTo(dir)>.004){this.ray.set(center.clone().addScaledVector(dir,100),dir.clone().negate());const hit=this.ray.intersectObjects(meshes,true)[0];sample={time:now,direction:dir.clone(),radius:hit?Math.max(radius,hit.point.distanceTo(center)):radius};this.samples.set(body.key,sample)}radius=sample.radius}
   const margin=.45,limit=radius+margin,distance=new THREE.Vector3(...position).distanceTo(center),sweep=performance.now()<this.zoomUntil||distance<limit;
   const result=exteriorCamera(this.previous?.toArray(),position,center.toArray(),limit,sweep);position=result.position;blocked||=result.blocked;clearance=Math.min(clearance,new THREE.Vector3(...position).distanceTo(center)-radius);
  }
  this.camera.position.fromArray(position);if(blocked)this.camera.lookAt(this.controls.target);this.previous=this.camera.position.clone();return {position,blocked,minimumSurfaceClearance:clearance};
 }
}
