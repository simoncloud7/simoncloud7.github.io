import * as THREE from 'three';
import {spiderFrame} from './spider-ground.js?v=f28a8f8b7fad';

const Y=new THREE.Vector3(0,1,0),Z=new THREE.Vector3(0,0,1);
const smooth=x=>{x=THREE.MathUtils.clamp(x,0,1);return x*x*(3-2*x)};

// Idle poses attach to existing architecture. They never own a camera or feed.
export class SpiderStandby{
 constructor({globe,actor,rig,silk,anchorSites=[],random=Math.random}){
  Object.assign(this,{globe,actor,rig,silk,random});this.time=0;this.kind=null;this.applied=false;
  this.body=actor.getObjectByName('twin-body-pivot');this.head=actor.getObjectByName('head-pivot');
  this.limbs=[-1,1].flatMap(side=>['arm','leg'].map(type=>{const node=actor.getObjectByName(type+'-'+side);return {node,type,side,position:node.position.clone(),quaternion:node.quaternion.clone(),geometry:node.geometry,bent:type==='leg'?node.geometry.clone():null}}));
  this.bodyPosition=this.body.position.clone();this.headQ=this.head.quaternion.clone();
  const museum=anchorSites.find(site=>site.root.getObjectByName('portico-roof-11'));
  const site=museum||anchorSites.find(site=>site.root.getObjectByName('main-building-0'));
  if(!site)return;
  this.site=site;this.building=site.root.getObjectByName('building-0')||site.root.getObjectByName('main-building-0');
  this.canopy=site.root.getObjectByName('portico-roof-11')||site.root.getObjectByName('flat-roof-1');
  this.available=!!(this.building&&this.canopy);if(!this.available)return;
  this.building.geometry.computeBoundingBox();this.canopy.geometry.computeBoundingBox();
  this.plan();this.grips=new THREE.InstancedMesh(new THREE.CylinderGeometry(.055,.055,.012,12),new THREE.MeshStandardMaterial({color:0x477f79,roughness:.55,metalness:.35}),8);this.grips.name='spider-wall-grip-pads';this.grips.visible=false;globe.add(this.grips);
 }
 plan(){
  this.globe.updateWorldMatrix(true,true);const inverse=this.globe.matrixWorld.clone().invert(),wallMatrix=inverse.clone().multiply(this.building.matrixWorld),roofMatrix=inverse.clone().multiply(this.canopy.matrixWorld),box=this.building.geometry.boundingBox,roof=this.canopy.geometry.boundingBox;
  const up=Y.clone().transformDirection(wallMatrix),out=new THREE.Vector3(1,0,0).transformDirection(wallMatrix),street=Z.clone().transformDirection(wallMatrix),anchor=new THREE.Vector3((roof.min.x+roof.max.x)/2,roof.min.y,(roof.min.z+roof.max.z)/2).applyMatrix4(roofMatrix);
  this.hang={anchor,up,front:street,q:spiderFrame(up.clone().negate(),street),position:anchor.clone().addScaledVector(up,-.30)};
  const wallScale=new THREE.Vector3().setFromMatrixScale(wallMatrix),point=new THREE.Vector3(box.max.x,box.min.y,box.max.z-.85/wallScale.z).applyMatrix4(wallMatrix).addScaledVector(up,.80);
  this.wall={point,normal:out,up,q:spiderFrame(up,out.clone().negate()),position:point.clone().addScaledVector(out,.50),gap:.50};
 }
 choose(kind){
  if(!this.available)return null;this.restore();this.kind=kind==='hang'||kind==='wall'?kind:(this.random()<.5?'hang':'wall');this.time=0;this.pose(0);return this.kind;
 }
 restore(){
  if(!this.applied)return;for(const limb of this.limbs){limb.node.position.copy(limb.position);limb.node.quaternion.copy(limb.quaternion);limb.node.geometry=limb.geometry}this.body.position.copy(this.bodyPosition);this.body.quaternion.identity();this.head.quaternion.copy(this.headQ);this.grips.visible=false;this.applied=false;this.wallReady=false;
 }
 place(point,q){
  this.globe.updateWorldMatrix(true,false);this.actor.parent.updateWorldMatrix(true,false);const globeQ=this.globe.getWorldQuaternion(new THREE.Quaternion()),parentQ=this.actor.parent.getWorldQuaternion(new THREE.Quaternion());this.actor.quaternion.copy(parentQ.invert().multiply(globeQ).multiply(q));this.actor.position.copy(this.actor.parent.worldToLocal(this.globe.localToWorld(point.clone())));this.actor.updateWorldMatrix(true,true);
 }
 bendLeg(limb,angle){
  const source=limb.geometry.attributes.position,target=limb.bent.attributes.position,p=new THREE.Vector3(),pivot=new THREE.Vector3(0,-.27,0),rotation=new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1,0,0),angle);
  for(let i=0;i<source.count;i++){p.fromBufferAttribute(source,i);const weight=smooth((-.24-p.y)/.10),bent=p.clone().sub(pivot).applyQuaternion(rotation).add(pivot);p.lerp(bent,weight);target.setXYZ(i,p.x,p.y,p.z)}target.needsUpdate=true;limb.bent.computeVertexNormals();limb.bent.computeBoundingBox();limb.bent.computeBoundingSphere();limb.node.geometry=limb.bent;
 }
 wallLimb(limb){
  const node=limb.node,vertices=node.geometry.attributes.position,desired=this.wall.gap/this.actor.scale.x,z=limb.side*(limb.type==='arm'?.30:.48),preference=limb.side>0?-2.05:-1.05;
  let best=null;const extent=angle=>{const s=Math.sin(angle),c=Math.cos(angle),sz=Math.sin(z),cz=Math.cos(z);let max=-Infinity;for(let i=0;i<vertices.count;i++)max=Math.max(max,(vertices.getX(i)*sz+vertices.getY(i)*cz)*s+vertices.getZ(i)*c);return max+limb.position.z};
  const range=limb.side>0?[-2.7,-Math.PI/2]:[-Math.PI/2,-.2];
  for(let i=0;i<=320;i++){const angle=THREE.MathUtils.lerp(...range,i/320),value=extent(angle),score=Math.abs(value-desired)+.0005*Math.abs(angle-preference);if(!best||score<best.score)best={angle,value,score}}
  node.rotation.set(best.angle,0,z);node.position.z=limb.position.z+desired-best.value;
 }
 applyPose(){
  this.body.position.copy(this.bodyPosition);this.body.quaternion.identity();
  for(const limb of this.limbs){limb.node.position.copy(limb.position);if(limb.type==='leg')this.bendLeg(limb,this.kind==='hang'?2.30:limb.side>0?.20:-.65);if(this.kind==='hang'){if(limb.type==='arm')limb.node.position.z+=.22;limb.node.rotation.set(limb.type==='leg'?-.55:-.40,0,limb.side*(limb.type==='leg'?1.05:-.65))}else this.wallLimb(limb)}
  this.applied=true;this.wallReady=false;
 }
 pose(time){
  if(!this.available||!this.kind)return;this.time=time;if(!this.applied)this.applyPose();
  if(this.kind==='hang'){
   const h=this.hang,q=h.q.clone().multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(0,.035*Math.sin(time*.43),.025*Math.sin(time*.65))));this.place(h.position,q);this.head.rotation.set(.025*Math.sin(time*.8),0,0);
   const target=this.globe.localToWorld(h.anchor.clone()),targets=Array.from({length:8},()=>target.clone()),active=Array(8).fill(false);active[3]=active[7]=true;this.rig.pose(time,{deploy:.38,targets:targets.map((p,i)=>active[i]?p:null)});this.silk.group.visible=true;this.silk.update(this.rig.emitters(),targets,1,time,{active,taut:true,pulse:false});this.targets=targets;this.phase='蜘豬倒吊待命';
  }else{
   const wall=this.wall;this.place(wall.position,wall.q);this.head.rotation.set(0,1.48+.025*Math.sin(time*.55),.025*Math.sin(time*.8));
   if(!this.wallReady){
    this.rig.pose(0,{deploy:1});const origins=this.rig.emitters(),bodyOrigin=this.actor.getWorldPosition(new THREE.Vector3()),right=new THREE.Vector3(1,0,0).transformDirection(this.actor.matrixWorld),normal=wall.normal.clone().transformDirection(this.globe.matrixWorld),plane=this.globe.localToWorld(wall.point.clone());
    wall.contacts=origins.map(p=>{const relative=p.clone().sub(bodyOrigin);p=p.clone().addScaledVector(right,-.20*relative.dot(right));p.addScaledVector(normal,-p.clone().sub(plane).dot(normal)+.015);return this.globe.worldToLocal(p)});
    const contacts=wall.contacts.map(p=>this.globe.localToWorld(p.clone()));this.rig.pose(0,{deploy:1,contacts,contactNormal:normal.negate()});wall.contacts.forEach((p,i)=>this.grips.setMatrixAt(i,new THREE.Matrix4().compose(p,new THREE.Quaternion().setFromUnitVectors(Y,wall.normal),new THREE.Vector3(1,1,1))));this.grips.instanceMatrix.needsUpdate=true;this.grips.computeBoundingSphere();this.grips.visible=true;this.wallReady=true;
   }
   this.silk.group.visible=false;this.targets=this.rig.emitters();this.phase='蜘豬貼牆待命';
  }
 }
 cameraPose(aspect=1.8){
  const p=this.kind==='hang'?this.hang:this.wall,up=p.up.clone().transformDirection(this.globe.matrixWorld),target=this.actor.getWorldPosition(new THREE.Vector3()).addScaledVector(up,this.kind==='hang'?-.85:.85),front=(this.kind==='hang'?p.front:p.normal).clone().transformDirection(this.globe.matrixWorld),side=(this.kind==='hang'?new THREE.Vector3().crossVectors(p.up,p.front):this.hang.front).clone().transformDirection(this.globe.matrixWorld),direction=front.multiplyScalar(this.kind==='hang'?1:.85).addScaledVector(side,this.kind==='hang'?.35:1.1).addScaledVector(up,.18).normalize();
  return {target,position:target.clone().addScaledVector(direction,aspect<1?7:5.5),up};
 }
}
