import {C,lorentz} from './relativity.mjs?v=cf9ebfe6af50';
export const LIGHT_DEMO_SECONDS=24,LOCAL_TIME_SCALE=8e-8/24,REST_ROD_LENGTH=10,LIGHT_RACE_DISTANCE=18,LIGHT_FREEZE_FRAME=19.6;
const clamp=x=>Math.max(0,Math.min(1,x)),smooth=x=>{const t=clamp(x);return t*t*(3-2*t)};
export function lightSpaceState(seconds,beta){const time=((Math.max(0,seconds)%LIGHT_DEMO_SECONDS))*LOCAL_TIME_SCALE;return {time,beta,lightA:2+C*time,lightB:2+C*time,emitter:2+beta*C*time,restLength:REST_ROD_LENGTH,movingLength:REST_ROD_LENGTH/lorentz(beta),lightSpeed:C,displayTimeScale:LOCAL_TIME_SCALE}}
export function lightPerformanceState(seconds,beta=.8){
 const speed=beta*C*LOCAL_TIME_SCALE/LIGHT_RACE_DISTANCE,reached=Math.min(1,speed*(LIGHT_DEMO_SECONDS-1e-6)),returnDuration=speed>0?reached/speed:0,returnStart=4+LIGHT_DEMO_SECONDS,returnEnd=returnStart+returnDuration,performanceSeconds=returnEnd+9,phaseTime=Math.max(0,seconds)%performanceSeconds;
 const prepare=phaseTime<4,measure=phaseTime>=4&&phaseTime<returnStart,returning=phaseTime>=returnStart&&phaseTime<returnEnd,review=phaseTime>=returnEnd,t=prepare?0:Math.min(LIGHT_DEMO_SECONDS-1e-6,phaseTime-4),physics=lightSpaceState(t,beta);
 const routeProgress=prepare||review?0:returning?Math.max(0,reached-speed*(phaseTime-returnStart)):Math.min(1,speed*Math.max(0,phaseTime-4));
 return {phaseTime,prepare,measure,returning,review,phase:prepare?'prepare':measure?'measure':returning?'return':'review',routeProgress,reached,returnStart,returnEnd,returnDuration,performanceSeconds,physics,progress:phaseTime/performanceSeconds};
}
export const LIGHT_PERFORMANCE_SECONDS=lightPerformanceState(0,.8).performanceSeconds;
export function advanceHeroTime(seconds,dt,beta,rate=1){
 let time=Math.max(0,seconds),remaining=Math.max(0,dt);rate=Math.max(1,Math.min(4,rate));
 while(remaining>1e-9){const state=lightPerformanceState(time,beta),scale=state.prepare||state.review?1:rate,boundary=state.prepare?4:state.measure?state.returnStart:state.returning?state.returnEnd:state.performanceSeconds,distance=boundary-state.phaseTime,step=Math.min(remaining,Math.max(1e-9,distance/scale));time+=step*scale;remaining-=step}
 return time;
}
export function heroMotionProfile(seconds,beta){
 const state=lightPerformanceState(seconds,beta),travelProgress=state.returning?state.reached-state.routeProgress:state.measure?state.routeProgress:0,legProgress=state.reached>0?clamp(travelProgress/state.reached):0,moving=state.measure&&state.routeProgress<1||state.returning;
 const gait=moving?smooth(legProgress/.04)*smooth((1-legProgress)/.04):0,afterimageStrength=moving?smooth(legProgress/.08)*smooth((1-legProgress)/.08)*smooth((beta-.2)/.3):0;
 return {travelProgress,legProgress,gait,afterimageStrength,worldFrozen:beta>=.8&&moving&&legProgress>=.08&&legProgress<=.92};
}
export function lightRaceState(seconds,beta){
 const state=lightPerformanceState(seconds,beta),distance=C*state.physics.time;
 return {runnerProgress:state.routeProgress,lightProgress:Math.min(1,distance/LIGHT_RACE_DISTANCE),runnerArrived:state.measure&&state.routeProgress>=1,lightArrived:state.measure&&distance>=LIGHT_RACE_DISTANCE,afterimageStrength:heroMotionProfile(seconds,beta).afterimageStrength};
}
export function rulerTrailStrength(seconds,beta){return heroMotionProfile(seconds,beta).afterimageStrength}
export function lightCameraBlend(seconds,beta=.8){
 const state=lightPerformanceState(seconds,beta),t=state.phaseTime;
 if(t<4)return 0;if(t<7)return smooth((t-4)/3);if(t<state.returnEnd-4)return 1;if(t<state.returnEnd)return 1-smooth((t-state.returnEnd+4)/4);return 0;
}
