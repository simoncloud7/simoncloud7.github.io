import {C} from './relativity.mjs?v=521635992d4b';
export const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
export const normalize=a=>{const l=Math.hypot(...a);return a.map(v=>v/l)};
export const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
export function tideHeight(normal,moonDirection,amplitude=.12){const d=dot(normalize(normal),normalize(moonDirection));return amplitude*(1.5*d*d-.5)}
export function shipClockLag(speedMps,seconds=86400){if(!Number.isFinite(speedMps)||Math.abs(speedMps)>=C||seconds<0)throw RangeError('Sublight speed and nonnegative duration required');const b2=(speedMps/C)**2;return seconds*b2/(1+Math.sqrt(1-b2))}
export function currentVector(n,strength=1){const a=cross([0,1,0],n),b=cross([0,0,1],n),lon=Math.atan2(n[0],n[1]);return a.map((v,i)=>strength*(v*(.8+.2*Math.sin(n[2]*5))+.22*Math.sin(lon*3)*b[i]))}
export function routeTable(points,radius=18){const lengths=[0];for(let i=1;i<points.length;i++)lengths.push(lengths.at(-1)+radius*Math.acos(Math.max(-1,Math.min(1,dot(points[i-1],points[i])))));return {points,lengths,total:lengths.at(-1)}}
export function routePosition(route,distance){const d=((distance%route.total)+route.total)%route.total;let lo=0,hi=route.lengths.length-1;while(lo+1<hi){const m=(lo+hi)>>1;if(route.lengths[m]<=d)lo=m;else hi=m}const t=(d-route.lengths[lo])/(route.lengths[hi]-route.lengths[lo]),a=route.points[lo],b=route.points[hi],normal=normalize(a.map((v,i)=>v+(b[i]-v)*t)),raw=b.map((v,i)=>v-a[i]),tangent=normalize(raw.map((v,i)=>v-dot(raw,normal)*normal[i]));return {normal,tangent}}
// Conservative body envelopes: medium sailboat ~3.2 scene units, rowboat ~1.4.
export function safeAdvance(route,distance,step,others,clearance=6.5){const before=routePosition(route,distance).normal,arc=(a,b)=>18*Math.acos(Math.max(-1,Math.min(1,dot(a,b))));let factor=1;for(const other of others){const d=arc(before,other),after=routePosition(route,distance+step).normal;if(arc(after,other)<d){factor=Math.min(factor,Math.max(0,Math.min(1,(d-clearance)/2.5)))}}const candidate=routePosition(route,distance+step*factor).normal;if(others.some(n=>arc(candidate,n)<clearance&&arc(candidate,n)<arc(before,n)))return 0;return factor}
export function fleetPose(route,index,time){const period=160,offset=index===0?0:97.5,dockSeconds=index===0?9:13,t=((time+offset)%period+period)%period,docked=t<dockSeconds,progress=docked?0:(t-dockSeconds)/(period-dockSeconds);return {...routePosition(route,route.total*progress),docked,progress,dockRemaining:docked?dockSeconds-t:0,laps:Math.floor((time+offset)/period)}}
export function marineNavigationStep(route,time,step,row,{dt=step,stalled=false,hold=false,state={}}={}){
 const nextState={waiting:state.waiting||0,retreat:state.retreat||0,cooldown:Math.max(0,(state.cooldown||0)-dt)};
 if(hold||dt===0||step===0)return {time,state:nextState,yielding:hold,reversing:false};
 if(nextState.retreat>0){const amount=Math.min(nextState.retreat,step*1.25),next=time-amount,p=fleetPose(route,0,next);if(seaDistance(p.normal,row)>=6.6){nextState.retreat-=amount;if(nextState.retreat<1e-8)nextState.cooldown=2;return {time:next,state:nextState,yielding:false,reversing:true}}nextState.retreat=0;nextState.cooldown=2}
 if(nextState.cooldown>0)return {time,state:nextState,yielding:true,reversing:false};
 const before=fleetPose(route,0,time),next=fleetPose(route,0,time+step),yielding=seaDistance(next.normal,row)<6.6&&seaDistance(next.normal,row)<seaDistance(before.normal,row);
 nextState.waiting=yielding&&stalled?nextState.waiting+dt:0;
 if(nextState.waiting>=2){nextState.waiting=0;nextState.retreat=Math.min(4/(route.total/151),Math.max(0,time-(Math.floor(time/160)*160+9)))}
 return {time:yielding?time:time+step,state:nextState,yielding,reversing:false};
}
export const seaDistance=(a,b)=>18*Math.acos(Math.max(-1,Math.min(1,dot(a,b))));
// An open-water starting point outside the crewed ship lane, rather than a second scheduled berth.
export const DRIFT_START=Object.freeze([.3420201433256688,0,-.9396926207859083]);
const mapSea=(x,z)=>[Math.sin(x/18)*Math.cos(z/18),Math.cos(x/18)*Math.cos(z/18),Math.sin(z/18)];
export const HARBOR_SAFE_RADIUS=8.5,DRIFT_DISPLAY_SCALE=.018;
export function pierDistance(n){
 const along=Math.atan2(n[2],n[0]*Math.sin(-2/18)+n[1]*Math.cos(-2/18))*18;
 return seaDistance(n,mapSea(-2,Math.max(13,Math.min(24.25,along))));
}
export const inProtectedHarbor=n=>pierDistance(n)<HARBOR_SAFE_RADIUS;
const inPolygon=(x,z,outline)=>{let inside=false;for(let i=0;i<outline.length;i++){const [ax,az]=outline[i],[bx,bz]=outline[(i+outline.length-1)%outline.length];if((az>z)!==(bz>z)&&x<(bx-ax)*(z-az)/(bz-az)+ax)inside=!inside}return inside};
export function seaClear(n,outline,{landScale=1.14,otherLandScale=.72,pierClearance=4.8,platformClearance=3.6,launchClearance=5}={}){
 for(const [axis,a,scale] of [['z',0,landScale],['z',-2.5,otherLandScale],['x',-2.35,otherLandScale]]){
  const [x,y,z]=n,c=Math.cos(a),s=Math.sin(a),p=axis==='z'?[x*c-y*s,x*s+y*c,z]:[x,y*c-z*s,y*s+z*c];
  if(inPolygon(Math.atan2(p[0],p[1])*18/scale,Math.asin(Math.max(-1,Math.min(1,p[2])))*18/scale,outline))return false;
 }
 const site=mapSea(16,11);if(seaDistance(n,site)<launchClearance)return false;
 if(dot(n,site)>.6){const east=[Math.cos(16/18),-Math.sin(16/18),0],south=[-Math.sin(16/18)*Math.sin(11/18),-Math.cos(16/18)*Math.sin(11/18),Math.cos(11/18)],x=18*dot(n,east),z=18*dot(n,south);if(Math.hypot(Math.max(-8.3-x,0,x-3.3),Math.max(-2.75-z,0,z-2.75))<platformClearance)return false}
 return pierDistance(n)>=pierClearance;
}
export const rowboatSeaClear=(n,outline)=>seaClear(n,outline,{landScale:1.09,otherLandScale:.67,pierClearance:2,platformClearance:1.4,launchClearance:3});
export function buildHarborOutflow(start,isWater){
 const along=Math.atan2(start[2],start[0]*Math.sin(-2/18)+start[1]*Math.cos(-2/18))*18;
 const pier=mapSea(-2,Math.max(13,Math.min(24.25,along))),away=normalize(start.map((v,i)=>v*dot(start,pier)-pier[i])),side=normalize(cross(start,away));
 for(const angle of [0,.2,-.2,.4,-.4,.7,-.7,1,-1]){
  const direction=away.map((v,i)=>v*Math.cos(angle)+side[i]*Math.sin(angle)),points=[];
  for(let d=0;d<=14.001;d+=.25)points.push(normalize(start.map((v,i)=>v*Math.cos(d/18)+direction[i]*Math.sin(d/18))));
  if(points.every(isWater)&&pierDistance(points.at(-1))>14)return routeTable(points);
 }
 throw Error('No water-only harbor outflow corridor');
}
export function passiveDrift(normal,dt,strength,{isWater=()=>true,others=[],clearance=6.6,flowAt=currentVector}={}){
 if(!Number.isFinite(dt)||dt<0||!Number.isFinite(strength)||strength<0)throw RangeError('Nonnegative drift step and strength required');
 const rawFlow=flowAt(normal,strength),deflected=!!rawFlow.coastalDeflection,vesselDeflected=!!rawFlow.vesselDeflection;
 let flow=rawFlow.map(v=>v*.85),speed=Math.hypot(...flow);
 if(dt===0||speed<1e-12)return {normal:[...normal],flow,speed:dt===0?0:speed,blocked:false,deflected,vesselDeflected};
 const advance=v=>normalize(normal.map((x,i)=>x+v[i]*dt*DRIFT_DISPLAY_SCALE));
 let next=advance(flow),sliding=false;
 const contacts=others.filter(other=>seaDistance(next,other)<clearance&&seaDistance(next,other)<seaDistance(normal,other));
 if(isWater(next)&&contacts.length){
  const slide=[...flow];
  for(const other of contacts){const toward=normalize(other.map((v,i)=>v-dot(other,normal)*normal[i])),inward=Math.max(0,dot(slide,toward));for(let i=0;i<3;i++)slide[i]-=toward[i]*inward}
  const candidate=advance(slide);
  if(Math.hypot(...slide)>1e-7&&isWater(candidate)&&!others.some(other=>seaDistance(candidate,other)<clearance&&seaDistance(candidate,other)<seaDistance(normal,other))){flow=slide;speed=Math.hypot(...slide);next=candidate;sliding=true}
 }
 const blocked=!isWater(next)||others.some(other=>seaDistance(next,other)<clearance&&seaDistance(next,other)<seaDistance(normal,other));
 return {normal:blocked?[...normal]:next,flow,speed:blocked?0:speed,blocked,deflected,vesselDeflected,sliding,blockedBy:blocked?(!isWater(next)?'shore':'vessel'):null};
}
