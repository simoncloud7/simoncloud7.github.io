import {gravityRate} from './relativity.mjs?v=68b46a776e0d';
import {PLANET_KM,REBOOST_SECONDS,SYNC_SECONDS,REENTRY_STORY_KM,HERO_CALL_STORY_KM,HERO_APPROACH_SECONDS,HERO_RESCUE_SECONDS,inwardDecay,reboostPlan,reboostPose} from './satellite-orbit-story.mjs?v=68b46a776e0d';

// Nominal circular timelike Schwarzschild orbit, compared with a static surface
// clock. k = rs/R, rho = r/R. This does not infer speed from the display orbit.
export function satelliteClockModel(k,rho){
 const ground=gravityRate(k);if(!Number.isFinite(rho)||rho<=1)throw RangeError('Orbit outside the surface required');
 const stable=k>0&&rho>3*k;
 if(!stable)return {stable:false,ground,innermostStableRadius:3*k,reason:k===0?'零質量沒有自由圓軌道':'此高度不在穩定自由圓軌道區域'};
 const localBeta=Math.sqrt(k/(2*(rho-k))),gravitational=gravityRate(k/rho)/ground,motion=Math.sqrt(1-localBeta**2),satellite=Math.sqrt(1-1.5*k/rho);
 return {stable:true,ground,innermostStableRadius:3*k,satellite,localBeta,gravitational,motion,ratio:satellite/ground};
}

export class SatelliteOperations{
 constructor(){this.reset()}
 reset(){this.ground=0;this.raw=0;this.output=0;this.frequencyCorrection=1;this.calibrated=false;this.syncRemaining=0;this.burnRemaining=0;this.radialKm=0;this.crossKm=0;this.syncs=0;this.burns=0;this.displayTime=0;this.oscillatorBias=2e-6;this.parameterKey=null;this.decayAge=0;this.crashed=false;this.crashAge=0;this.burnSerial=0;this.transfer=null;this.burnEndedThisStep=false;this.thrusterFailed=false;this.transferAgent='engine';this.rescueRemaining=0;this.rescueTime=0;this.rescues=0;this.rescueSerial=0;this.rescueDemo=false;this.rescueTransferStarted=false;this.rescueTransferDone=false}
 requestSync(){if(this.model?.stable&&!this.crashed&&!this.syncRemaining){this.syncRemaining=SYNC_SECONDS;return true}return false}
 requestBurn(){if(this.altitudeKm<REENTRY_STORY_KM)this.thrusterFailed=true;if(this.model?.stable&&!this.crashed&&!this.thrusterFailed&&!this.rescueRemaining&&!this.burnRemaining&&this.radialKm< -1e-6){this.burnRemaining=REBOOST_SECONDS;this.transferAgent='engine';this.transfer=reboostPlan(this.rho+this.radialKm/PLANET_KM,this.rho);this.burnSerial++;return true}return false}
 get altitudeKm(){return Math.max(0,(this.rho-1)*PLANET_KM+this.radialKm)}
 get rescueInRange(){return this.radialKm< -1e-6&&this.altitudeKm>0&&(this.altitudeKm<=HERO_CALL_STORY_KM+1e-6||this.thrusterFailed)}
 requestRescue({demo=false}={}){
  if(!this.model?.stable||this.crashed||this.burnRemaining||this.rescueRemaining)return false;
  if(demo){const altitude=Math.min(180,this.altitudeKm);this.radialKm=altitude-(this.rho-1)*PLANET_KM;this.thrusterFailed=true;this.decayAge=30*Math.log1p(-this.radialKm/(.085*30))}
  if(this.altitudeKm<REENTRY_STORY_KM)this.thrusterFailed=true;
  if(!this.rescueInRange)return false;
  this.rescueRemaining=HERO_RESCUE_SECONDS;this.rescueTime=0;this.rescueSerial++;this.rescueDemo=demo;this.rescueTransferStarted=false;this.rescueTransferDone=false;return true;
 }
 update(displayDt,coordinateDt,k,rho,{automatic=true,disturbances=true,orbitPaused=false}={}){
  if(displayDt<0||coordinateDt<0||!Number.isFinite(displayDt+coordinateDt))throw RangeError('Forward time required');
  const key=k+':'+rho;if(key!==this.parameterKey){this.reset();this.parameterKey=key}
  this.rho=rho;this.model=satelliteClockModel(k,rho);this.displayTime+=displayDt;this.burnEndedThisStep=false;
  // A static surface clock remains defined even when this module cannot model
  // a stable satellite orbit. Unavailable satellite values are not zero readings.
  this.ground+=coordinateDt*this.model.ground;
  if(this.crashed){this.rescueRemaining=this.burnRemaining=0;this.crashAge+=displayDt;return this.state()}
  if(!this.model.stable){this.syncRemaining=this.burnRemaining=this.rescueRemaining=0;this.radialKm=this.crossKm=0;return this.state()}
  this.oscillatorBias=2e-6+.2e-6*Math.sin(this.displayTime/30);
  const m=this.model,rawRate=m.satellite*(1+this.oscillatorBias);
  this.raw+=coordinateDt*rawRate;this.output+=coordinateDt*rawRate*this.frequencyCorrection;
  if(this.syncRemaining){this.syncRemaining=Math.max(0,this.syncRemaining-displayDt);if(!this.syncRemaining){this.frequencyCorrection=m.ground/rawRate;this.output=this.ground;this.calibrated=true;this.syncs++}}
  // Hero broadcasting and the accelerated orbital-maintenance story are
  // separate presentations. Preserve a pending transfer while clocks run on.
  if(!orbitPaused){
   if(this.rescueRemaining&&displayDt>0){
    // Approach is a slowed cinematic beat. The ordinary orbital story is held;
    // the independent reference clocks above continue advancing.
    this.rescueTime=Math.min(HERO_RESCUE_SECONDS,this.rescueTime+displayDt);this.rescueRemaining=Math.max(0,HERO_RESCUE_SECONDS-this.rescueTime);if(this.rescueRemaining<1e-9)this.rescueRemaining=0;
    if(this.rescueTime>=HERO_APPROACH_SECONDS&&!this.rescueTransferStarted){this.transfer=reboostPlan(rho+this.radialKm/PLANET_KM,rho);this.transferAgent='hero';this.burnSerial++;this.rescueTransferStarted=true}
    if(this.rescueTransferStarted&&!this.rescueTransferDone){const age=Math.min(REBOOST_SECONDS,this.rescueTime-HERO_APPROACH_SECONDS),p=reboostPose(this.transfer,age);this.burnRemaining=REBOOST_SECONDS-age;this.radialKm=(p.radius-rho)*PLANET_KM;if(age>=REBOOST_SECONDS-1e-9){this.burnRemaining=0;this.radialKm=0;this.decayAge=0;this.thrusterFailed=false;this.rescues++;this.rescueTransferDone=true;this.burnEndedThisStep=true}}
   }
   else if(this.burnRemaining&&displayDt>0){this.burnRemaining=Math.max(0,this.burnRemaining-displayDt);if(this.burnRemaining<1e-9)this.burnRemaining=0;const p=reboostPose(this.transfer,REBOOST_SECONDS-this.burnRemaining);this.radialKm=(p.radius-rho)*PLANET_KM;if(!this.burnRemaining){this.radialKm=0;this.decayAge=0;this.burns++;this.burnEndedThisStep=true}}
   else if(disturbances&&displayDt>0){const fall=inwardDecay(-this.radialKm,this.decayAge,displayDt,rho);this.decayAge=fall.age;this.radialKm=-fall.lossKm;if(fall.crashed){this.crashed=true;this.crashAge=0;this.syncRemaining=0;this.burnRemaining=0}}
  }
  if(!this.rescueRemaining&&!this.burnRemaining&&this.altitudeKm<REENTRY_STORY_KM)this.thrusterFailed=true;
  const size=-this.radialKm;if(automatic&&displayDt>0&&!this.crashed){if(Math.abs(this.output-this.ground)>100e-6&&!this.syncRemaining)this.requestSync();if(!orbitPaused&&size>6&&!this.burnRemaining&&!this.rescueRemaining&&!this.thrusterFailed)this.requestBurn()}
  return this.state();
 }
 state(){const available=!!this.model?.stable&&!this.crashed,transfer=this.transfer&&(this.burnRemaining>0||this.burnEndedThisStep)?{...reboostPose(this.transfer,REBOOST_SECONDS-this.burnRemaining),agent:this.transferAgent}:null,rescueActive=this.rescueRemaining>0,rescueInRange=available&&this.rescueInRange;return {model:this.model,available,ground:this.ground,raw:this.raw,output:this.output,rawOffset:available?this.raw-this.ground:null,outputOffset:available?this.output-this.ground:null,frequencyCorrection:this.frequencyCorrection,calibrated:this.calibrated,syncRemaining:this.syncRemaining,burnRemaining:this.burnRemaining,burnSerial:this.burnSerial,transfer,radialKm:this.radialKm,crossKm:0,errorKm:available?-this.radialKm:null,altitudeKm:this.altitudeKm,crashed:this.crashed,crashAge:this.crashAge,decayAge:this.decayAge,syncs:this.syncs,burns:this.burns,oscillatorBias:this.oscillatorBias,thrusterFailed:this.thrusterFailed,rescueCallAltitudeKm:HERO_CALL_STORY_KM,rescueInRange,rescueAvailable:rescueInRange&&!rescueActive&&!this.burnRemaining,rescueActive,rescueRemaining:this.rescueRemaining,rescueTime:this.rescueTime,rescueSerial:this.rescueSerial,rescueDemo:this.rescueDemo,rescues:this.rescues,rescuePhase:rescueActive?(this.rescueTime<HERO_APPROACH_SECONDS?'approach':this.rescueTransferDone?'depart':transfer?.phase||'boost'):null}}
}
