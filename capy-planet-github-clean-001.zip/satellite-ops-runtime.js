import * as THREE from 'three';
import {SatelliteOperations} from './satellite-ops.mjs?v=2f222a9f157d';
import {PLANET_KM,REENTRY_STORY_KM,HERO_APPROACH_SECONDS,HERO_DEPART_SECONDS,REBOOST_SECONDS} from './satellite-orbit-story.mjs?v=2f222a9f157d';
import {createSatellitePropulsion} from './satellite-propulsion.js?v=2f222a9f157d';
import {SatelliteHeroRescue} from './satellite-hero-rescue.js?v=2f222a9f157d';
const $=s=>document.querySelector(s),up=new THREE.Vector3(0,1,0),signedUs=s=>(s>=0?'+':'−')+(Math.abs(s)<.1?(Math.abs(s)*1e6).toFixed(2)+' μs':Math.abs(s).toFixed(5)+' s');
export class SatelliteOperationsView{
 constructor({orbiter,globe,fable,onRadius,onResume,onAction=()=>{}}){
  Object.assign(this,{orbiter,globe,onRadius,onResume,onAction});this.sim=new SatelliteOperations();
  $('#satellite-sync').onclick=()=>{this.sim.requestSync();this.onResume();this.onAction('sync')};$('#satellite-burn').onclick=()=>{if(this.sim.transferAgent!=='hero'&&this.sim.burnRemaining||this.sim.requestBurn()){this.onResume();this.onAction('burn')}};
  this.heroRescue=fable?new SatelliteHeroRescue({fable,orbiter,globe}):null;
  const rescue=demo=>{if(!this.heroRescue||this.orbiter.broadcastActive)return;if(this.sim.rescueRemaining){this.onResume();this.onAction('rescue');return}if(this.sim.requestRescue({demo})){if(demo){const desired=Math.PI/2,nominal=this.orbiter.sceneAngle??this.orbiter.phase;this.orbiter.scenePhaseOffset=(this.orbiter.scenePhaseOffset||0)+desired-nominal;this.orbiter.sceneAngle=desired}const state=this.sim.state();this.applyOrbit(state);this.heroRescue.update(0,state,this.thrust);this.onResume();this.onAction('rescue')}};
  $('#satellite-rescue').onclick=()=>rescue(false);$('#satellite-rescue-demo').onclick=()=>rescue(true);
  $('#satellite-redeploy').onclick=()=>{this.sim.reset();this.resetScene();this.onResume();this.onAction('redeploy')};
  $('#satellite-height').onchange=e=>this.onRadius(Number(e.target.value));this.onRadius(Number($('#satellite-height').value));
  $('#satellite-use-stable-height').onclick=()=>{if(this.recommendedRadius===null)return;const select=$('#satellite-height');select.value=String(this.recommendedRadius);select.dispatchEvent(new Event('change',{bubbles:true}))};$('#satellite-resume').onclick=()=>this.onResume();
  this.effects=new THREE.Group();orbiter.root.add(this.effects);
  this.beacon=new THREE.Mesh(new THREE.SphereGeometry(.18,16,12),new THREE.MeshBasicMaterial({color:0x9cf0ff,transparent:true,opacity:.8}));this.beacon.position.y=2.4;this.effects.add(this.beacon);
  this.waves=Array.from({length:3},()=>{const wave=new THREE.Mesh(new THREE.TorusGeometry(.2,.012,8,48),new THREE.MeshBasicMaterial({color:0x9cf0ff,transparent:true,opacity:.7,depthWrite:false}));wave.rotation.x=Math.PI/2;wave.position.copy(this.beacon.position);this.effects.add(wave);return wave});
  this.propulsion=createSatellitePropulsion();this.effects.add(this.propulsion.root);this.exhaust=this.propulsion.plumes;
  this.heat=new THREE.Mesh(new THREE.SphereGeometry(1.25,20,12),new THREE.MeshBasicMaterial({color:0xff9c48,transparent:true,opacity:.18,depthWrite:false}));this.heat.position.y=.8;this.heat.scale.set(1,.7,1.3);this.effects.add(this.heat);
  this.impact=new THREE.Group();globe.add(this.impact);this.impact.visible=false;this.flash=new THREE.Mesh(new THREE.SphereGeometry(1,20,12),new THREE.MeshBasicMaterial({color:0xffc77f,transparent:true,depthWrite:false}));this.impact.add(this.flash);this.shock=new THREE.Mesh(new THREE.RingGeometry(.8,1,48),new THREE.MeshBasicMaterial({color:0xffc783,side:THREE.DoubleSide,transparent:true,depthWrite:false}));this.shock.rotation.x=-Math.PI/2;this.shock.position.y=.1;this.impact.add(this.shock);this.resetScene();
 }
 resetScene(){this.heroRescue?.cancel();this.orbiter.scenePhaseOffset=0;this.orbiter.maintenance=null;this.orbiter.root.visible=true;this.lastBurnSerial=0;this.burnActive=false;this.impactLocal=null;if(this.impact)this.impact.visible=false}
 beginCameraFollow(){
  const o=this.orbiter,side=new THREE.Vector3().crossVectors(o.bodyOrbit.a,o.bodyOrbit.b).applyQuaternion(this.globe.getWorldQuaternion(new THREE.Quaternion())).normalize();
  // Always use the same side of the directed orbit. The preceding overview
  // must not mirror a repeated performance. Keep the original stable up axis.
  this.cameraFrame={sign:1,up:Math.abs(side.y)<.8?new THREE.Vector3(0,1,0):new THREE.Vector3(1,0,0)};
 }
 cameraPose(){
  if(!this.cameraFrame)this.beginCameraFollow();
  const o=this.orbiter,p=o.root.position,normal=p.clone().normalize(),side=new THREE.Vector3().crossVectors(o.bodyOrbit.a,o.bodyOrbit.b).applyQuaternion(this.globe.getWorldQuaternion(new THREE.Quaternion())).normalize().multiplyScalar(this.cameraFrame.sign),target=p.clone().addScaledVector(normal,.9),position=p.clone().addScaledVector(side,12).addScaledVector(normal,3),up=this.cameraFrame.up.clone();
  document.body.dataset.satelliteCamera=JSON.stringify({mode:'steady orbital side follow',side:this.cameraFrame.sign,position:position.toArray(),target:target.toArray(),up:up.toArray(),distance:position.distanceTo(target)});
  return {position,target,up};
 }
 applyOrbit(s){
  const o=this.orbiter,nominal=o.sceneAngle??o.phase,globeQ=this.globe.getWorldQuaternion(new THREE.Quaternion());let angle=nominal;
  if(s.burnSerial!==this.lastBurnSerial&&s.transfer){this.lastBurnSerial=s.burnSerial;this.transferAngleStart=nominal}
  if(s.transfer){angle=this.transferAngleStart+s.transfer.angle;if(!s.burnRemaining&&this.burnActive){o.scenePhaseOffset=(o.scenePhaseOffset||0)+angle-nominal;o.sceneAngle=angle}}
  this.burnActive=s.burnRemaining>0;
  const normal=o.bodyOrbit.a.clone().multiplyScalar(Math.cos(angle)).addScaledVector(o.bodyOrbit.b,Math.sin(angle)).applyQuaternion(globeQ).normalize(),radius=Math.max(18,o.radius+s.radialKm/PLANET_KM*18);
  o.root.position.copy(normal).multiplyScalar(radius);o.root.quaternion.setFromUnitVectors(up,normal);
  if(s.crashed){if(!this.impactLocal){this.impactLocal=normal.clone().applyQuaternion(globeQ.clone().invert()).multiplyScalar(18.12);this.impact.position.copy(this.impactLocal);this.impact.quaternion.setFromUnitVectors(up,this.impactLocal.clone().normalize())}o.root.position.copy(this.impactLocal).applyQuaternion(globeQ);o.root.quaternion.setFromUnitVectors(up,o.root.position.clone().normalize());o.root.visible=false}else{o.root.visible=true;this.impactLocal=null}
  this.impact.visible=s.crashed&&s.crashAge<3;this.flash.scale.setScalar(.25+s.crashAge*.7);this.flash.material.opacity=Math.max(0,.9*(1-s.crashAge/2));this.shock.scale.setScalar(.15+s.crashAge*1.6);this.shock.material.opacity=Math.max(0,.7*(1-s.crashAge/3));
  const tangent=o.bodyOrbit.a.clone().multiplyScalar(-Math.sin(angle)).addScaledVector(o.bodyOrbit.b,Math.cos(angle)).applyQuaternion(globeQ).normalize();this.thrust=tangent;
  if(s.transfer){const a=o.bodyOrbit.a.clone().multiplyScalar(Math.cos(this.transferAngleStart)).addScaledVector(o.bodyOrbit.b,Math.sin(this.transferAngleStart)),b=o.bodyOrbit.a.clone().multiplyScalar(-Math.sin(this.transferAngleStart)).addScaledVector(o.bodyOrbit.b,Math.cos(this.transferAngleStart));this.thrust=a.multiplyScalar(s.transfer.velocity[0]).addScaledVector(b,s.transfer.velocity[1]).applyQuaternion(globeQ).normalize()}
  if(s.rescueActive){
   // Present a clear gap between the solar fins to the hero, so both palms
   // reach the bus rather than pushing a solar panel. Return the attitude
   // gradually after the hands release, without changing the camera.
   const rear=this.thrust.clone().addScaledVector(normal,-this.thrust.dot(normal)).normalize().negate(),side=new THREE.Vector3().crossVectors(normal,rear),a=THREE.MathUtils.degToRad(72),x=rear.clone().multiplyScalar(Math.cos(a)).addScaledVector(side,Math.sin(a)),z=rear.clone().multiplyScalar(Math.sin(a)).addScaledVector(side,-Math.cos(a)),target=new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(x,normal,z));
   const u=THREE.MathUtils.clamp(s.rescuePhase==='depart'?(s.rescueTime-HERO_APPROACH_SECONDS-REBOOST_SECONDS)/HERO_DEPART_SECONDS:s.rescueTime/HERO_APPROACH_SECONDS,0,1),ease=u*u*(3-2*u);o.root.quaternion.slerp(target,s.rescuePhase==='depart'?1-ease:ease);
  }
  const exhaust=this.thrust.clone().negate().applyQuaternion(o.root.quaternion.clone().invert());this.propulsion.update(exhaust,!o.broadcastActive&&!s.crashed&&s.transfer?.agent!=='hero'&&!!s.transfer?.firing&&s.burnRemaining>0,this.sim.displayTime);
  this.heat.visible=!s.crashed&&s.available&&!s.burnRemaining&&s.altitudeKm<REENTRY_STORY_KM&&!s.rescueActive;
  o.maintenance={crashed:s.crashed,currentRadius:radius,transferActive:(s.burnRemaining>0||s.rescueActive)&&!o.broadcastActive,reentry:this.heat.visible};
 }
 update(dt,physicsDt,k,paused=false){
  const rho=this.orbiter.radius/18,key=k+':'+rho;if(key!==this.viewKey){this.resetScene();this.viewKey=key}
  const s=this.sim.update(dt,physicsDt,k,rho,{automatic:$('#satellite-auto').checked,disturbances:$('#satellite-disturbance').checked,orbitPaused:!!this.orbiter.broadcastActive});this.state=s;this.applyOrbit(s);this.heroRescue?.update(dt,s,this.thrust,!!this.orbiter.broadcastActive);
  this.recommendedRadius=k>0?[...$('#satellite-height').options].map(o=>Number(o.value)).filter(r=>r>1&&r>s.model.innermostStableRadius).sort((a,b)=>a-b)[0]??null:null;
  $('#satellite-availability').hidden=s.available&&!paused;
  $('#satellite-availability-status').textContent=s.crashed?'浮鯊衛星已墜毀，通訊與拍攝停止。重新部署可重開這段維護演出。':!s.available?(k>0?'目前 r = '+rho.toFixed(2)+' R 不在穩定自由圓軌道區域；此質量需要 r > '+s.model.innermostStableRadius.toFixed(3)+' R。':'零質量沒有自由圓軌道。')+'星鐘與軌道維護暫停計算，地面鐘仍可走時。':'宇宙已暫停：地面鐘、星鐘與軌道維護暫停更新。';
  $('#satellite-redeploy').hidden=!s.crashed;$('#satellite-redeploy').textContent='重新部署衛星';$('#satellite-use-stable-height').hidden=s.crashed||s.available||this.recommendedRadius===null;$('#satellite-use-stable-height').textContent=this.recommendedRadius===null?'調整參考高度':'改用 r = '+this.recommendedRadius.toFixed(2)+' R';$('#satellite-resume').hidden=!paused;
  this.beacon.visible=!s.crashed&&s.syncRemaining>0;this.beacon.scale.setScalar(1+.4*Math.sin(this.sim.displayTime*10));for(const [i,wave] of this.waves.entries()){const u=(this.sim.displayTime*1.2+i/3)%1;wave.visible=!s.crashed&&s.syncRemaining>0;wave.scale.setScalar(1+u*12);wave.material.opacity=.7*(1-u)}
  $('#satellite-sync').disabled=!s.available;$('#satellite-burn').disabled=!s.available||!!this.orbiter.broadcastActive||s.thrusterFailed||s.rescueActive;$('#satellite-burn').textContent=s.rescueActive?'救援演出中':s.thrusterFailed?'暫停自行修軌':s.burnRemaining?'近看升軌演出':'點火修正軌道';
  $('#satellite-rescue').hidden=!s.thrusterFailed&&!s.rescueActive;$('#satellite-rescue').disabled=!this.heroRescue||!s.rescueAvailable&&!s.rescueActive||!!this.orbiter.broadcastActive;$('#satellite-rescue').textContent=s.rescueActive?'近看超拉救援':'請超拉救援';$('#satellite-rescue-demo').disabled=!this.heroRescue||!s.available||!!s.burnRemaining||s.rescueActive||!!this.orbiter.broadcastActive;
  $('#satellite-rescue-status').textContent=s.rescuePhase==='approach'?'救援慢鏡頭 · 超拉飛來接手':s.rescuePhase==='boost'?'超拉雙手向飛行方向推進 · 衛星引擎不點火':s.rescuePhase==='coast'?'超拉鬆手陪飛 · 衛星沿轉移軌道滑行':s.rescuePhase==='circularize'?'超拉第二次推進 · 穩定回到參考軌道':s.rescuePhase==='depart'?'已回軌 · 超拉正在離開':s.crashed?'結構已毀損，無法救援；請重新部署':s.thrusterFailed?'救援情境中，暫停自行修軌；超拉推回後恢復正常。':s.rescues?'救援演出完成 · 點火修軌、校時、自動維護與拍攝照常運作':'可預覽超拉救援情境；演出完成後衛星恢復正常。';
  $('#satellite-ground').textContent=s.ground.toFixed(3)+' s';$('#satellite-raw').textContent=s.available?signedUs(s.rawOffset):'—';$('#satellite-output').textContent=s.available?signedUs(s.outputOffset):'—';$('#satellite-altitude').textContent=s.model.stable?s.altitudeKm.toFixed(1)+' km':'—';
  $('#satellite-clock-status').textContent=s.crashed?'已失聯 · 星鐘不再回傳，表面地面鐘繼續走時':!s.available?'星鐘未計算 · 此高度不適用穩定圓軌道鐘差':s.syncRemaining?'地面站交換校時資料…':s.calibrated?'已校正輸出相位與頻率；原始鐘繼續記錄偏差':'尚未校時 · 原始鐘與輸出鐘均會累積誤差';
  $('#satellite-orbit-error').textContent=s.available?s.errorKm.toFixed(2)+' km':s.crashed?'已墜毀':'—';const phase=s.transfer?.phase;
  $('#satellite-orbit-status').textContent=s.crashed?'浮鯊衛星已墜毀 · 通訊中斷':!s.available?'未計算軌道偏移':this.orbiter.broadcastActive?'實驗轉播中 · 軌道維護演出待命':s.rescueActive?'超拉外力救援中':phase==='boost'?'順向加速點火 · 噴氣朝飛行反方向':phase==='coast'?'沿橢圓轉移軌道升高 · 推進器關閉':phase==='circularize'?'第二次順向點火 · 回到參考圓軌道':s.thrusterFailed?'推進系統失效 · 無法自行修軌':s.errorKm<.1?'接近參考軌道':$('#satellite-disturbance').checked?'向內衰減中 · 尚未修軌將持續下降':'衰減演出已暫停';$('#orbit-error-dot').setAttribute('visibility',s.available?'visible':'hidden');
  const diagramScale=Math.min(6,40/Math.max(.001,Math.abs(s.radialKm)));$('#orbit-error-dot').setAttribute('cx','100');$('#orbit-error-dot').setAttribute('cy',String(54-s.radialKm*diagramScale));$('#orbit-error-scale').textContent='每格 '+(30/diagramScale).toFixed(1)+' km';
  $('#satellite-model-status').textContent=s.model.stable?'參考圓軌道 r = '+rho.toFixed(2)+' R；局部速度 '+s.model.localBeta.toPrecision(4)+' c。引力因子 ×'+s.model.gravitational.toFixed(10)+'，速度因子 ×'+s.model.motion.toFixed(10)+'；相對表面鐘速 ×'+s.model.ratio.toFixed(12)+(Math.abs(rho-1.5)<1e-9?'。此基準高度的兩個相對論效應恰好相消；設備頻偏仍需校時。':'。'):s.model.reason+'；請降低質量或提高衛星參考高度。';
  document.body.dataset.satelliteOps=JSON.stringify({...s,radius:rho,paused,orbitStoryPaused:!!this.orbiter.broadcastActive,recommendedRadius:this.recommendedRadius,automatic:$('#satellite-auto').checked,disturbances:$('#satellite-disturbance').checked,sceneOffsetScale:1,diagramPixelsPerKm:diagramScale,thrustDirection:this.thrust.toArray(),exhaustDirection:this.thrust.clone().negate().toArray(),firing:this.exhaust.visible,orbitModel:'accelerated inward-decay story; Newtonian Hohmann transfer geometry, display-time impulses; strong field is illustrative',clockModel:'nominal circular Schwarzschild reference vs static surface, separate from orbital story',photosWaitForMaintenance:true});
 }
}
