import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {loadCachedModel} from './model-cache.mjs?v=67d6694af1eb';
import {SpiderRig,SpiderSilk} from './spider-rig.js?v=67d6694af1eb';
import {SpiderStandby} from './spider-standby.js?v=67d6694af1eb';
import {isHeroCloth,setFlightPose,setGaitPose} from './hero-style.js?v=67d6694af1eb';
import {RunnerAfterimages} from './runner-afterimages.js?v=67d6694af1eb';
import {burstTravel} from './hero-motions.mjs?v=67d6694af1eb';
import {capeMotion,clothRipple,weaverLift} from './cape-motion.mjs?v=67d6694af1eb';
import {poseWeaverArms} from './weaver-rig.js?v=67d6694af1eb';
import {poseSuspendedWeaver,updateSuspendedCape} from './weaver-flight.js?v=67d6694af1eb';
const $=s=>document.querySelector(s),views=[],labels={'capy-walk':'正常步行','capy-run':'一般跑步','spider-idle':'八足待命','spider-crawl':'交替攀爬','spider-silk':'八足展開','spider-repair':'動手維修','spider-jump':'蹬地飛躍','spider-web':'八隻腳尖噴絲'};
let designs,spec;
const defaultMotion=key=>key==='capy-super'?'capy-landing':key==='capy-speed'?'afterimages':key==='capy-spider'?'spider-web':'weaver-flight';
function stage(v,z){const delta=z-v.stageZ;v.camera.position.z+=delta;v.controls.target.z+=delta;v.ground.position.z=z;v.stageZ=z}
function choose(v,mode,play=true){
 const wasSpiderStandby=['spider-hang','spider-wall'].includes(v.mode),isSpiderStandby=['spider-hang','spider-wall'].includes(mode);
 if(v.spiderStandby){v.spiderStandby.restore();v.spiderBackdrop.visible=isSpiderStandby;v.model.position.set(0,0,0);v.model.quaternion.identity();if(wasSpiderStandby&&!isSpiderStandby){v.camera.position.copy(v.spiderCameraHome.position);v.camera.up.set(0,1,0);v.controls.target.copy(v.spiderCameraHome.target)}}
 v.mixer.stopAllAction();v.action=null;v.mode=mode;v.time=0;v.playing=play&&mode!=='idle';stage(v,0);v.rig.position.set(0,0,0);v.rig.rotation.set(0,0,0);setFlightPose(v.model,1);
 if(v.afterimages){v.afterimages.history=[];v.afterimages.update(v.rig,0,0,.8,0)}
 const clip=v.animations.find(a=>a.name===mode);v.duration=mode==='spider-web'||isSpiderStandby?12:clip?.duration||(mode==='afterimages'||mode==='weaver'||mode==='weaver-flight'?16:0);v.loop=isSpiderStandby||(clip?spec[mode]?.loop??true:false);
 if(clip){v.action=v.mixer.clipAction(clip);v.action.reset().setLoop(v.loop?THREE.LoopRepeat:THREE.LoopOnce,Infinity);v.action.clampWhenFinished=!v.loop;v.action.play()}
 v.select.value=mode;v.seek.max=String(v.duration||1);v.seek.disabled=mode==='idle';v.note.textContent=mode==='afterimages'||mode==='weaver'||mode==='weaver-flight'||mode==='spider-web'||isSpiderStandby?'程式效果 · 隨動作包提供可重用程式':'GLB 內建動畫 · 隨模型下載';
 if(isSpiderStandby){v.spiderStandby.choose(mode==='spider-hang'?'hang':'wall');const view=v.spiderStandby.cameraPose(v.camera.aspect);v.camera.position.copy(view.position);v.camera.up.copy(view.up);v.controls.target.copy(view.target);v.controls.update()}
 if(mode==='idle')v.note.textContent='選擇動作後播放；可暫停、重播或拖曳進度。';
 pose(v,0,0);
}
function seedGhosts(v){
 if(!v.afterimages)return;v.afterimages.history=[];
 for(let i=12;i>=0;i--){const t=v.time-i*.035;if(t<0)continue;v.afterimages.history.push({time:t,position:new THREE.Vector3(0,.035*Math.abs(Math.sin(t*14)),burstTravel(t)),quaternion:new THREE.Quaternion().setFromEuler(new THREE.Euler(.12,0,0)),stride:t*14})}
}
async function boot(){
 try{
  [designs,spec]=await Promise.all(['./hero-designs.json?v=67d6694af1eb','./hero-motion-spec.json?v=67d6694af1eb'].map(async p=>(await fetch(p)).json()));
  const manifest=await(await fetch('./'+designs.manifest)).json(),base='./'+designs.manifest.slice(0,designs.manifest.lastIndexOf('/')+1),loader=new GLTFLoader();$('#crew-manifest').href='./'+designs.manifest;
  for(const article of document.querySelectorAll('[data-hero]')){
   const key=article.dataset.hero,entry=manifest.assets.find(a=>a.id===designs.assets[key].id),gltf=await loadCachedModel(loader,base+entry.path,entry),model=gltf.scene,host=article.querySelector('.viewport'),scene=new THREE.Scene(),rig=new THREE.Group();rig.add(model);scene.add(rig);
   const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true,alpha:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;host.append(renderer.domElement);
   scene.add(new THREE.HemisphereLight(0xfff9e8,0x6b7e76,1.4));const sun=new THREE.DirectionalLight(0xffefda,2);sun.position.set(-3,6,5);scene.add(sun);const rim=new THREE.DirectionalLight(0xd4f3ee,.9);rim.position.set(4,3,-3);scene.add(rim);
   const ground=new THREE.Mesh(new THREE.CircleGeometry(1.25,64),new THREE.MeshBasicMaterial({color:key==='capy-speed'?0xd9d2e1:0xd3e1d5,transparent:true,opacity:.6}));ground.rotation.x=-Math.PI/2;ground.position.y=-.01;scene.add(ground);
   const camera=new THREE.PerspectiveCamera(34,1,.05,150),controls=new OrbitControls(camera,renderer.domElement);camera.position.set(3.6,2.3,5.3);controls.target.set(0,1.1,0);controls.enablePan=false;controls.enableDamping=true;controls.minDistance=3.5;controls.maxDistance=9;controls.maxPolarAngle=Math.PI*.75;controls.update();
   const cloth=[];model.traverse(n=>{if(n.isMesh&&isHeroCloth(n.name)){n.geometry=n.geometry.clone();n.geometry.computeBoundingBox();cloth.push({mesh:n,base:n.geometry.attributes.position.array.slice(),center:n.geometry.boundingBox.getCenter(new THREE.Vector3()),size:n.geometry.boundingBox.getSize(new THREE.Vector3())})}});
   const v={key,id:entry.id,host,article,renderer,scene,rig,model,camera,controls,cloth,ground,animations:gltf.animations,mixer:new THREE.AnimationMixer(model),time:0,mode:'idle',playing:false,stageZ:0};
   if(key==='capy-spider'){
    v.spiderRig=new SpiderRig(model);v.silk=new SpiderSilk(scene);controls.maxDistance=12;ground.scale.setScalar(1.4);v.spiderCameraHome={position:camera.position.clone(),target:controls.target.clone()};
    const layout=await(await fetch('./planet-layout.json?v=67d6694af1eb')).json(),buildingManifest=await(await fetch('./'+layout.export_manifest)).json(),placement=layout.surface_placements.find(p=>p.key==='museum'),building=buildingManifest.assets.find(a=>a.id===placement.asset_id),buildingBase='./'+layout.export_manifest.slice(0,layout.export_manifest.lastIndexOf('/')+1),architecture=await loadCachedModel(loader,buildingBase+building.path,building);v.spiderBackdrop=architecture.scene.clone(true);scene.add(v.spiderBackdrop);v.spiderStandby=new SpiderStandby({globe:scene,actor:model,rig:v.spiderRig,silk:v.silk,anchorSites:[{root:v.spiderBackdrop,name:'待命建築'}]});v.spiderBackdrop.visible=false;
   }
   if(key==='capy-speed')v.afterimages=new RunnerAfterimages(scene,model,setGaitPose);
   const label=document.createElement('label');label.className='motion-choice';label.textContent='選擇動作';const select=document.createElement('select');select.id='hero-motion-'+key;select.setAttribute('aria-label',designs.assets[key].name+'動作');label.append(select);article.querySelector('.actions').before(label);v.select=select;
   for(const [value,text] of [['idle','待命'],...(key==='capy-spider'?[['spider-hang','蛛絲倒吊待命'],['spider-wall','貼牆攀附待命'],['spider-web','八隻腳尖噴絲']]:[]),...gltf.animations.map(a=>[a.name,spec[a.name]?.label||labels[a.name]||a.name]),...(key==='capy-speed'?[['afterimages','起步 → 高速殘影 → 停步']]:key==='capy-mage'?[['weaver-flight','披風尾端揚起 → 吊掛飛行 → 落地'],['weaver','披巾 → 魔毯 → 披回']]:[])]){const option=document.createElement('option');option.value=value;option.textContent=text;select.append(option)}
   const timeline=document.createElement('label');timeline.className='motion-timeline';timeline.textContent='動作進度';const seek=document.createElement('input');seek.type='range';seek.min='0';seek.max='1';seek.step='.01';seek.value='0';seek.setAttribute('aria-label',designs.assets[key].name+'動作進度');timeline.append(seek);const stamp=document.createElement('output');timeline.append(stamp);article.querySelector('.actions').after(timeline);Object.assign(v,{seek,stamp});
   const note=document.createElement('p');note.className='motion-note';timeline.after(note);v.note=note;
   const restart=document.createElement('button');restart.dataset.action='restart';restart.textContent='重播';article.querySelector('[data-action="motion"]').after(restart);
   const resource=document.createElement('div');resource.className='motion-resources';const catalog=document.createElement('a');catalog.href='./credits.html#'+entry.id;catalog.textContent='角色與使用資訊';resource.append(catalog);note.after(resource);
   const resize=()=>{camera.aspect=host.clientWidth/host.clientHeight;camera.updateProjectionMatrix();renderer.setSize(host.clientWidth,host.clientHeight,false)};new ResizeObserver(resize).observe(host);resize();
   select.onchange=()=>choose(v,select.value,true);
   article.querySelector('[data-action="motion"]').onclick=()=>{if(v.mode==='idle')choose(v,defaultMotion(key),true);else if(v.time>=v.duration&&!v.loop)choose(v,v.mode,true);else v.playing=!v.playing};
   restart.onclick=()=>choose(v,v.mode==='idle'?(defaultMotion(key)):v.mode,true);
   seek.oninput=()=>{v.playing=false;v.time=Number(seek.value);seedGhosts(v);pose(v,0,v.time)};
   article.querySelector('[data-action="turn"]').onclick=()=>{const delta=camera.position.clone().sub(controls.target).applyAxisAngle(new THREE.Vector3(0,1,0),Math.PI/2);camera.position.copy(controls.target).add(delta);controls.update()};
   const link=article.querySelector('.download');link.href=base+entry.path;link.download=designs.assets[key].name+'.glb';choose(v,'idle',false);views.push(v);
  }
  document.body.dataset.ready='true';$('#load-status').textContent='已載入網站隨附的原創英雄。選擇新動作、重播，或拖曳進度檢查細節。';
 }catch(e){$('#load-status').textContent='模型載入未完成：'+e.message;document.body.dataset.ready='failed';console.error(e)}
}
function pose(v,dt,wallTime){
 if(v.playing){v.time+=dt;if(v.loop)v.time%=v.duration;else if(v.time>=v.duration){v.time=v.duration;v.playing=false}}
 const {model,rig,key,mode}=v;rig.position.set(0,0,0);rig.rotation.set(0,0,0);if(!v.action&&!['spider-hang','spider-wall'].includes(mode))setFlightPose(model,1);let progress=0,label='待命';stage(v,0);
 if(v.action){v.action.enabled=true;v.action.paused=false;v.action.time=v.time;v.mixer.update(0);v.action.paused=true;label=spec[mode]?.label||labels[mode]||mode}
 if(mode==='afterimages'){const stride=v.time*14;rig.rotation.x=.12;rig.position.set(0,.035*Math.abs(Math.sin(stride)),burstTravel(v.time));stage(v,rig.position.z);setGaitPose(model,stride,true);v.afterimages.update(rig,v.time,v.time,.8,stride);label=v.time<2.1?'起步 · 一般跑步':v.time<13.8?'高速 · 五層淡出殘影':v.time<16?'減速 · 一般跑步':'已停步';if(v.time===16)setFlightPose(model,1)}
 else if(v.afterimages)v.afterimages.update(rig,0,16,0,0);
 if(mode==='weaver'){const t=v.time;progress=t<3?.04+.19*t/3:t<11?.5:.78+.20*(t-11)/5;const motion=capeMotion(progress);label=motion.stage;poseWeaverArms(model,motion,0,t)}
 const suspension=mode==='weaver-flight'?weaverLift(v.time):null;if(suspension){poseSuspendedWeaver(model,v.time,suspension.body);updateSuspendedCape(v.cloth,v.time,suspension.tail);rig.position.y=suspension.height;rig.rotation.set(suspension.pitch,0,suspension.roll);label=suspension.stage}
 if(v.silk){v.silk.group.visible=mode==='spider-web';if(['spider-hang','spider-wall'].includes(mode)){v.spiderStandby.pose(v.time);label=v.spiderStandby.phase}else if(mode==='spider-web'){v.spiderRig.pose(v.time,{working:true});const origins=v.spiderRig.emitters(),forward=new THREE.Vector3(0,0,1).transformDirection(model.matrixWorld),targets=origins.map(p=>p.clone().addScaledVector(forward,1.8)),extent=Math.min(1,Math.max(0,(v.time-.5)/1.2),Math.max(0,(12-v.time)/1.5));v.silk.update(origins,targets,extent,v.time);label='八隻腳尖 · 向前噴絲'}}
 const time=mode==='idle'?wallTime:v.time;
 for(const {mesh,base,center,size} of v.cloth){if(suspension)continue;const p=mesh.geometry.attributes.position;
  if(key==='capy-mage'){const m=capeMotion(progress,center.toArray());for(let i=0;i<p.count;i++){const x=base[i*3],y=base[i*3+1],z=base[i*3+2],u=(x-center.x)/(size.x/2),w=(y-center.y)/(size.y/2),t=THREE.MathUtils.clamp((1.42-y)/1.02,0,1),r=clothRipple(u,w,time,m.carpet,m.fold);p.setXYZ(i,x+r.x,y+r.y,center.z+(z-center.z)*(1-.92*m.carpet)+r.z+.035*t*Math.sin(time*4+t*5))}mesh.rotation.set(m.rotation,0,m.twist);mesh.scale.fromArray(m.scale);mesh.position.fromArray(m.center).sub(center.clone().multiply(mesh.scale).applyQuaternion(mesh.quaternion))}
  else for(let i=0;i<p.count;i++){const t=THREE.MathUtils.clamp((1.42-base[i*3+1])/1.02,0,1);p.setXYZ(i,base[i*3],base[i*3+1],base[i*3+2]+.035*t*Math.sin(time*7+base[i*3]*5+t*4))}
  p.needsUpdate=true;mesh.geometry.computeVertexNormals();mesh.geometry.computeBoundingBox();mesh.geometry.computeBoundingSphere();
 }
 v.article.querySelector('.pose-label').textContent=label;v.article.querySelector('[data-action="motion"]').textContent=v.playing?'暫停':'播放動作';v.article.querySelector('[data-action="motion"]').setAttribute('aria-pressed',String(v.playing));v.seek.value=String(v.time);v.stamp.textContent=v.time.toFixed(1)+' / '+v.duration.toFixed(1)+' s';
 v.telemetry={assetId:v.id,mode,time:v.time,duration:v.duration,playing:v.playing,embeddedClips:v.animations.map(a=>a.name),afterimages:v.afterimages?.ghosts.filter(g=>g.root.visible).length||0,stage:label,suspension,silkEmitters:v.spiderRig?.legs.length||0,silkStrands:v.silk?.strands.filter(s=>s.group.visible&&v.silk.group.visible).length||0};
}
const clock=new THREE.Clock();function frame(){const dt=Math.min(.05,clock.getDelta()),time=clock.elapsedTime;for(const v of views){pose(v,dt,time);v.controls.update();v.renderer.render(v.scene,v.camera)}if(views.length)document.body.dataset.heroGallery=JSON.stringify(views.map(v=>v.telemetry));requestAnimationFrame(frame)}frame();boot();
