import {deviceViewport,watchDeviceViewport} from './device-viewport.mjs';
// The scene keeps a fixed viewport behind floating controls. UI visibility and
// position never change the renderer dimensions or camera aspect.
export class SceneViewport{
 constructor({renderer,camera,host}){
  Object.assign(this,{renderer,camera,host});this.pending=false;this.last='';
  this.queue=()=>{if(!this.pending){this.pending=true;requestAnimationFrame(()=>{this.pending=false;this.layout()})}};
  this.observer=new ResizeObserver(this.queue);this.observer.observe(host);
  this.deviceEvents=watchDeviceViewport(this.queue);this.layout();
 }
 layout(){
  const view=deviceViewport();for(const [key,value] of Object.entries(view))document.documentElement.style.setProperty('--scene-'+key,value+'px');
  const bounds=this.host.getBoundingClientRect(),rect={left:Math.round(bounds.left),top:Math.round(bounds.top),width:Math.max(1,Math.floor(bounds.width)),height:Math.max(1,Math.floor(bounds.height)),mode:'floating'};
  const key=JSON.stringify(rect);if(key===this.last)return;this.last=key;
  this.renderer.setSize(rect.width,rect.height,false);this.camera.aspect=rect.width/rect.height;this.camera.updateProjectionMatrix();document.body.dataset.viewport=key;
  document.dispatchEvent(new CustomEvent('scene-viewport-change',{detail:rect}));
 }
}
