import {attachBrowserViewport,elementViewport,viewportTask,watchDeviceViewport} from './device-viewport.mjs?v=e6c32348dbca';
// Keep the same framing along the shorter viewport axis. Updating aspect alone
// crops an overview in portrait even though the canvas dimensions are correct.
export const viewportFitScale=aspect=>Math.min(1,Math.max(.01,aspect));
// The scene's normal-flow frame follows the visible browser. Controls float
// above it, so their visibility never changes renderer dimensions or aspect.
export class SceneViewport{
 constructor({renderer,camera,host,autoFrame=()=>true,repaint=()=>{}}){
  Object.assign(this,{renderer,camera,host,autoFrame});this.pending=false;this.last='';this.fitScale=1;this.nextCheck=0;
  this.browserFrame=attachBrowserViewport({root:document.documentElement,onSettled:()=>{this.layout();repaint()}});
  this.layoutTask=viewportTask(()=>{if(this.browserFrame.settling)return;this.layout();repaint()});this.queue=this.layoutTask.queue;
  this.observer=new ResizeObserver(this.queue);this.observer.observe(host);
  this.deviceEvents=watchDeviceViewport(this.queue);this.layout();
 }
 sync(now=performance.now()){
  if(this.browserFrame.settling)return false;
  if(now<this.nextCheck)return false;this.nextCheck=now+100;this.browserFrame.refresh();const view=elementViewport(this.host);if(!view)return false;
  const old=this.rect;if(old&&['left','top','width','height'].every(key=>old[key]===view[key]))return false;return this.layout(view);
 }
 layout(view=elementViewport(this.host)){
  if(this.browserFrame.settling)return false;
  if(!view)return false;for(const [key,value] of Object.entries(view))document.documentElement.style.setProperty('--scene-'+key,value+'px');
  const rect={...view,mode:'floating'};this.rect=rect;
  const key=JSON.stringify(rect),resized=key!==this.last,scale=this.autoFrame()?viewportFitScale(rect.width/rect.height):1,refit=scale!==this.fitScale;if(!resized&&!refit)return;
  if(resized){this.last=key;this.renderer.setSize(rect.width,rect.height,false);this.camera.aspect=rect.width/rect.height;document.body.dataset.viewport=key}
  this.camera.zoom=(this.camera.zoom||1)/this.fitScale*scale;this.fitScale=scale;this.camera.updateProjectionMatrix();document.body.dataset.viewportFraming=JSON.stringify({layout:rect.width<rect.height?'portrait':'landscape',scale,aspect:this.camera.aspect});
  if(resized)document.dispatchEvent(new CustomEvent('scene-viewport-change',{detail:rect}));return resized||refit;
 }
 diagnostics(){
  const v=globalThis.visualViewport,canvas=this.renderer.domElement;
  return {build:document.body.dataset.build||'local',browser:navigator.userAgent,url:location.origin+location.pathname,window:{width:innerWidth,height:innerHeight},visual:v?{width:v.width,height:v.height,scale:v.scale,top:v.offsetTop,left:v.offsetLeft}:null,root:{width:document.documentElement.clientWidth,height:document.documentElement.clientHeight},scene:elementViewport(this.host),canvas:canvas?{width:canvas.width,height:canvas.height,css:elementViewport(canvas)}:null,framing:{aspect:this.camera.aspect,zoom:this.camera.zoom,fitScale:this.fitScale},layout:document.body.dataset.sceneLayout,panels:JSON.parse(document.body.dataset.scenePanels||'{}')};
 }
}
