import {deviceViewport,watchDeviceViewport} from './device-viewport.mjs';
// Keep the same framing along the shorter viewport axis. Updating aspect alone
// crops an overview in portrait even though the canvas dimensions are correct.
export const viewportFitScale=aspect=>Math.min(1,Math.max(.01,aspect));
// The scene keeps a fixed viewport behind floating controls. UI visibility and
// position never change the renderer dimensions or camera aspect.
export class SceneViewport{
 constructor({renderer,camera,host,autoFrame=()=>true}){
  Object.assign(this,{renderer,camera,host,autoFrame});this.pending=false;this.last='';this.fitScale=1;
  this.queue=()=>{if(!this.pending){this.pending=true;requestAnimationFrame(()=>{this.pending=false;this.layout()})}};
  this.observer=new ResizeObserver(this.queue);this.observer.observe(host);
  this.deviceEvents=watchDeviceViewport(this.queue);this.layout();
 }
 layout(){
  const view=deviceViewport();for(const [key,value] of Object.entries(view))document.documentElement.style.setProperty('--scene-'+key,value+'px');
  const bounds=this.host.getBoundingClientRect(),rect={left:Math.round(bounds.left),top:Math.round(bounds.top),width:Math.max(1,Math.floor(bounds.width)),height:Math.max(1,Math.floor(bounds.height)),mode:'floating'};
  const key=JSON.stringify(rect),resized=key!==this.last,scale=this.autoFrame()?viewportFitScale(rect.width/rect.height):1,refit=scale!==this.fitScale;if(!resized&&!refit)return;
  if(resized){this.last=key;this.renderer.setSize(rect.width,rect.height,false);this.camera.aspect=rect.width/rect.height;document.body.dataset.viewport=key}
  this.camera.zoom=(this.camera.zoom||1)/this.fitScale*scale;this.fitScale=scale;this.camera.updateProjectionMatrix();document.body.dataset.viewportFraming=JSON.stringify({layout:rect.width<rect.height?'portrait':'landscape',scale,aspect:this.camera.aspect});
  if(resized)document.dispatchEvent(new CustomEvent('scene-viewport-change',{detail:rect}));
 }
}
