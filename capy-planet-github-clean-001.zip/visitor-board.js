import * as THREE from 'three';
import {getVisitorStats} from './visitor-stats.mjs?v=2d2193a1a37f';

// A texture on the existing repair sign, rather than another HTML overlay.
// It inherits the sign's repair choreography and obstacle fade automatically.
export class VisitorBoard{
 constructor(sign,{createCanvas=()=>globalThis.document?.createElement?.('canvas'),stats=getVisitorStats}={}){
  this.canvas=createCanvas();this.ctx=this.canvas?.getContext?.('2d');if(!this.ctx)return;
  this.canvas.width=1024;this.canvas.height=512;
  this.texture=new THREE.CanvasTexture(this.canvas);this.texture.colorSpace=THREE.SRGBColorSpace;
  this.texture.anisotropy=4;
  const material=new THREE.MeshBasicMaterial({map:this.texture,toneMapped:false});
  this.face=new THREE.Mesh(new THREE.PlaneGeometry(1.30,.68),material);this.face.name='repair-sign-visitors';this.face.position.set(.37,0,.15);
  sign.traverse(node=>{if(node.name.startsWith('sign-service-bar'))node.visible=false});sign.add(this.face);
  this.paint({status:'loading',visitors:null});stats().then(value=>this.paint(value)).catch(()=>this.paint({status:'unavailable',visitors:null}));
 }
 paint(value){
  this.value=value;const c=this.ctx;c.fillStyle='#2a6e73';c.fillRect(0,0,1024,512);c.textAlign='center';c.textBaseline='middle';
  c.fillStyle='#d1f0df';c.font='600 76px sans-serif';c.fillText('到訪人數',512,102);
  const text=value.status==='ready'?new Intl.NumberFormat('en-US').format(value.visitors)+' 人':value.status==='local'?'正式站啟用':value.status==='loading'?'讀取中…':'維修中';
  let size=value.status==='ready'?146:98;c.font=`700 ${size}px sans-serif`;while(c.measureText(text).width>930&&size>24)c.font=`700 ${--size}px sans-serif`;
  c.fillStyle='#ffe1a0';c.fillText(text,512,280);c.fillStyle='#c4dedb';c.font='38px sans-serif';c.fillText('訪客估計 · 啟用起累計',512,434);
  this.texture.needsUpdate=true;
  if(globalThis.document?.body)document.body.dataset.visitorBoard=JSON.stringify({...value,label:'到訪人數',display:text,inScene:true});
 }
}
