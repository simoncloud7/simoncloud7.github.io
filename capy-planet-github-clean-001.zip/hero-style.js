// Shared display pose and cloth selectors for the authored hero costumes.
export const isHeroCloth=name=>name.startsWith('hero-sail-cape')||name.startsWith('weaver-cloak')||name.startsWith('flowing-red-cape');
export function setGaitPose(root,phase,run=false){root.traverse(n=>{const match=/^(arm|leg)-(-?1)$/.exec(n.name);if(match)n.rotation.x=Math.sin(phase)*Number(match[2])*(match[1]==='arm'?-1:1)*(run?.83:.28);if(n.name.startsWith('elder-cane'))n.visible=false})}
export function setFlightPose(model,blend,{single=0,armBlend=blend}={}){
 const flying=1-blend,armFlying=1-armBlend;
 model.traverse(n=>{
  if(n.name==='head-pivot')n.rotation.x=-1.25*flying;
  // Negative X is a shoulder raise through the character's FRONT (+Z).
  // Keep both raised and tucked poses on this branch, including two-to-one
  // flight changes, so interpolation never sweeps either paw behind the back.
  if(n.name==='arm--1'||n.name==='arm-1'){const side=n.name==='arm--1'?-1:1,reach=side===-1?1:1-single;n.rotation.x=(-(Math.PI-.1)*reach-.28*(1-reach))*armFlying;n.rotation.z=side*(.07*reach+.32*(1-reach))*armFlying;n.scale.y=1+.65*reach*armFlying}
  if(n.name.startsWith('leg-')){n.rotation.x=.06*flying;n.rotation.z=(n.name==='leg-1'?1:-1)*.06*flying}
 });
}
