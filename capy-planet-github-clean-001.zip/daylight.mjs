const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],unit=a=>{const n=Math.hypot(...a);return a.map(v=>v/n)},clamp=x=>Math.max(-1,Math.min(1,x)),TAU=Math.PI*2;
export const physicalLighting=mode=>mode==='stellar'||mode==='natural';
export const lightingAmbient=mode=>mode==='natural'?.08:mode==='stellar'?.16:2.2;
// Keep the original upright presentation in every lighting mode. Lighting must
// not select a different physical rotation axis.
export const PLANET_NORTH=Object.freeze([0,1,0]);
export function advancePlanetSpin(globe,seconds){globe.rotateY(seconds*.012)}
export function solarGeometry(normal,sunDirection,spinAxis=[0,0,1],horizonElevation=0){
 const n=unit(normal),s=unit(sunDirection),axis=unit(spinAxis),latitudeSin=dot(n,axis),declinationSin=dot(s,axis),np=n.map((v,i)=>v-latitudeSin*axis[i]),sp=s.map((v,i)=>v-declinationSin*axis[i]),product=Math.hypot(...np)*Math.hypot(...sp),elevation=Math.asin(clamp(dot(n,s)))*180/Math.PI;
 const hourAngle=product<1e-10?null:Math.atan2(dot(axis,cross(sp,np)),dot(sp,np)),hours=hourAngle===null?null:((12+hourAngle*12/Math.PI)%24+24)%24;
 const heightAboveHorizon=elevation-horizonElevation,period=heightAboveHorizon>1e-7?'白天':heightAboveHorizon>-18?(hourAngle!==null&&hourAngle<0?'黎明':'黃昏'):'夜晚';
 return {elevation,horizonElevation,heightAboveHorizon,hourAngle,hours,period,latitudeSin,declinationSin,product};
}
export function solarMomentDelta(normal,sunDirection,spinAxis,moment,horizonElevation=0){
 const g=solarGeometry(normal,sunDirection,spinAxis);if(g.hourAngle===null)return null;
 let angle;if(moment==='noon')angle=0;else if(moment==='midnight')angle=Math.PI;else{
  const horizon=(Math.sin(horizonElevation*Math.PI/180)-g.latitudeSin*g.declinationSin)/g.product;if(Math.abs(horizon)>1)return null;
  angle=Math.acos(clamp(horizon))*(moment==='sunrise'?-1:1);
 }
 return ((angle-g.hourAngle+Math.PI)%TAU+TAU)%TAU-Math.PI;
}
export function solarClock(hours){if(hours===null)return '—';const minutes=Math.round(hours*60)%1440;return String(Math.floor(minutes/60)).padStart(2,'0')+':'+String(minutes%60).padStart(2,'0')}
