import * as THREE from 'three';
import {launchPose,LAUNCH_DURATION,LANDING_X,ufoPose,VOYAGE_START,VOYAGE_TURN,voyagePose} from './flight.mjs?v=3f5a2fef0fc5';
import {comparisonCamera,referenceLabel} from './comparison-view.js?v=3f5a2fef0fc5';
import {loadScenicPhoto,saveScenicPhoto} from './photo-store.mjs?v=3f5a2fef0fc5';
import {photoTimestamp,photoFilename} from './photo-caption.mjs?v=3f5a2fef0fc5';
import {heroState} from './fable.mjs?v=3f5a2fef0fc5';
import {makeScenicCamera} from './scenic-camera.mjs?v=3f5a2fef0fc5';
import {clearPlanetSight} from './sensor-visibility.mjs?v=3f5a2fef0fc5';
import {withSensorShadows} from './shadow-pass.mjs?v=3f5a2fef0fc5';
import {SpacewalkSystem} from './spacewalk-runtime.js?v=3f5a2fef0fc5';

export class FlightSystem{
 constructor({scene,globe,renderer,cloneAsset,assets,activities,frameAt,f8,ufo,onStart}){
  Object.assign(this,{scene,globe,renderer,f8,ufo,onStart});this.launchTime=0;this.launchActive=false;this.missionRequested=false;this.missionDismissed=false;this.voyage=null;this.twinMission=null;this.feedEnabled=true;this.feedFrames=0;this.lastFeed=-1;
  this.site=new THREE.Group();const f=frameAt(16,11);this.site.position.copy(f.normal.multiplyScalar(18.2));this.site.quaternion.copy(f.q);globe.add(this.site);
  const base=new THREE.Mesh(new THREE.BoxGeometry(11.6,1.8,5.5),new THREE.MeshStandardMaterial({color:0x8a9996,roughness:1}));base.position.set(-2.5,-.9,0);base.receiveShadow=true;base.castShadow=true;this.base=base;this.site.add(base);
  const launch=cloneAsset(assets.launchpad.id).root;this.launchpad=launch;this.site.add(launch);
  const landing=cloneAsset(assets['landing-pad'].id).root;landing.position.x=LANDING_X;this.landingPad=landing;this.site.add(landing);
  this.booster=cloneAsset(assets['reusable-booster'].id).root;this.upper=cloneAsset(assets['upper-stage'].id).root;this.site.add(this.booster,this.upper);
  this.spacecraft=cloneAsset(assets['twin-spacecraft'].id,.8).root;scene.add(this.spacecraft);
  this.spacewalk=activities?new SpacewalkSystem({spacecraft:this.spacecraft,cloneAsset,assets:activities}):null;
  this.legs=[];this.booster.traverse(n=>{if(/^landing-leg-\d$/.test(n.name))this.legs.push(n)});
  this.boostFlame=this.flame(.24,1.6);this.boostFlame.position.y=.2;this.booster.add(this.boostFlame);
  this.upperFlame=this.flame(.16,1);this.upper.add(this.upperFlame);
  this.trail=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(24,3,19),new THREE.Vector3(39,15,-8)]),new THREE.LineDashedMaterial({color:0xc8b783,dashSize:.6,gapSize:.5,transparent:true,opacity:.5}));this.trail.computeLineDistances();this.trail.visible=false;scene.add(this.trail);
  this.voyageGuide=new THREE.Group();this.voyageGuide.userData.sensorOverlay=true;this.voyageGuide.visible=false;scene.add(this.voyageGuide);
  for(const [point,text] of [[VOYAGE_START,'A · 出發／重逢'],[VOYAGE_TURN,'B · 折返']]){const label=referenceLabel(text);label.position.fromArray(point).add(new THREE.Vector3(0,3,0));this.voyageGuide.add(label)}
  document.querySelector('#launch-time').max=String(LAUNCH_DURATION);
  document.querySelector('#launch-time').oninput=e=>{this.launchTime=Number(e.target.value);this.launchActive=false;this.applyLaunch()};
  document.querySelector('#launch').onclick=()=>{this.launchTime=0;this.launchActive=true;this.missionDismissed=false;this.applyLaunch();this.onStart()};
  document.querySelector('#mission-close').onclick=()=>{this.missionDismissed=true;this.refreshMission()};
  document.querySelector('#feed-toggle').onclick=()=>this.toggleFeed();document.querySelector('#feed-close').onclick=()=>this.toggleFeed(false);document.querySelector('#feed-tab').onclick=()=>this.toggleFeed(true);
  this.sensor=new THREE.PerspectiveCamera(44,16/9,.08,160);this.target=new THREE.WebGLRenderTarget(384,216,{depthBuffer:true});this.target.texture.colorSpace=THREE.SRGBColorSpace;
  this.canvas=document.querySelector('#f8-image');this.canvas.width=384;this.canvas.height=216;this.ctx=this.canvas.getContext('2d');this.pixels=new Uint8Array(384*216*4);this.image=this.ctx.createImageData(384,216);
  this.lakeCaptureCount=0;this.lastLakePass=null;
  document.querySelector('#lake-photo').onclick=()=>document.querySelector('#lake-dialog').showModal();document.querySelector('#lake-photo-close').onclick=()=>document.querySelector('#lake-dialog').close();
  loadScenicPhoto().then(saved=>{if(saved?.uri&&saved.frameVersion===6&&saved.assetId===this.landmark?.lake.assetId)this.showLakePhoto(saved)}).catch(()=>{});
  for(const id of ['satellite-height','scenic-camera-mode'])document.querySelector('#'+id).addEventListener('change',()=>this.markPhotoSettingsChanged());
  this.applyLaunch();document.body.classList.add('has-feed');
 }
 flame(radius,length){const mesh=new THREE.Mesh(new THREE.ConeGeometry(radius,length,20),new THREE.MeshBasicMaterial({color:0xffbd65,transparent:true,opacity:.9}));mesh.rotation.z=Math.PI;mesh.position.y=-length/2;const group=new THREE.Group();group.add(mesh);return group}
 setFocus(kind){this.missionRequested=kind==='launch';if(this.missionRequested)this.missionDismissed=false;if(kind==='ship'&&(this.voyage===null||this.voyage>=1))this.spacewalk?.preview();this.refreshMission()}
 refreshMission(){document.querySelector('.mission').hidden=this.missionDismissed||!(this.missionRequested||this.launchActive)}
 applyLaunch(){const p=launchPose(this.launchTime);this.booster.position.fromArray(p.boost);this.booster.rotation.z=p.angle;this.upper.position.fromArray(p.upper);this.upper.visible=p.upperVisible;this.upper.rotation.z=p.t<11?p.angle:-.25;this.boostFlame.visible=p.flame;this.upperFlame.visible=p.upperFlame;
  if(this.twinBerth){this.booster.position.x+=2.65;this.upper.position.x+=2.65}
  for(const leg of this.legs){const i=Number(leg.name.at(-1)),a=i*Math.PI/2;leg.quaternion.setFromAxisAngle(new THREE.Vector3(-Math.sin(a),0,Math.cos(a)),THREE.MathUtils.lerp(2.85,.6,p.legs))}
  document.querySelector('#launch-phase').textContent=p.phase;document.querySelector('#launch-stamp').textContent=p.t.toFixed(1)+' s';if(document.activeElement!==document.querySelector('#launch-time'))document.querySelector('#launch-time').value=String(p.t);
  this.refreshMission();document.body.dataset.launch=JSON.stringify({time:p.t,phase:p.phase,landed:p.landed,legs:p.legs,booster:this.booster.position.toArray(),upper:this.upper.position.toArray(),upperVisible:p.upperVisible,reservedForTwins:!!this.twinBerth});
 }
 setTwinBerth(enabled){
  if(!!this.twinBerth===enabled)return;
  if(enabled){this.savedLaunch={time:this.launchTime,active:this.launchActive,requested:this.missionRequested,dismissed:this.missionDismissed};this.launchTime=0;this.launchActive=false;this.missionRequested=false;this.missionDismissed=true}
  else if(this.savedLaunch){const s=this.savedLaunch;this.launchTime=s.time;this.launchActive=s.active;this.missionRequested=s.requested;this.missionDismissed=s.dismissed;this.savedLaunch=null}
  this.twinBerth=enabled;for(const id of ['launch','launch-time'])document.querySelector('#'+id).disabled=enabled;this.applyLaunch();
 }
 setTwinMission(pose){this.twinMission=pose;if(pose){this.trail.visible=false;this.voyageGuide.visible=false;this.spacecraft.position.copy(pose.position);this.spacecraft.quaternion.copy(pose.quaternion)}}
 setVoyage(progress){this.voyage=progress;this.trail.visible=progress!==null}
 setVoyageComparison(enabled){this.voyageGuide.visible=enabled&&this.voyage!==null;this.trail.visible=enabled&&this.voyage!==null}
 voyageCameraPose(aspect){const a=new THREE.Vector3(...VOYAGE_START),b=new THREE.Vector3(...VOYAGE_TURN),points=[];for(const p of [a,b])for(const x of [-4,4])for(const y of [-4,5])for(const z of [-4,4])points.push(p.clone().add(new THREE.Vector3(x,y,z)));return comparisonCamera(points,new THREE.Vector3(1,.65,1.1),new THREE.Vector3(0,1,0),aspect)}
 hideSensorDiagrams(keep=null){const kept=new Set(Array.isArray(keep)?keep:[keep]),saved=[];this.scene.traverse(n=>{if(n.userData.sensorOverlay&&!kept.has(n)){saved.push([n,n.visible]);n.visible=false}});return ()=>{for(const [n,visible] of saved)n.visible=visible}}
 beginExperimentBroadcast(provider){if(this.broadcastProvider)return;this.broadcastProvider=provider;this.f8.broadcastActive=true;this.broadcastAutoOpened=!this.feedEnabled;this.broadcastNormal=this.f8.root.position.clone().normalize();const initial=provider?.();if(initial?.positionAtStart)this.broadcastNormal.copy(initial.anchor).normalize();this.returnBroadcastNormal=null;this.returnBroadcastState=null;this.lastFeed=-Infinity;this.toggleFeed(true);document.querySelector('#feed-title').textContent='浮鯊 / 英雄實驗轉播'}
 endExperimentBroadcast(){if(!this.broadcastProvider)return;this.broadcastProvider=null;this.f8.broadcastActive=false;this.broadcastPose=null;this.returnBroadcastNormal=this.broadcastNormal.clone();this.returnBroadcastState=null;this.broadcastNormal=null;if(this.broadcastAutoOpened&&this.feedEnabled)this.toggleFeed(false);document.querySelector('#feed-title').textContent='浮鯊 / 對地相機';document.querySelector('#feed-state').textContent='轉播已結束 · 恢復繞行';document.body.dataset.experimentBroadcast=JSON.stringify({active:false,returning:true});this.lastFeed=-Infinity}
 updateExperimentBroadcast(dt){
  const pose=this.broadcastProvider?.();this.broadcastPose=pose;if(this.f8?.maintenance?.crashed||this.f8?.maintenance?.transferActive&&!this.f8.broadcastActive){this.broadcastPose=null;this.returnBroadcastNormal=null;this.returnBroadcastState=null;return}const current=pose?this.broadcastNormal:this.returnBroadcastNormal;if(!current)return;
  const desired=pose?pose.anchor.clone().normalize():this.f8.root.position.clone().normalize();
  if(pose){const turn=new THREE.Quaternion().setFromUnitVectors(current,desired),step=new THREE.Quaternion().slerp(turn,1-Math.exp(-dt*5));current.applyQuaternion(step).normalize()}
  else{
   // Decay an offset relative to the moving nominal orbit. Chasing its world
   // position never reliably finishes, and a paused old return must not revive
   // after a maintenance transfer and pull the satellite backwards.
   this.returnBroadcastState??={offset:new THREE.Quaternion().setFromUnitVectors(desired,current),age:0};const state=this.returnBroadcastState;state.age+=dt;const u=Math.min(1,state.age/1.8),ease=u*u*(3-2*u),offset=state.offset.clone().slerp(new THREE.Quaternion(),ease);current.copy(desired).applyQuaternion(offset).normalize();if(u===1){this.returnBroadcastNormal=null;this.returnBroadcastState=null}
  }
  this.f8.root.position.copy(current).multiplyScalar(this.f8.maintenance?.currentRadius??this.f8.radius);this.f8.root.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),current);
  const angle=current.angleTo(desired);
  document.body.dataset.experimentBroadcast=JSON.stringify({active:!!pose,returning:!pose&&!!this.returnBroadcastNormal,label:pose?.label,overheadAngle:angle,satelliteRadius:this.f8.radius/18,orbitStoryPaused:!!this.f8.broadcastActive,model:'display satellite retasking; orbital story held during broadcast; nominal clock model unchanged'});
 }
 showLakePhoto(photo){this.currentPhoto=photo;document.querySelector('#lake-photo-image').src=photo.uri;document.querySelector('#lake-download').href=photo.uri;document.querySelector('#lake-download').download=photoFilename(photo.capturedAt);document.querySelector('#lake-photo').hidden=false;this.photoAvailable=true;document.querySelector('#lake-photo-meta').textContent=photoTimestamp(photo.capturedAt)+' · '+photo.width+' × '+photo.height+' PNG · 場景 T+'+photo.elapsed.toFixed(1)+'s · 衛星 '+photo.satelliteRadius.toFixed(2)+' R · '+(photo.cameraMode==='fixed'?'固定鏡頭':'全湖自動變焦')+' '+photo.fov.toFixed(2)+'°'+(photo.sighting!=='none'?' · 拍到卡皮超拉'+(photo.sighting==='hover'?'懸浮':'飛過'):'');this.markPhotoSettingsChanged()}
 markPhotoSettingsChanged(){const p=this.currentPhoto;this.photoSettingsPending=!!p&&((p.referenceRadius??p.satelliteRadius)!==Number(document.querySelector('#satellite-height').value)||p.cameraMode!==document.querySelector('#scenic-camera-mode').value);document.querySelector('#lake-photo').textContent=this.photoSettingsPending?'查看上次景區快照':'查看景區快照'}
 toggleFeed(value=!this.feedEnabled){this.feedEnabled=value;document.querySelector('#f8-monitor').hidden=!value;const tab=document.querySelector('#feed-tab');tab.hidden=value;tab.setAttribute('aria-expanded',String(value));document.querySelector('#feed-toggle').textContent=value?'關閉 浮鯊衛星螢幕':'開啟 浮鯊衛星螢幕';document.querySelector('#feed-toggle').setAttribute('aria-pressed',String(value));document.body.classList.toggle('has-feed',value);document.body.dataset.feedEnabled=String(value);document.dispatchEvent(new CustomEvent('satellite-feed-visibility',{detail:value}))}
 focusPosition(kind){this.scene.updateMatrixWorld(true);if(kind==='launch')return this.booster.getWorldPosition(new THREE.Vector3());if(kind==='ship')return this.spacecraft.getWorldPosition(new THREE.Vector3());if(kind==='ufo')return this.ufo.getWorldPosition(new THREE.Vector3());return null}
 spacecraftCameraPose(){const q=this.spacecraft.quaternion,p=this.spacecraft.position;return {position:p.clone().add(new THREE.Vector3(6,4.5,7).applyQuaternion(q)),target:p.clone().add(new THREE.Vector3(0,.8,0).applyQuaternion(q)),up:new THREE.Vector3(0,1,0).applyQuaternion(q)}}
 update(elapsed,dt,{worldTime=elapsed,worldDt=dt}={}){
  if(this.launchActive&&worldDt>0){this.launchTime=Math.min(LAUNCH_DURATION,this.launchTime+worldDt);if(this.launchTime===LAUNCH_DURATION){this.launchActive=false;this.missionRequested=false}}this.applyLaunch();
  const u=ufoPose(worldTime);this.ufo.position.fromArray(u.position);this.ufo.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),this.ufo.position.clone().normalize());document.body.dataset.ufo=JSON.stringify(u);
  const pose=voyagePose(this.voyage??0),dir=new THREE.Vector3(...pose.direction).normalize();if(this.twinMission){this.spacecraft.position.copy(this.twinMission.position);this.spacecraft.quaternion.copy(this.twinMission.quaternion)}else{this.spacecraft.position.fromArray(pose.position);this.spacecraft.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1),dir)}
  this.trail.material.color.setHex(pose.returning?0x8ed6d5:0xf3cd88);
  document.body.dataset.voyage=JSON.stringify(this.twinMission?{position:this.twinMission.position.toArray(),direction:new THREE.Vector3(0,0,1).applyQuaternion(this.twinMission.quaternion).toArray(),progress:this.twinMission.progress,returning:this.twinMission.returning,asset:'twin-spacecraft'}:{...pose,asset:'twin-spacecraft'});
  this.spacewalk?.update(worldDt,!!this.twinMission||this.voyage!==null&&this.voyage<1);
  this.updateExperimentBroadcast(dt);
  if(this.f8?.maintenance?.crashed){document.querySelector('#feed-state').textContent='訊號中斷 · 浮鯊衛星已墜毀';document.querySelector('#landmark-state').textContent='重新部署衛星後恢復拍攝';document.body.dataset.feed=JSON.stringify({enabled:this.feedEnabled,frames:this.feedFrames,lost:true,reason:'satellite crashed'});return}
  // Capture only while visible, capped to ~6 simulated frames/s. Main orbit camera is untouched.
  const landmarkState=this.broadcastProvider||this.returnBroadcastNormal||this.f8?.maintenance?.transferActive?null:this.landmark?.lake.state(this.landmark.orbiter,elapsed),needsSnapshot=landmarkState?.capture&&this.lastLakePass!==landmarkState.passId;
  document.querySelector('#landmark-state').textContent=this.broadcastPose?'實驗實況 · '+this.broadcastPose.label:this.photoSettingsPending?'設定已改 · 下次通過更新快照':landmarkState?.near?'明水覃風景區 · 定向取景':this.photoAvailable?'已保留景區快照':'景區通過倒數 '+Math.ceil(landmarkState?.secondsToPass||0)+' s';
  if((this.feedEnabled&&(this.feedFrames===0||elapsed-this.lastFeed>=1/6))||needsSnapshot){this.capture(elapsed);this.lastFeed=elapsed}

 }
 capture(elapsed){
  this.scene.updateMatrixWorld(true);const root=this.f8.root,q=root.getWorldQuaternion(new THREE.Quaternion()),p=root.getWorldPosition(new THREE.Vector3()),normal=new THREE.Vector3(0,1,0).applyQuaternion(q);
  this.sensor.position.copy(p).addScaledVector(normal,-.18);this.sensor.up.set(0,0,1).applyQuaternion(q);this.sensor.lookAt(p.clone().addScaledVector(normal,-15));this.sensor.updateMatrixWorld(true);
  const broadcast=this.broadcastPose,landmarkState=broadcast||this.returnBroadcastNormal||this.f8?.maintenance?.transferActive?null:this.landmark?.lake.state(this.landmark.orbiter,elapsed);this.sensor.fov=landmarkState?.near?62:44;
  if(broadcast){this.sensor.up.copy(broadcast.up);this.sensor.lookAt(broadcast.target);this.sensor.updateMatrixWorld(true);let tangent=0;for(const point of broadcast.bounds){const v=point.clone().applyMatrix4(this.sensor.matrixWorldInverse);if(v.z<-.1)tangent=Math.max(tangent,Math.abs(v.y)/-v.z,Math.abs(v.x)/(-v.z*this.sensor.aspect))}this.sensor.fov=THREE.MathUtils.clamp(THREE.MathUtils.radToDeg(2*Math.atan(tangent*1.16)),20,90)}
  else if(landmarkState?.near){this.sensor.up.copy(this.landmark.lake.worldNorth());this.sensor.lookAt(this.landmark.lake.worldCenter())}this.sensor.updateProjectionMatrix();this.sensor.updateMatrixWorld(true);
  const restoreDiagrams=this.hideSensorDiagrams(broadcast?.groups||broadcast?.group);const visible=root.visible,oldTarget=this.renderer.getRenderTarget();root.visible=false;
  try{withSensorShadows(this.renderer,()=>{this.renderer.setRenderTarget(this.target);this.renderer.render(this.scene,this.sensor);this.renderer.readRenderTargetPixels(this.target,0,0,384,216,this.pixels)})}finally{restoreDiagrams();root.visible=visible;this.renderer.setRenderTarget(oldTarget)}
  for(let y=0;y<216;y++)this.image.data.set(this.pixels.subarray((215-y)*384*4,(216-y)*384*4),y*384*4);this.ctx.putImageData(this.image,0,0);this.feedFrames++;
  const local=p.clone().applyQuaternion(this.globe.quaternion.clone().invert()).normalize(),lat=THREE.MathUtils.radToDeg(Math.asin(local.z)),lon=THREE.MathUtils.radToDeg(Math.atan2(local.x,local.y));document.querySelector('#feed-position').textContent=`${lat.toFixed(1)}° / ${lon.toFixed(1)}° · T+${elapsed.toFixed(1)}s`;
  let varied=0;for(let i=4;i<this.pixels.length;i+=388)if(Math.abs(this.pixels[i]-this.pixels[0])+Math.abs(this.pixels[i+1]-this.pixels[1])>8)varied++;
  document.querySelector('#feed-state').textContent=(broadcast?'LIVE · '+broadcast.label+' · ':landmarkState?.near?'明水覃風景區 · ':'SIM LIVE · ')+this.feedFrames;document.body.dataset.feed=JSON.stringify({enabled:this.feedEnabled,frames:this.feedFrames,variedSamples:varied,latitude:lat,longitude:lon,camera_position:p.toArray(),camera_direction:this.sensor.getWorldDirection(new THREE.Vector3()).toArray(),width:384,height:216,broadcast:broadcast?.label||null,landmark:landmarkState?.near?'sun-moon-lake':null});
  if(landmarkState?.capture&&this.lastLakePass!==landmarkState.passId){this.lastLakePass=landmarkState.passId;this.captureScenicPhoto(elapsed,landmarkState)}
 }
 scenicCamera(){
  this.scene.updateMatrixWorld(true);const p=this.f8.root.getWorldPosition(new THREE.Vector3()),points=[];
  this.landmark.lake.root.traverse(node=>{if(!node.isMesh||!node.name.startsWith('irregular-sun-moon-lake'))return;const position=node.geometry.attributes.position,index=node.geometry.index,count=index?index.count:position.count,step=Math.max(1,Math.floor(count/6000));for(let i=0;i<count;i+=step)points.push(new THREE.Vector3().fromBufferAttribute(position,index?index.getX(i):i).applyMatrix4(node.matrixWorld))});
  const result=makeScenicCamera({position:p.clone().addScaledVector(p.clone().normalize(),-.18),referencePosition:this.landmark.lake.worldNormal().multiplyScalar(27-.18),target:this.landmark.lake.worldCenter(),up:this.landmark.lake.worldNorth(),points,mode:document.querySelector('#scenic-camera-mode').value});
  this.lastScenicLens=result;return result.camera;
 }
 heroSighting(camera,{checkOccluders=false}={}){
  const hero=this.landmark.hero;if(!hero)return {sighting:'none'};
  const box=new THREE.Box3().setFromObject(hero.super),center=box.getCenter(new THREE.Vector3()),ndc=center.clone().project(camera);
  if(Math.abs(ndc.x)>.9||Math.abs(ndc.y)>.9||ndc.z<=-1||ndc.z>=1||!clearPlanetSight(camera.position.toArray(),center.toArray()))return {sighting:'none'};
  if(checkOccluders){
   for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z]){const p=new THREE.Vector3(x,y,z).project(camera);if(Math.abs(p.x)>.97||Math.abs(p.y)>.97)return {sighting:'none'}}
   const direction=center.clone().sub(camera.position),distance=direction.length(),ray=new THREE.Raycaster(camera.position,direction.normalize(),.05,distance-.12),occluders=[];
   this.globe.traverseVisible(n=>{if(!n.isMesh)return;for(let a=n;a;a=a.parent)if(a===hero.super||a.userData.sensorOverlay)return;occluders.push(n)});
   if(ray.intersectObjects(occluders,false).length)return {sighting:'none'};
  }
  const sighting=hero.lastConfig?.beta===0?'hover':heroState(hero.superTime,'super').mode;
  return {sighting,position:center.toArray(),ndc:ndc.toArray(),phase:heroState(hero.superTime,'super').phase};
 }
 captureScenicPhoto(elapsed,state){
  const width=2400,height=2560,frameHeight=2440,photoCamera=this.scenicCamera(),seen=this.heroSighting(photoCamera,{checkOccluders:true});
  const restoreDiagrams=this.hideSensorDiagrams();const target=new THREE.WebGLRenderTarget(width,frameHeight,{depthBuffer:true,samples:4});target.texture.colorSpace=THREE.SRGBColorSpace;const pixels=new Uint8Array(width*frameHeight*4),oldTarget=this.renderer.getRenderTarget(),wasVisible=this.f8.root.visible;this.f8.root.visible=false;
  try{withSensorShadows(this.renderer,()=>{this.renderer.setRenderTarget(target);this.renderer.render(this.scene,photoCamera);this.renderer.readRenderTargetPixels(target,0,0,width,frameHeight,pixels)},{refresh:true})}finally{restoreDiagrams();this.f8.root.visible=wasVisible;this.renderer.setRenderTarget(oldTarget);target.dispose()}
  const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;const context=canvas.getContext('2d'),image=context.createImageData(width,frameHeight);for(let y=0;y<frameHeight;y++)image.data.set(pixels.subarray((frameHeight-1-y)*width*4,(frameHeight-y)*width*4),y*width*4);context.putImageData(image,0,0);
  const capturedAt=new Date().toISOString(),sighting=seen.sighting,satelliteRadius=this.f8.root.position.length()/18,cameraMode=this.lastScenicLens.mode;
  context.fillStyle='#102231';context.fillRect(0,frameHeight,width,height-frameHeight);context.textBaseline='alphabetic';context.font='500 42px "Microsoft JhengHei",sans-serif';context.fillStyle='#e2ece4';context.fillText('浮鯊衛星 · 明水覃風景區',44,frameHeight+48);context.textAlign='right';context.font='39px "Segoe UI",sans-serif';context.fillStyle='#e1c68e';context.fillText(photoTimestamp(capturedAt),width-44,frameHeight+48);context.textAlign='left';context.font='36px "Microsoft JhengHei",sans-serif';context.fillStyle='#bfd2d7';context.fillText('場景 T+'+elapsed.toFixed(1)+'s · 衛星 '+satelliteRadius.toFixed(2)+' R · '+(cameraMode==='fixed'?'固定鏡頭':'全湖自動變焦')+' '+photoCamera.fov.toFixed(1)+'°'+(sighting==='none'?'':' · 卡皮超拉'+(sighting==='hover'?'在湖上方懸浮':'飛越湖區')),44,frameHeight+99);
  const photo={frameVersion:6,referenceRadius:this.f8.radius/18,satelliteRadius,cameraMode,referenceFov:this.lastScenicLens.referenceFov,capturePolicy:"one scheduled scenic snapshot per pass",uri:canvas.toDataURL('image/png'),capturedAt,sighting,elapsed,passId:state.passId,assetId:this.landmark.lake.assetId,width,height,imageHeight:frameHeight,fov:photoCamera.fov};this.lakeCaptureCount++;this.showLakePhoto(photo);saveScenicPhoto(photo).catch(()=>{});
  if(sighting==='flight')document.body.dataset.flyingPhoto=JSON.stringify({captured:true,capturedAt,elapsed,sighting,hero:seen,cameraPosition:photoCamera.position.toArray(),passId:state.passId,width,height,framing:'normal scenic snapshot',capturePolicy:'one scheduled snapshot per pass, no waiting or retakes',poseChangedForPhoto:false});
  document.body.dataset.lake=JSON.stringify({captured:true,capturedAt,sighting,satelliteRadius,cameraMode,referenceFov:this.lastScenicLens.referenceFov,capturePolicy:'one scheduled scenic snapshot per pass',passId:state.passId,captures:this.lakeCaptureCount,elapsed,width,height,format:'image/png',aspect:width/height,fieldOfView:photoCamera.fov,framing:cameraMode==='fixed'?'fixed lens calibrated at 1.50 R':'automatic complete lake with 4% shoreline margin',source:'Independent high-resolution floating-shark satellite perspective render of original 3D scene'});
  return true;
 }

}
