import {deviceViewport,viewportTask,watchDeviceViewport} from './device-viewport.mjs?v=b484b6b41e6f';
const MARGIN=12,STORAGE_KEY='planet-floating-panels-v1';
export const LEGACY_PANELS=[{key:'launch',selector:'.mission',handle:':scope > div',label:'發射控制'},{key:'feed',selector:'#f8-monitor',handle:'.monitor-head',label:'衛星小螢幕'},{key:'rescue',selector:'#rescue-monitor',handle:'.monitor-head',label:'回憶播放螢幕'}];
export function constrainPanelPosition(point,size,viewport,margin=MARGIN){
 const limit=(v,edge,span)=>Math.min(Math.max(margin,edge-span-margin),Math.max(margin,v));
 const p={x:limit(point.x,viewport.width,size.width),y:limit(point.y,viewport.height,size.height)};
 if(point.edge==='left')p.x=0;else if(point.edge==='right')p.x=Math.max(0,viewport.width-size.width);else if(point.edge==='bottom')p.y=Math.max(0,viewport.height-size.height);
 return p;
}
// Defaults are anchors inside the current browser viewport, not device presets.
export function defaultPanelPosition(key,size,view,navHeight=0){
 const bottom=view.height-size.height-navHeight-2*MARGIN;
 if(key==='scene-controls')return {x:view.width-size.width-MARGIN,y:MARGIN};
 if(key==='scene-identity')return {x:MARGIN,y:MARGIN};
 if(key==='scene-navigation')return {x:(view.width-size.width)/2,y:view.height-size.height-MARGIN};
 if(key==='feed')return {x:MARGIN,y:bottom};
 if(key==='rescue')return {x:MARGIN,y:MARGIN};
 if(key==='launch')return {x:(view.width-size.width)/2,y:bottom};
 return null;
}

export class FloatingPanels{
 constructor({configs=LEGACY_PANELS,storageKey=STORAGE_KEY}={}){
  this.storageKey=storageKey;
  this.entries=[];this.positions={};this.drag=null;this.pending=false;this.layer=10;
  try{const saved=JSON.parse(sessionStorage.getItem(storageKey)||'{}');for(const {key} of configs)if(Number.isFinite(saved[key]?.x)&&Number.isFinite(saved[key]?.y))this.positions[key]=saved[key]}catch{}
  for(const config of configs){
   const panel=document.querySelector(config.selector),handle=config.handle===':scope'?panel:panel?.querySelector(config.handle);if(!handle)continue;
   const original=Object.fromEntries(['position','left','top','right','bottom','transform','margin','zIndex'].map(key=>[key,panel.style[key]])),entry={...config,panel,handle,original};this.entries.push(entry);
   panel.classList.add('floating-panel');handle.classList.add('floating-panel-handle');handle.tabIndex=0;handle.setAttribute('role','group');handle.setAttribute('aria-label',config.label+'：拖曳移動，方向鍵微調，Home 還原位置');handle.title='拖曳移動面板；方向鍵微調，Home 還原位置';
   const grip=document.createElement('span');grip.className='panel-move-grip';grip.textContent='⠿';grip.setAttribute('aria-hidden','true');handle.prepend(grip);
   if(!config.noReset){const reset=document.createElement('button');reset.type='button';reset.className='panel-position-reset';reset.textContent='↺';reset.title='還原位置';reset.setAttribute('aria-label','還原'+config.label+'位置');reset.onclick=()=>this.reset(entry);handle.insertBefore(reset,handle.querySelector('#mission-close,#feed-close,#rescue-close,[data-panel-collapse]'))}
   handle.addEventListener('pointerdown',e=>this.start(entry,e));handle.addEventListener('pointermove',e=>this.move(entry,e));
   for(const event of ['pointerup','pointercancel','lostpointercapture'])handle.addEventListener(event,e=>this.finish(entry,e));
   handle.addEventListener('keydown',e=>this.key(entry,e));
  }
  this.layoutTask=viewportTask(()=>{for(const entry of this.entries)this.layoutEntry(entry);document.dispatchEvent(new CustomEvent('floating-panels-layout'))});this.schedule=this.layoutTask.queue;
  this.resizeObserver=new ResizeObserver(this.schedule);this.visibilityObserver=new MutationObserver(records=>{if(records.some(r=>r.oldValue!==r.target.getAttribute('hidden')))this.schedule()});
  for(const {panel} of this.entries){this.resizeObserver.observe(panel);this.visibilityObserver.observe(panel,{attributes:true,attributeFilter:['hidden'],attributeOldValue:true})}
  this.viewportEvents=watchDeviceViewport(this.schedule);document.addEventListener('scene-viewport-change',this.schedule);this.schedule();
 }
 save(){try{sessionStorage.setItem(this.storageKey,JSON.stringify(this.positions))}catch{}}
 layoutEntry(entry){
  if(!entry.panel.getClientRects().length)return;const point=this.positions[entry.key];if(point){this.place(entry,point,true);return}
  const bounds=entry.panel.getBoundingClientRect(),view=deviceViewport(),nav=document.querySelector('nav[aria-label="宇宙視角"]'),navHeight=nav&&!nav.hidden?nav.getBoundingClientRect().height:44;
  const desired=defaultPanelPosition(entry.key,bounds,view,navHeight)||{x:bounds.left-view.left,y:bounds.top-view.top,...(entry.dockEdge?{edge:entry.dockEdge}:{})};this.place(entry,desired,false,false);
 }
 place(entry,point,reflow=false,remember=true){
  const {panel}=entry;if(!panel.getClientRects().length)return;
  Object.assign(panel.style,{position:'fixed',right:'auto',bottom:'auto',transform:'none',margin:'0'});
  const bounds=panel.getBoundingClientRect(),view=deviceViewport(),spanX=Math.max(0,view.width-bounds.width-2*MARGIN),spanY=Math.max(0,view.height-bounds.height-2*MARGIN),desired=reflow&&Number.isFinite(point.rx)?{x:MARGIN+point.rx*spanX,y:MARGIN+point.ry*spanY}:point,edge=entry.dockEdge==='bottom'?'bottom':entry.dockEdge?(point.edge||entry.dockEdge):null,p=constrainPanelPosition({...desired,edge},bounds,view);
  if(edge)panel.dataset.edge=edge;
  panel.style.left=(view.left+p.x)+'px';panel.style.top=(view.top+p.y)+'px';if(remember)this.positions[entry.key]={...p,rx:spanX?(p.x-MARGIN)/spanX:0,ry:spanY?(p.y-MARGIN)/spanY:0,...(edge?{edge}:{})};
 }
 reset(entry){Object.assign(entry.panel.style,entry.original);delete this.positions[entry.key];if(entry.dockEdge){entry.panel.dataset.edge=entry.dockEdge;const view=deviceViewport(),r=entry.panel.getBoundingClientRect();this.place(entry,{x:entry.dockEdge==='bottom'?(view.width-r.width)/2:0,y:view.height*(entry.dockY??.26),edge:entry.dockEdge})}else this.layoutEntry(entry);this.save()}
 start(entry,event){
  if(event.button!==0||this.drag||event.target.closest('button,a,input,select,textarea,summary'))return;
  const bounds=entry.panel.getBoundingClientRect(),view=deviceViewport();this.drag={entry,id:event.pointerId,x:event.clientX,y:event.clientY,left:bounds.left-view.left,top:bounds.top-view.top,moved:false};
  entry.handle.setPointerCapture(event.pointerId);entry.handle.focus({preventScroll:true});event.preventDefault();
 }
 move(entry,event){
  const drag=this.drag;if(!drag||drag.entry!==entry||drag.id!==event.pointerId)return;
  const dx=event.clientX-drag.x,dy=event.clientY-drag.y;if(!drag.moved&&Math.hypot(dx,dy)<3)return;
  if(!drag.moved){drag.moved=true;entry.panel.classList.add('is-dragging');entry.panel.style.zIndex=String(++this.layer)}this.place(entry,{x:drag.left+dx,y:drag.top+dy,...(entry.dockEdge?{edge:entry.dockEdge==='bottom'?'bottom':event.clientX<deviceViewport().width/2?'left':'right'}:{})});event.preventDefault();
 }
 finish(entry,event){
  const drag=this.drag;if(!drag||drag.entry!==entry||drag.id!==event.pointerId)return;this.drag=null;entry.panel.classList.remove('is-dragging');
  if(entry.handle.hasPointerCapture(event.pointerId))entry.handle.releasePointerCapture(event.pointerId);if(drag.moved)this.save();
 }
 key(entry,event){
  if(event.target!==entry.handle||event.ctrlKey||event.altKey||event.metaKey)return;
  if(event.key==='Home'){event.preventDefault();this.reset(entry);return}
  const delta={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[event.key];if(!delta)return;
  event.preventDefault();const bounds=entry.panel.getBoundingClientRect(),view=deviceViewport(),step=event.shiftKey?32:8;this.place(entry,{x:bounds.left-view.left+delta[0]*step,y:bounds.top-view.top+delta[1]*step,...(entry.dockEdge?{edge:delta[0]?(delta[0]<0?'left':'right'):entry.panel.dataset.edge}:{})});this.save();
 }
}
