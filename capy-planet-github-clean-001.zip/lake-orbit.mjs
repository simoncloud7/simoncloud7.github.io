export const LAKE_PHASE=-.35,LAKE_SPEED=.075;
export function lakeOrbitState(seconds){const angle=seconds*LAKE_SPEED+LAKE_PHASE,wrapped=Math.atan2(Math.sin(angle),Math.cos(angle));return {angle,wrapped,passId:Math.round(angle/(Math.PI*2)),near:Math.abs(wrapped)<.20,capture:Math.abs(wrapped)<.04,secondsToPass:((Math.PI*2-angle%(Math.PI*2))%(Math.PI*2))/LAKE_SPEED}}
