import {normalize,dot,cross,seaDistance,pierDistance,inProtectedHarbor,HARBOR_SAFE_RADIUS} from './marine.mjs?v=487184046c10';
export const VORTEX_LIFETIME=24;
export const VORTEX_RADIUS=3.8,MIN_VORTEX_PIER_DISTANCE=HARBOR_SAFE_RADIUS+VORTEX_RADIUS;
export const ease=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
export function vortexBasis(center,start){
 let east=start.map((v,i)=>v-dot(center,start)*center[i]);if(Math.hypot(...east)<1e-8)east=cross(center,Math.abs(center[1])>.8?[1,0,0]:[0,1,0]);east=normalize(east);return {east,south:normalize(cross(east,center))};
}
export function aroundVortex(center,basis,radius,angle){
 const a=radius/18;return normalize(center.map((v,i)=>v*Math.cos(a)+(basis.east[i]*Math.cos(angle)+basis.south[i]*Math.sin(angle))*Math.sin(a)));
}
export function vortexSiteClear(c,isWater){
 if(!isWater(c)||pierDistance(c)<MIN_VORTEX_PIER_DISTANCE)return false;
 const footprint=vortexBasis(c,[0,1,0]);
 for(const r of [VORTEX_RADIUS/2,VORTEX_RADIUS])for(let j=0;j<20;j++)if(!isWater(aroundVortex(c,footprint,r,j/20*Math.PI*2)))return false;
 return true;
}
export function findOpenOceanVortex(isWater,recent=[],phase=0){
 const count=256,offset=((Math.floor(phase*137)%count)+count)%count;
 for(let k=0;k<count;k++){
  const i=(offset+k*73)%count,y=1-2*(i+.5)/count,a=i*2.399963229728653+phase*.71,r=Math.sqrt(1-y*y),c=[r*Math.cos(a),y,r*Math.sin(a)];
  if(recent.every(p=>seaDistance(c,p)>=12)&&vortexSiteClear(c,isWater))return c;
 }
 return null;
}
export function vortexPathClear(kind,center,start,escape,isWater){
 const event={kind,center,start,escape};
 for(let t=1.5;t<11.5;t+=.12){const p=vortexBoatPose(event,t).normal;if(!isWater(p)||inProtectedHarbor(p))return false}
 return true;
}
export function findVortexCenter(start,isWater,other=null,accept=null,{phase=0,recent=[]}={}){
 if(inProtectedHarbor(start))return null;
 const basis=vortexBasis(start,[0,1,0]);
 const radii=[1.6,2.2,2.8,3.6,4.4],offset=Math.floor(Math.abs(phase))%radii.length;
 for(let r=0;r<radii.length;r++)for(let i=0;i<20;i++){
  const radius=radii[(r+offset)%radii.length],c=aroundVortex(start,basis,radius,i/20*Math.PI*2+phase*2.399963);
  if(!vortexSiteClear(c,isWater)||recent.some(p=>seaDistance(c,p)<6)||other&&seaDistance(c,other)<18)continue;
  const pathClear=accept||((center)=>vortexPathClear('row',center,start,start,isWater));
  if(pathClear(c))return c;
 }return null;
}
export function vortexBoatPose(event,age){
 const t=Math.max(0,age-1.5),small=event.kind==='row',duration=small?6:5,u=Math.min(1,t/duration),initial=seaDistance(event.center,event.start),basis=vortexBasis(event.center,event.start);
 const inward=small?u:ease(u);
 let radius=initial*(1-inward)+(small?.26:initial*.5)*inward,angle=(small?4:1.6)*Math.PI*ease(u),stage=age<1.5?'approaching':small?'spiralling':'caught',depth=0;
 if(t>=duration){
  const v=(t-duration)/(small?2:4);
  if(small){radius=.26*(1-ease(v))+.07*ease(v);angle=4*Math.PI+2*Math.PI*Math.min(1,v);depth=1.7*ease(v);stage=v<1?'sinking':t<10?'lost':'respawn'}
  else{radius=initial*.5+(initial+3-initial*.5)*ease(v);angle=1.6*Math.PI+Math.PI*Math.min(1,v);stage=v<1?'escaping':'escaped'}
 }
 let normal=aroundVortex(event.center,basis,radius,angle);
 if(!small&&t>=duration){const e=ease((t-duration)/4);normal=normalize(normal.map((v,i)=>v*(1-e)+event.escape[i]*e))}
 const radial=normalize(normal.map((v,i)=>v-dot(normal,event.center)*event.center[i])),raw=cross(radial,event.center),tangent=Math.hypot(...raw)>1e-8?normalize(raw):basis.south;
 return {normal,tangent,stage,depth,hidden:stage==='lost',respawn:stage==='respawn',escaped:stage==='escaped',radius,pitch:0,roll:0,power:stage==='escaping'};
}
