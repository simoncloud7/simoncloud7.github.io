// Geometry stays local until the user opens a prefilled GitHub issue.
export class ViewportTrace{
 constructor(read,{now=()=>performance.now(),limit=96}={}){this.read=read;this.now=now;this.limit=limit;this.started=now();this.rows=[];this.last=''}
 sample(reason){
  const value=this.read(),signature=JSON.stringify(value);
  if(['poll','resize','scroll','change','dock'].includes(reason)&&signature===this.last)return;this.last=signature;
  this.rows.push({ms:Math.round(this.now()-this.started),reason,...value});
  if(this.rows.length>this.limit)this.rows.splice(1,1);
 }
 snapshot(){return this.rows.map(row=>JSON.parse(JSON.stringify(row)))}
}

export function readViewportRecord({env=globalThis,getSnapshot=()=>({})}={}){
 const d=env.document,v=env.visualViewport,host=d.querySelector('#cosmos,#universe'),canvas=host?.querySelector('canvas'),r=host?.getBoundingClientRect(),extra=getSnapshot(),size=(w,h)=>[Math.round(w||0),Math.round(h||0)];
 const tab=d.getElementById?.('scene-tab-navigation'),box=tab?.getBoundingClientRect(),style=tab&&env.getComputedStyle?.(tab),offset=size(v?.offsetLeft,v?.offsetTop);
 const dock=box?{visible:!tab.hidden&&box.width>0&&box.height>0,rect:[Math.round(box.left),Math.round(box.top),Math.round(box.width),Math.round(box.height)],padding:Math.round(parseFloat(style?.paddingBottom)||0),gap:Math.round((v?.height||env.innerHeight||0)+(v?.offsetTop||0)-box.top-box.height),edge:['bottom','left','right'].includes(tab.dataset?.edge)?tab.dataset.edge:'unknown'}:null;
 return {inner:size(env.innerWidth,env.innerHeight),outer:size(env.outerWidth,env.outerHeight),visual:v?size(v.width,v.height):null,visualOffset:offset,scale:v?Math.round(v.scale*10000)/10000:null,root:size(d.documentElement.clientWidth,d.documentElement.clientHeight),scene:r?size(r.width,r.height):null,canvas:canvas?size(canvas.width,canvas.height):null,screen:size(env.screen?.width,env.screen?.height),orientation:env.screen?.orientation?.type||env.orientation||null,focus:d.activeElement?.tagName||null,zoom:extra.framing?.zoom??null,aspect:extra.framing?.aspect??null,browserWidth:d.documentElement.style.getPropertyValue('--browser-width'),browserHeight:d.documentElement.style.getPropertyValue('--browser-height'),dock};
}

// Only allowlisted geometry enters the issue URL; never include the page query,
// diagnostic extras, form text, cookies, storage, account details or credentials.
export function buildViewportIssue({rows=[],build='local',browser='',page='/',createdAt=new Date().toISOString()}={}){
 const word=(v,n=80)=>String(v??'').replace(/[\r\n|`<>]/g,' ').slice(0,n);
 const number=v=>typeof v==='number'&&Number.isFinite(v)?String(Math.round(v*10000)/10000):'-';
 const pair=v=>Array.isArray(v)?v.slice(0,2).map(number).join('x'):'-';
 const geometry=r=>[pair(r.inner),pair(r.visual),number(r.scale),pair(r.root),pair(r.scene),pair(r.canvas),number(r.zoom),number(r.aspect),word(r.browserWidth,20)||'-',word(r.browserHeight,20)||'-',pair(r.outer),pair(r.screen),word(r.orientation,24)||'-'].join(' ');
 const unique=[];
 rows.forEach((row,index)=>{const state=geometry(row);if(!index||state!==unique.at(-1).state||index===rows.length-1)unique.push({row,state})});
 let selected=unique.length>33?[unique[0],...unique.slice(-32)]:unique;
 const dockChanges=[];
 for(const row of rows){if(!row.dock)continue;const d=row.dock,state=d.visible?[...(Array.isArray(d.rect)?d.rect.slice(0,4).map(number):['-','-','-','-']),number(d.padding),number(d.gap),pair(row.visualOffset),['bottom','left','right'].includes(d.edge)?d.edge:'unknown'].join(' '):'hidden';if(state!==dockChanges.at(-1)?.state)dockChanges.push({row,state})}
 let docks=dockChanges.length>9?[dockChanges[0],...dockChanges.slice(-8)]:dockChanges;
 const version=word(build),path=page==='./universe.html'?page:page==='./planet.html'?page:'/',title='[轉向回報] 卡皮星 '+version;
 const make=()=>{
  const body=[
   '卡皮星轉向回報：瀏覽器實際讀值，尚未判定原因。',
   '版本：'+version+'　頁面：'+path,
   '時間：'+word(createdAt)+'　瀏覽器：'+word(browser,320),
   '起點與最後狀態保留；連續相同尺寸合併。'+(unique.length>selected.length?'較早的 '+(unique.length-selected.length)+' 筆變化已省略。':''),
   'ms 為開頁後毫秒。Win=視窗，VV=可見區，Root=文件，Scene=場景，Buf=繪圖像素；其後為相機 zoom/aspect、CSS 寬高、outer、screen、方向。',
   '```text','ms event Win VV scale Root Scene Buf zoom aspect CSS-W CSS-H outer screen orientation',
   ...selected.map(({row,state})=>number(row.ms)+' '+word(row.reason,24)+' '+state),'```',
   ...(docks.length?['底部標籤：x/y/寬/高、底部留白 padding、距可見區底邊 gap、可見區偏移、停靠邊；hidden 為收起標籤未顯示。'+(dockChanges.length>docks.length?'較早的 '+(dockChanges.length-docks.length)+' 筆標籤變化已省略。':''),'```text','ms event x y width height padding gap VV-offset edge',...docks.map(({row,state})=>number(row.ms)+' '+word(row.reason,24)+' '+state),'```']:[]),
   '只含尺寸、版本與瀏覽器資訊；不含輸入內容、帳號、Cookie 或瀏覽紀錄。'
  ].join('\n');
  const url=new URL('https://github.com/simoncloud7/simoncloud7.github.io/issues/new');url.searchParams.set('title',title);url.searchParams.set('body',body);return {url:url.href,title,body};
 };
 let result=make();
 // Keep the encoded URL below 7 KB, including a long browser identification.
 // Retain the initial baseline and the newest transition sequence when trimming.
 while(result.url.length>7000&&(selected.length>2||docks.length>2)){if(selected.length>2)selected.splice(1,1);else docks.splice(1,1);result=make()}
 return result;
}

export function installViewportReport({button=null,status=null,getSnapshot=()=>({})}={}){
 const trace=new ViewportTrace(()=>readViewportRecord({getSnapshot})),timers=new Set(),listeners=[];let burst=false;
 const later=(fn,delay)=>{const id=setTimeout(()=>{timers.delete(id);fn()},delay);timers.add(id)};
 const record=reason=>{
  trace.sample(reason);if(burst)return;burst=true;
  for(const delay of [100,250,500,1000,2000,4000])later(()=>{trace.sample('poll');if(delay===4000)burst=false},delay);
 };
 const listen=(target,type)=>{const fn=()=>record(type);target?.addEventListener(type,fn,{passive:true});listeners.push(()=>target?.removeEventListener(type,fn))};
 for(const type of ['resize','orientationchange','focus','blur','pageshow'])listen(window,type);
 for(const type of ['resize','scroll'])listen(window.visualViewport,type);
 listen(screen.orientation,'change');listen(document,'visibilitychange');record('initial');
 const dock=document.getElementById('scene-tab-navigation');
 if(dock&&typeof MutationObserver!=='undefined'){
  const observer=new MutationObserver(changes=>{if(changes.some(change=>change.oldValue!==dock.getAttribute(change.attributeName)))record('dock')});
  observer.observe(dock,{attributes:true,attributeFilter:['hidden','style','data-edge'],attributeOldValue:true});listeners.push(()=>observer.disconnect());
 }
 const debug=new URLSearchParams(location.search).has('viewport-report');
 if(debug&&!button){button=document.createElement('button');document.body.append(button)}
 if(button){
  button.type='button';button.textContent=debug?'轉向後，回報到 GitHub':'回報到 GitHub';
  if(debug){document.body.append(button);button.id='viewport-report';button.style.cssText='position:fixed;z-index:20001;top:12px;left:12px;max-width:calc(100% - 24px);min-height:48px;padding:10px 16px;border:1px solid #d5c28f;border-radius:10px;background:#193340;color:#fff;font:17px/1.5 sans-serif;touch-action:manipulation'}
  button.onclick=()=>{
   trace.sample('report');const report=buildViewportIssue({rows:trace.snapshot(),build:document.body.dataset.build||'local',browser:navigator.userAgent,page:location.pathname});
   window.open(report.url,'_blank','noopener,noreferrer');
   if(status)status.textContent='已開啟填好的 GitHub 回報；按 Create／建立後才會儲存。';
   let next=document.querySelector('#viewport-report-next');
   if(!next){next=document.createElement('a');next.id='viewport-report-next';next.textContent='若未開啟，點此前往 GitHub';next.target='_blank';next.rel='noopener noreferrer';next.style.cssText='display:block;color:#e4c985;font:16px/1.7 sans-serif';button.after(next)}
   next.href=report.url;
   if(debug)next.style.cssText='position:fixed;z-index:20001;top:76px;left:12px;padding:8px;background:#193340;color:white;font:16px/1.5 sans-serif';
  };
  if(!debug){const local=document.createElement('button');local.type='button';local.textContent='查看本機回報圖';local.onclick=showReport;button.after(local)}
 }
 if(status)status.textContent='轉向後按回報，GitHub 會填好資料；再按 Create／建立即可儲存。需登入 GitHub，送出後會公開在你的儲存庫。';

 function showReport(){
  trace.sample('report');const rows=trace.snapshot(),chosen=rows.length>40?[rows[0],...rows.slice(-39)]:rows;
  const out=document.createElement('canvas');out.width=1600;out.height=350+chosen.length*35;const ctx=out.getContext('2d');
  ctx.fillStyle='#0b1826';ctx.fillRect(0,0,out.width,out.height);ctx.fillStyle='#ecf3ed';ctx.font='bold 34px sans-serif';ctx.fillText('卡皮星 · 轉向回報',24,48);
  ctx.font='22px sans-serif';ctx.fillText('版本 '+(document.body.dataset.build||'local')+' · '+location.pathname,24,86);
  ctx.font='18px monospace';const ua=navigator.userAgent;for(let i=0;i<ua.length;i+=140)ctx.fillText(ua.slice(i,i+140),24,120+(i/140)*24);
  const last=chosen.at(-1);ctx.font='18px monospace';ctx.fillText('outer '+last.outer.join('x')+' | screen '+last.screen.join('x')+' | orientation '+last.orientation,24,166);
  ctx.font='22px sans-serif';ctx.fillText('Win：視窗　Visual：可見區　Scale：頁面縮放　Root：文件　Scene：場景　Buffer：繪圖像素',24,200);
  ctx.fillText('每列均為實際讀值；不包含輸入內容、帳號、Cookie，未自動上傳。',24,226);
  const columns=[24,110,310,505,700,805,1000,1200,1430],heads=['ms','event','Win','Visual','Scale','Root','Scene','Buffer','Zoom'];
  ctx.fillStyle='#e4c985';ctx.font='21px monospace';heads.forEach((v,i)=>ctx.fillText(v,columns[i],276));
  const pair=v=>v?v.join('x'):'—';chosen.forEach((row,index)=>{const y=315+index*35;ctx.fillStyle=index%2?'#142639':'#102030';ctx.fillRect(12,y-25,1576,34);ctx.fillStyle='#ecf3ed';ctx.font='21px monospace';const values=[String(row.ms),row.reason.slice(0,15),pair(row.inner),pair(row.visual),String(row.scale??'—'),pair(row.root),pair(row.scene),pair(row.canvas),row.zoom===null?'—':row.zoom.toFixed(3)];values.forEach((v,i)=>ctx.fillText(v,columns[i],y))});
  if(last.dock){ctx.fillStyle='#e4c985';ctx.font='18px sans-serif';ctx.fillText('底部標籤 '+(last.dock.visible?last.dock.rect.join(' / ')+'　padding '+last.dock.padding+'　gap '+last.dock.gap+'　VV-offset '+last.visualOffset.join(' / '):'未顯示'),24,out.height-18)}
  // Keep the complete trace in the image's adjacent local download as well.
  const dialog=document.createElement('dialog');dialog.setAttribute('aria-label','轉向回報圖片');dialog.style.cssText='width:min(1200px,96vw);max-height:94dvh;padding:16px;background:#102030;color:white;border:1px solid #849a98;border-radius:12px;overflow:auto';
  const close=document.createElement('button');close.textContent='關閉';close.style.cssText='float:right;padding:10px 20px;font:17px sans-serif';close.onclick=()=>dialog.close();
  const note=document.createElement('p');note.textContent='請分享這一張回報圖；可以長按圖片儲存，或使用下方下載。';note.style.font='17px/1.7 sans-serif';
  const img=document.createElement('img');img.alt='卡皮星轉向前後尺寸回報';img.src=out.toDataURL('image/png');img.style.cssText='display:block;width:100%;height:auto';
  const base='卡皮星-轉向回報',download=document.createElement('a');download.textContent='下載回報圖片';download.href=img.src;download.download=base+'.png';download.style.cssText='display:inline-block;padding:12px;color:#e4c985;font:18px sans-serif';
  const data=document.createElement('a');data.textContent='下載完整尺寸記錄';data.href=URL.createObjectURL(new Blob([JSON.stringify({build:document.body.dataset.build||'local',browser:navigator.userAgent,rows},null,2)],{type:'application/json'}));data.download=base+'.json';data.style.cssText='display:inline-block;padding:12px;color:#b5d3d8;font:18px sans-serif';
  dialog.append(close,note,img,download,data);document.body.append(dialog);dialog.addEventListener('close',()=>{URL.revokeObjectURL(data.href);dialog.remove()},{once:true});dialog.showModal();
 }
 return {trace,destroy(){listeners.forEach(off=>off());for(const id of timers)clearTimeout(id)}};
}
