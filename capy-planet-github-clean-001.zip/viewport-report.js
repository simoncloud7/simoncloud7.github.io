// Local-only geometry trace. It never reads input values or sends a report.
export class ViewportTrace{
 constructor(read,{now=()=>performance.now(),limit=96}={}){this.read=read;this.now=now;this.limit=limit;this.started=now();this.rows=[];this.last=''}
 sample(reason){
  const value=this.read(),signature=JSON.stringify(value);
  if(['poll','resize','scroll','change'].includes(reason)&&signature===this.last)return;this.last=signature;
  this.rows.push({ms:Math.round(this.now()-this.started),reason,...value});
  if(this.rows.length>this.limit)this.rows.splice(1,1);
 }
 snapshot(){return this.rows.map(row=>JSON.parse(JSON.stringify(row)))}
}

export function readViewportRecord({env=globalThis,getSnapshot=()=>({})}={}){
 const d=env.document,v=env.visualViewport,host=d.querySelector('#cosmos,#universe'),canvas=host?.querySelector('canvas'),r=host?.getBoundingClientRect(),extra=getSnapshot(),size=(w,h)=>[Math.round(w||0),Math.round(h||0)];
 return {inner:size(env.innerWidth,env.innerHeight),outer:size(env.outerWidth,env.outerHeight),visual:v?size(v.width,v.height):null,scale:v?Math.round(v.scale*10000)/10000:null,root:size(d.documentElement.clientWidth,d.documentElement.clientHeight),scene:r?size(r.width,r.height):null,canvas:canvas?size(canvas.width,canvas.height):null,screen:size(env.screen?.width,env.screen?.height),orientation:env.screen?.orientation?.type||env.orientation||null,focus:d.activeElement?.tagName||null,zoom:extra.framing?.zoom??null,aspect:extra.framing?.aspect??null,browserWidth:d.documentElement.style.getPropertyValue('--browser-width'),browserHeight:d.documentElement.style.getPropertyValue('--browser-height')};
}

export function installViewportReport({button=null,status=null,getSnapshot=()=>({})}={}){
 const trace=new ViewportTrace(()=>readViewportRecord({getSnapshot})),timers=new Set(),listeners=[];let burst=false;
 const later=(fn,delay)=>{const id=setTimeout(()=>{timers.delete(id);fn()},delay);timers.add(id)};
 const record=reason=>{
  trace.sample(reason);if(burst)return;burst=true;
  for(const delay of [100,250,500,1000,2000,4000])later(()=>{trace.sample('poll');if(delay===4000)burst=false},delay);
 };
 const listen=(target,type)=>{const fn=()=>record(type);target?.addEventListener(type,fn,{passive:true});listeners.push(()=>target?.removeEventListener(type,fn))};
 for(const type of ['resize','orientationchange','focus','blur','pageshow'])listen(window,type);
 for(const type of ['resize','scroll'])listen(window.visualViewport,type);
 listen(screen.orientation,'change');listen(document,'visibilitychange');record('initial');
 const debug=new URLSearchParams(location.search).has('viewport-report');
 if(debug&&!button){button=document.createElement('button');document.body.append(button)}
 if(button){
  button.type='button';button.textContent=debug?'轉向後，按此顯示回報圖':'產生轉向回報圖';
  if(debug){document.body.append(button);button.id='viewport-report';button.style.cssText='position:fixed;z-index:20001;top:12px;left:12px;max-width:calc(100% - 24px);min-height:48px;padding:10px 16px;border:1px solid #d5c28f;border-radius:10px;background:#193340;color:#fff;font:17px/1.5 sans-serif;touch-action:manipulation'}
  button.onclick=()=>showReport();
 }
 if(status)status.textContent='自動保留轉向前後的尺寸，一次產生回報圖片；資料留在本機。';

 function showReport(){
  trace.sample('report');const rows=trace.snapshot(),chosen=rows.length>40?[rows[0],...rows.slice(-39)]:rows;
  const out=document.createElement('canvas');out.width=1600;out.height=350+chosen.length*35;const ctx=out.getContext('2d');
  ctx.fillStyle='#0b1826';ctx.fillRect(0,0,out.width,out.height);ctx.fillStyle='#ecf3ed';ctx.font='bold 34px sans-serif';ctx.fillText('卡皮星 · 轉向回報',24,48);
  ctx.font='22px sans-serif';ctx.fillText('版本 '+(document.body.dataset.build||'local')+' · '+location.pathname,24,86);
  ctx.font='18px monospace';const ua=navigator.userAgent;for(let i=0;i<ua.length;i+=140)ctx.fillText(ua.slice(i,i+140),24,120+(i/140)*24);
  const last=chosen.at(-1);ctx.font='18px monospace';ctx.fillText('outer '+last.outer.join('x')+' | screen '+last.screen.join('x')+' | orientation '+last.orientation,24,166);
  ctx.font='22px sans-serif';ctx.fillText('Win：視窗　Visual：可見區　Scale：頁面縮放　Root：文件　Scene：場景　Buffer：繪圖像素',24,200);
  ctx.fillText('每列均為實際讀值；不包含輸入內容、帳號、Cookie，未自動上傳。',24,226);
  const columns=[24,110,310,505,700,805,1000,1200,1430],heads=['ms','event','Win','Visual','Scale','Root','Scene','Buffer','Zoom'];
  ctx.fillStyle='#e4c985';ctx.font='21px monospace';heads.forEach((v,i)=>ctx.fillText(v,columns[i],276));
  const pair=v=>v?v.join('x'):'—';chosen.forEach((row,index)=>{const y=315+index*35;ctx.fillStyle=index%2?'#142639':'#102030';ctx.fillRect(12,y-25,1576,34);ctx.fillStyle='#ecf3ed';ctx.font='21px monospace';const values=[String(row.ms),row.reason.slice(0,15),pair(row.inner),pair(row.visual),String(row.scale??'—'),pair(row.root),pair(row.scene),pair(row.canvas),row.zoom===null?'—':row.zoom.toFixed(3)];values.forEach((v,i)=>ctx.fillText(v,columns[i],y))});
  // Keep the complete trace in the image's adjacent local download as well.
  const dialog=document.createElement('dialog');dialog.setAttribute('aria-label','轉向回報圖片');dialog.style.cssText='width:min(1200px,96vw);max-height:94dvh;padding:16px;background:#102030;color:white;border:1px solid #849a98;border-radius:12px;overflow:auto';
  const close=document.createElement('button');close.textContent='關閉';close.style.cssText='float:right;padding:10px 20px;font:17px sans-serif';close.onclick=()=>dialog.close();
  const note=document.createElement('p');note.textContent='請分享這一張回報圖；可以長按圖片儲存，或使用下方下載。';note.style.font='17px/1.7 sans-serif';
  const img=document.createElement('img');img.alt='卡皮星轉向前後尺寸回報';img.src=out.toDataURL('image/png');img.style.cssText='display:block;width:100%;height:auto';
  const base='卡皮星-轉向回報',download=document.createElement('a');download.textContent='下載回報圖片';download.href=img.src;download.download=base+'.png';download.style.cssText='display:inline-block;padding:12px;color:#e4c985;font:18px sans-serif';
  const data=document.createElement('a');data.textContent='下載完整尺寸記錄';data.href=URL.createObjectURL(new Blob([JSON.stringify({build:document.body.dataset.build||'local',browser:navigator.userAgent,rows},null,2)],{type:'application/json'}));data.download=base+'.json';data.style.cssText='display:inline-block;padding:12px;color:#b5d3d8;font:18px sans-serif';
  dialog.append(close,note,img,download,data);document.body.append(dialog);dialog.addEventListener('close',()=>{URL.revokeObjectURL(data.href);dialog.remove()},{once:true});dialog.showModal();
 }
 return {trace,destroy(){listeners.forEach(off=>off());for(const id of timers)clearTimeout(id)}};
}
