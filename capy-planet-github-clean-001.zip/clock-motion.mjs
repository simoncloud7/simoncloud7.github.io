import {C,REFERENCE_RADIUS} from './relativity.mjs?v=9530a88e453c';

// This circular comparison path is held at fixed radius; it is not a free orbit.
// v_local = r dphi / (sqrt(1-rs/r) dt_infinity).
export function clockAngularRate(beta,rho,compactness=0){
 if(!Number.isFinite(beta)||Math.abs(beta)>=1||!Number.isFinite(rho)||rho<1||!Number.isFinite(compactness)||compactness<0||compactness>=1)throw RangeError('Exterior sublight clock path required');
 return beta*C/(REFERENCE_RADIUS*rho)*Math.sqrt(1-compactness/rho);
}
export function clockSceneRadius(experiment,withGravity,rho){return experiment==='clocks'&&!withGravity?1.5:rho}
export function clockDialPeriod(timeScale){return timeScale<.1?.1:1}
