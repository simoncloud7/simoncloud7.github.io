import * as THREE from 'three';
import {lightPerformanceState,lightRaceState,lightCameraBlend,rulerTrailStrength,heroMotionProfile,advanceHeroTime,LIGHT_FREEZE_FRAME,LIGHT_RACE_DISTANCE} from './light-space.mjs?v=c38a92d35e93';
import {setFlightPose,setGaitPose,isHeroCloth} from './hero-style.js?v=c38a92d35e93';
import {comparisonCamera} from './comparison-view.js?v=c38a92d35e93';
import {clothRipple} from './cape-motion.mjs?v=c38a92d35e93';
import {StarterSignal} from './starter-signal.js?v=c38a92d35e93';
import {ExperimentStage} from './experiment-stage.js?v=c38a92d35e93';
import {RunnerAfterimages} from './runner-afterimages.js?v=c38a92d35e93';
import {visibleExperimentPoints} from './experiment-captions.js?v=c38a92d35e93';

const clamp=x=>Math.max(0,Math.min(1,x));
export class LightSpaceExperiment{
 constructor({globe,onReplay,onCaptions=()=>{}}){
  this.globe=globe;this.onReplay=onReplay;this.onCaptions=onCaptions;this.time=0;this.mode='speed';this.ready=false;this.presentationRates={speed:4,length:4};
  this.group=new THREE.Group();this.group.userData.sensorOverlay=true;this.group.visible=false;globe.add(this.group);
  this.sources=[];this.pulses=[];this.receivers=[];this.rulers=[];this.beams=[];
  for(let i=0;i<2;i++){
   const color=i?0xffc45d:0x56daf4;
   const source=new THREE.Group(),housing=new THREE.Mesh(new THREE.BoxGeometry(.16,.18,.2),new THREE.MeshStandardMaterial({color})),lens=new THREE.Mesh(new THREE.SphereGeometry(.065,12,8),new THREE.MeshBasicMaterial({color}));
   lens.position.y=-.11;source.add(housing,lens);this.sources.push(source);
   const pulse=new THREE.Mesh(new THREE.SphereGeometry(.12,16,12),new THREE.MeshBasicMaterial({color}));this.group.add(pulse);this.pulses.push(pulse);
   const beam=new THREE.Mesh(new THREE.CylinderGeometry(.022,.022,1,8,1,true),new THREE.MeshBasicMaterial({color,transparent:true,opacity:.85,depthWrite:false}));this.group.add(beam);this.beams.push(beam);
   const receiver=new THREE.Mesh(new THREE.RingGeometry(.17,.26,24),new THREE.MeshBasicMaterial({color,side:THREE.DoubleSide,transparent:true,opacity:.4}));this.group.add(receiver);this.receivers.push(receiver);
   const ruler=new THREE.Group(),mat=new THREE.MeshStandardMaterial({color,roughness:.55});
   for(const z of [-.22,.22]){const rail=new THREE.Mesh(new THREE.BoxGeometry(1,.045,.045),mat);rail.position.z=z;ruler.add(rail)}
   for(const x of [-.5,.5]){const cap=new THREE.Mesh(new THREE.BoxGeometry(.025,.045,.48),mat);cap.position.x=x;ruler.add(cap)}
   const gripMaterial=new THREE.MeshStandardMaterial({color:i?0x85663e:0x3c6973,roughness:.9});for(const z of [-.165,.165]){const grip=new THREE.Mesh(new THREE.CylinderGeometry(.045,.045,.16,10),gripMaterial);grip.rotation.x=Math.PI/2;grip.position.set(-.5,0,z);ruler.add(grip)}
   for(let t=0;t<=10;t++){const tick=new THREE.Mesh(new THREE.BoxGeometry(.012,.055,t%5===0?.15:.08),mat);tick.position.set(t/10-.5,.025,0);ruler.add(tick)}
   this.group.add(ruler);this.rulers.push(ruler);
  }
  for(const b of document.querySelectorAll('[data-light-mode]'))b.onclick=()=>this.setMode(b.dataset.lightMode);
  document.querySelector('#hero-performance-rate').onchange=e=>this.setPlaybackRate(Number(e.target.value));
  document.querySelector('#light-replay').onclick=()=>this.replay(true);document.querySelector('#light-freeze').onclick=()=>{this.frozen=!this.frozen;if(this.frozen){this.time=LIGHT_FREEZE_FRAME;this.seedTrail=true}this.syncMode()};this.syncMode();
 }
 configure({cloneAsset,assets,mageAsset,site,paths,fable,frameAt,stage}){
  this.fable=fable;this.frameAt=frameAt;this.street=new THREE.CatmullRomCurve3(paths[0].map(([x,z])=>new THREE.Vector3(x,0,z)));this.streetLength=this.street.getLength();
  const finish=new THREE.Vector3(site.finish_before_junction[0],0,site.finish_before_junction[1]);let nearest=Infinity;for(let i=0;i<=1000;i++){const u=i/1000,d=this.street.getPointAt(u).distanceToSquared(finish);if(d<nearest){nearest=d;this.finishU=u}}
  this.audience=new ExperimentStage(stage);const frame=frameAt(...site.position);this.group.position.copy(frame.normal).multiplyScalar(18.30);this.group.quaternion.copy(frame.q);
  this.super=cloneAsset(assets['capy-super'].id,.74).root;this.runner=cloneAsset(assets['capy-speed'].id,.74).root;this.group.add(this.super,this.runner);
  this.mage=cloneAsset(mageAsset.id,.74).root;this.group.add(this.mage);this.actors=[this.mage,this.super];this.cloth=[];
  this.flightDirection=new THREE.Vector3(1,1,0).normalize();this.flightNormal=new THREE.Vector3(-1,1,0).normalize();this.flightStart=new THREE.Vector3(0,1.25,1.45);this.flightExtent=LIGHT_RACE_DISTANCE*.65;
  for(const root of [this.mage,this.super,this.runner])root.traverse(n=>{if(n.isMesh&&isHeroCloth(n.name)){n.geometry=n.geometry.clone();this.cloth.push({owner:root,mesh:n,base:n.geometry.attributes.position.array.slice()})}});
  let carpetColor=0x9a5148;this.mage.traverse(n=>{if(n.isMesh&&isHeroCloth(n.name)){n.visible=false}});
  const geometry=new THREE.PlaneGeometry(1.85,1.30,18,14);geometry.rotateX(-Math.PI/2);this.carpetBase=geometry.attributes.position.array.slice();this.carpet=new THREE.Mesh(geometry,new THREE.MeshStandardMaterial({color:carpetColor,side:THREE.DoubleSide,roughness:.85}));this.carpet.castShadow=true;this.carpet.receiveShadow=true;this.group.add(this.carpet);
  this.mage.getObjectByName('arm-1').add(this.sources[0]);this.super.getObjectByName('arm--1').add(this.sources[1]);
  for(const s of this.sources)s.position.set(0,-.67,0);
  this.afterimages=new RunnerAfterimages(this.group,this.runner,(root,stride)=>this.poseRunner(root,stride,true),{delay:.20});
  this.flag=new StarterSignal();this.group.add(this.flag.root);
  // Reserve a complete pose envelope once. Hands, feet and cloth can animate
  // inside it without repeatedly changing the caption's attachment bounds.
  this.captionEnvelopes=new Map([this.mage,this.super,this.runner].map(root=>{
   const model=root.clone(true),box=new THREE.Box3();model.position.set(0,0,0);model.quaternion.identity();model.scale.setScalar(1);
   const include=()=>{for(const p of visibleExperimentPoints(model))box.expandByPoint(p)};
   for(let i=0;i<24;i++){this.poseRunner(model,i/24*Math.PI*2,true);for(const side of [-1,1])model.getObjectByName('arm-'+side).rotation.x=-i/23*Math.PI;include()}
   for(const blend of root===this.super?[0,1]:[1]){setFlightPose(model,blend);setGaitPose(model,0,false);include()}
   box.expandByScalar(.18);for(const axis of ['x','z']){const extent=Math.max(Math.abs(box.min[axis]),Math.abs(box.max[axis]));box.min[axis]=-extent;box.max[axis]=extent}const points=[];for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z])points.push(new THREE.Vector3(x,y,z));return [root,points];
  }));this.ready=true;
 }
 replay(reframe=false){this.time=0;this.frozen=false;this.seedTrail=false;this.decorTime=0;this.lastTrailPhase=null;this.afterimages?.reset();this.emissionOrigins=null;this.openingPoints=null;this.cameraFrames=null;this.lastPhaseTime=null;this.syncMode();if(reframe&&this.group.visible)this.onReplay?.()}
 setMode(mode){this.mode=mode;this.replay(true)}
 setPlaybackRate(rate){this.presentationRates[this.mode]=Math.max(1,Math.min(4,rate));this.replay(true)}
 syncMode(){
  const speed=this.mode==='speed';
  document.querySelector('#hero-performance-rate').value=String(this.presentationRates[this.mode]);
  for(const b of document.querySelectorAll('[data-light-mode]'))b.setAttribute('aria-pressed',String(b.dataset.lightMode===this.mode));
  document.querySelector('#light-question').textContent=speed?'超拉飛得快，射出的光會更快嗎？':'電俠帶著尺跑，量起來會多長？';
  document.querySelector('#light-task').textContent=speed?'電俠揮旗後，兩盞燈同時開啟。超拉帶燈向斜上方 45° 飛，奇異巴拉留在原地照向同一方向；兩道光平行直射，比較到達時間。':'超拉懸浮揮旗，奇異巴拉拿靜止尺，電俠帶同樣的尺跑到路口前。調整跑步速度，看本星局部參考系同時量到的長度。';
  document.querySelector('#light-speed-reading').hidden=!speed;document.querySelector('#light-length-reading').hidden=speed;
  document.querySelector('#light-replay').disabled=!this.group.visible;document.querySelector('#light-freeze').disabled=!this.group.visible;document.querySelector('#light-freeze').textContent=this.frozen?'繼續演出':'定格比較';
  document.querySelector('#light-still').textContent=speed?'超拉懸停':'電俠停步';
  if(document.querySelector('.science').dataset.modelTab==='light')document.querySelector('#traveler-speed-caption').textContent=speed?'超拉本次演出速度':'電俠本次演出速度';
  for(const r of this.rulers)r.visible=!speed;for(const s of this.sources)s.visible=speed;if(this.ready){this.runner.visible=this.super.visible=true;if(this.group.visible)this.fable.setPerformance(true,false)}
 }
 isWorldFrozen(dt=0,beta=.8){return this.group.visible&&heroMotionProfile(advanceHeroTime(this.time,this.frozen?0:dt,beta,this.presentationRates[this.mode]),beta).worldFrozen}
 start(){if(!this.ready)return;this.replay();this.group.visible=true;this.fable.setPerformance(true,false);this.audience.begin();this.syncMode()}
 stop(){this.audience?.stop();this.afterimages?.reset();this.frozen=false;document.querySelector('#light-performance-phase').textContent='實驗已結束 · 主觀定格已解除';document.querySelector('#light-performance-progress').value=0;this.onCaptions(null);document.body.dataset.lightSpace=JSON.stringify({active:false});this.group.visible=false;this.fable?.setPerformance(false);this.syncMode()}
 ground(x,z){return Math.sqrt(Math.max(1,18.3**2-x*x-z*z))-18.3}
 point(object,local=new THREE.Vector3()){return this.group.worldToLocal(object.localToWorld(local.clone()))}
 holdLamp(root,x,z,phase,running,returning=false){
  root.position.set(x,this.ground(x,z)+(root===this.mage ? .42 : 0),z);root.rotation.set(0,returning?-Math.PI/2:Math.PI/2,0);
  setFlightPose(root,1);setGaitPose(root,phase,running);
  const arm=root.getObjectByName('arm-1');arm.rotation.x=-Math.PI/2;arm.rotation.z=0;
  const lamp=this.sources[root===this.mage?0:1];this.group.updateWorldMatrix(true,true);
  root.position.x+=x-this.point(lamp).x;this.group.updateWorldMatrix(true,true);
  return this.point(lamp);
 }
 routeFrame(u,reverse=false){const p=this.street.getPointAt(Math.max(0,Math.min(1,u))),d=this.street.getTangentAt(Math.max(0,Math.min(1,u))),f=this.frameAt(p.x,p.z),tangent=new THREE.Vector3(d.x,0,d.z).applyQuaternion(f.q).normalize().multiplyScalar(reverse?-1:1);return {p,f,tangent}}
 placeRoute(root,u,height,flight,reverse=false){
  const {p,f,tangent}=this.routeFrame(u,reverse),inverse=this.group.quaternion.clone().invert();root.position.copy(f.normal).multiplyScalar(18.3+height).sub(this.group.position).applyQuaternion(inverse);
  const q=flight?new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3().crossVectors(tangent,f.normal.clone().negate()).normalize(),tangent,f.normal.clone().negate())):f.q.clone().multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),Math.atan2(reverse?-this.street.getTangentAt(u).x:this.street.getTangentAt(u).x,reverse?-this.street.getTangentAt(u).z:this.street.getTangentAt(u).z)));
  root.quaternion.copy(inverse).multiply(q);return {normal:f.normal.clone().applyQuaternion(inverse),forward:tangent.clone().applyQuaternion(inverse)};
 }
 poseFlight(progress,beta,returning=false){
  const forward=this.flightDirection.clone().multiplyScalar(returning?-1:1),chest=this.flightNormal.clone().negate();
  this.super.position.copy(this.flightStart).addScaledVector(this.flightDirection,this.flightExtent*progress);this.super.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3().crossVectors(forward,chest).normalize(),forward,chest));
  setFlightPose(this.super,0,{single:beta>=.999?1:0});const arm=this.super.getObjectByName('arm--1');arm.rotation.x=-Math.PI;arm.rotation.z=0;
 }
 poseMageLamp(x){
  this.mage.position.set(x,this.ground(x,-1.4)+.42,-1.4);this.mage.rotation.set(0,Math.PI/2,0);setFlightPose(this.mage,1);setGaitPose(this.mage,0,false);const arm=this.mage.getObjectByName('arm-1');arm.rotation.x=-3*Math.PI/4;arm.rotation.z=0;
 }
 initializeEmission(beta){
  this.poseFlight(0,beta);this.startX=0;this.poseMageLamp(this.startX);
  // Align the two emission events in the planet frame; their separation is
  // transverse to the common ray direction, rather than ahead of one another.
  for(let j=0;j<12;j++){const a=this.point(this.sources[0],new THREE.Vector3(0,-.11,0)),b=this.point(this.sources[1],new THREE.Vector3(0,-.11,0));this.startX+=b.clone().sub(a).dot(this.flightDirection)/this.flightDirection.x;this.poseMageLamp(this.startX)}
  this.emissionOrigins=this.sources.map(source=>this.point(source,new THREE.Vector3(0,-.11,0)));
 }
 lightTrackPoint(index,progress){
  return this.emissionOrigins[index].clone().addScaledVector(this.flightDirection,this.flightExtent*progress);
 }
 poseRunner(root,stride,running,gait=1){
  setFlightPose(root,1);setGaitPose(root,stride,running);for(const side of [-1,1]){root.getObjectByName('leg-'+side).rotation.x*=gait;const arm=root.getObjectByName('arm-'+side);arm.rotation.x=-Math.PI/2;arm.rotation.z=-side*.25}
 }
 update(dt,beta,camera){
  if(!this.group.visible||!this.ready){this.audience?.update(dt);return}
  if(!this.frozen)this.time=advanceHeroTime(this.time,dt,beta,this.presentationRates[this.mode]);
  const state=lightPerformanceState(this.time,beta),motion=heroMotionProfile(this.time,beta),race=lightRaceState(this.time,beta),s=state.physics,speed=this.mode==='speed',routeProgress=race.runnerProgress,routeSpan=this.finishU-.02,u=.02+routeSpan*routeProgress,actor=speed?this.super:this.runner,commander=speed?this.runner:this.super;
  if(this.lastPhaseTime!==null&&state.phaseTime<this.lastPhaseTime){this.emissionOrigins=null;this.afterimages.reset()}this.lastPhaseTime=state.phaseTime;
  this.state=state;this.performer=actor;this.decorTime=(this.decorTime||0)+(motion.worldFrozen?0:dt);
  if(!this.emissionOrigins)this.initializeEmission(beta);
  const trailDistance=motion.travelProgress*routeSpan*this.streetLength,stride=trailDistance*7;
  let route;if(speed){this.poseMageLamp(this.startX);this.poseFlight(routeProgress,beta,state.returning)}else{this.holdLamp(this.mage,-.5,-.9,0,false);route=this.placeRoute(actor,u,0,false,state.returning);const gait=motion.gait;this.poseRunner(actor,stride,state.measure&&beta>0&&!race.runnerArrived||state.returning&&routeProgress>0,gait)}
  commander.position.set(-1.0,this.ground(-1,2.8)+(speed?0:1.15+.04*Math.sin(this.decorTime*2)),2.8);commander.rotation.set(0,Math.PI/2,0);setFlightPose(commander,1);setGaitPose(commander,0,false);
  const signal=state.prepare?Math.sin(this.time*7)*.35:state.phaseTime<5?-.8:0,arm=commander.getObjectByName('arm--1');arm.rotation.x=state.prepare?-2.1+signal:state.phaseTime<5?-1.5+signal:-.35;arm.rotation.z=-.15;
  this.group.updateWorldMatrix(true,true);this.flag.root.position.copy(this.point(arm,new THREE.Vector3(0,-.67,0)));this.flag.root.quaternion.copy(commander.quaternion);this.flag.root.rotateZ(.1*Math.sin(this.decorTime*5));this.flag.update(this.decorTime);
  const carpet=this.carpet.geometry.attributes.position;this.carpet.position.copy(this.mage.position);this.carpet.position.y-=.01;
  for(let i=0;i<carpet.count;i++){const x=this.carpetBase[i*3],z=this.carpetBase[i*3+2],r=clothRipple(x/.925,z/.65,this.decorTime,1);carpet.setXYZ(i,x+r.x*.1,r.height*.24,z+r.y*.1)}carpet.needsUpdate=true;this.carpet.geometry.computeVertexNormals();
  for(const {owner,mesh,base} of this.cloth){const p=mesh.geometry.attributes.position;for(let i=0;i<p.count;i++){const f=clamp((1.42-base[i*3+1])/1.02);p.setZ(i,base[i*3+2]+.025*f*Math.sin((owner===actor?this.time:this.decorTime)*7+i*.07))}p.needsUpdate=true;mesh.geometry.computeVertexNormals()}
  const displayLength=state.prepare||state.review||race.runnerArrived?s.restLength:s.movingLength;
  if(!speed){
   for(const side of [-1,1]){const arm=this.mage.getObjectByName('arm-'+side);arm.rotation.x=-Math.PI/2;arm.rotation.z=-side*.3}
   this.group.updateWorldMatrix(true,true);
   const mid=root=>[-1,1].map(side=>this.point(root.getObjectByName('arm-'+side),new THREE.Vector3(0,-.67,0))).reduce((a,b)=>a.add(b),new THREE.Vector3()).multiplyScalar(.5);
   this.rulers[0].scale.x=s.restLength*.18;this.rulers[0].position.copy(mid(this.mage));this.rulers[0].position.x+=this.rulers[0].scale.x/2;this.rulers[0].quaternion.identity();
   const hands=[-1,1].map(side=>this.point(actor.getObjectByName('arm-'+side),new THREE.Vector3(0,-.67,0))),p=hands.reduce((a,b)=>a.add(b),new THREE.Vector3()).divideScalar(hands.length),L=displayLength*.18;
   this.rulers[1].scale.x=L;this.rulers[1].position.copy(p).addScaledVector(route.forward,L/2);this.rulers[1].quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(route.forward,route.normal,new THREE.Vector3().crossVectors(route.forward,route.normal).normalize()));
  }
  if(this.lastTrailPhase!==state.phase){this.afterimages.reset();this.lastTrailPhase=state.phase}
  if(this.seedTrail&&!speed){const position=actor.position.clone(),quaternion=actor.quaternion.clone();this.afterimages.reset();for(let j=7;j>=0;j--){const distance=Math.max(0,trailDistance-j*.20),progress=distance/(routeSpan*this.streetLength),t=trailDistance>0?4+(this.time-4)*distance/trailDistance:4;this.placeRoute(actor,.02+routeSpan*progress,0,false);this.afterimages.update(actor,distance,0,beta,distance*7,rulerTrailStrength(t,beta))}actor.position.copy(position);actor.quaternion.copy(quaternion)}this.seedTrail=false;
  // A reference exposure clock measured by travelled distance gives identical
  // spatial spacing and gait samples in either direction, regardless of FPS.
  this.afterimages.update(this.runner,trailDistance,0,beta,stride,speed?0:motion.afterimageStrength);
  for(let i=0;i<2;i++){
   this.pulses[i].visible=this.beams[i].visible=speed&&state.measure;this.receivers[i].visible=speed;
   const front=this.lightTrackPoint(i,race.lightProgress),tail=this.point(this.sources[i],new THREE.Vector3(0,-.11,0)),distance=Math.max(0,front.clone().sub(tail).dot(this.flightDirection));this.pulses[i].position.copy(front);this.beams[i].position.copy(tail).addScaledVector(this.flightDirection,distance/2);this.beams[i].quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),this.flightDirection);this.beams[i].scale.y=distance;
   this.receivers[i].position.copy(this.lightTrackPoint(i,1));this.receivers[i].quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1),this.flightDirection);this.receivers[i].material.opacity=state.measure&&race.lightArrived?1:.4;
  }
  const countdown=Math.max(1,4-Math.floor(state.phaseTime)),message=state.prepare?'清場與就位 · '+countdown:state.phaseTime<5?'開始！':state.measure?(speed?(race.runnerArrived?'超拉到達比較終點 · 懸停':race.lightArrived?'兩道光同時到站 · 超拉仍在追趕':'45° 追光中 · 兩道光皆為 c'):race.runnerArrived?'電俠到站 · 停下恢復 10 m':'奔跑量尺 · 量得 '+s.movingLength.toFixed(2)+' m'):state.returning?'回到起點 · 準備看結果':speed?'結果：光源飛得快，光速仍是 c':'結果：跑步時 '+s.movingLength.toFixed(2)+' m，停下回到 10 m';
  document.querySelector('#light-performance-phase').textContent=(this.frozen?'定格 · ':'')+message+(motion.worldFrozen?' · 主觀時間定格／浮鯊轉播中':'');document.querySelector('#light-performance-progress').value=state.progress;
  const stageActors=[actor,this.mage,commander],stageSubjects=[...stageActors,this.carpet,this.flag.root,...(speed?[...this.beams,...this.pulses,...this.receivers]:this.rulers)].filter(root=>root.visible);
  const stageTargets=stageActors.map(root=>{const p=root.getWorldPosition(new THREE.Vector3());return p.addScaledVector(p.clone().normalize(),1.0)});
  const captionBounds=new Map([...this.captionEnvelopes].map(([root,points])=>{root.updateWorldMatrix(true,true);return [root,points.map(p=>p.clone().applyMatrix4(root.matrixWorld))]}));
  const mageFront=this.mage.position.clone();mageFront.x+=3.2;mageFront.y=this.ground(mageFront.x,mageFront.z)+.05;
  this.onCaptions({subjects:stageSubjects,stable:true,tracking:true,bounds:captionBounds,items:[{root:this.mage,anchor:(speed?this.sources[0]:this.rulers[0]).getWorldPosition(new THREE.Vector3()),side:speed?'front':'above',pinned:true,pinRoot:speed?this.mage:this.mage.getObjectByName('head-pivot'),pinAnchor:speed?this.group.localToWorld(mageFront):null,title:speed?'奇異巴拉 · 靜止光源':'奇異巴拉 · 靜止尺',value:speed?'0 c':s.restLength.toFixed(2)+' m',color:'#56daf4'},{root:actor,anchor:(speed?this.sources[1]:this.rulers[1]).getWorldPosition(new THREE.Vector3()),side:'above',follow:true,title:speed?'超拉 · 移動光源':'電俠 · 移動尺',value:speed?(state.prepare||state.review||race.runnerArrived?'0':beta.toFixed(3))+' c':displayLength.toFixed(2)+' m',color:'#ffc45d'}]});
  if(!this.openingPoints)this.openingPoints=this.openingFramePoints();
  if(this.frozen)this.audience.age=Math.max(this.audience.age,3.4);this.audience.update(dt,{camera,targets:stageTargets,subjects:stageSubjects,satellite:this.satellite?.root,freezeAudience:motion.worldFrozen});
  document.body.dataset.lightSpace=JSON.stringify({active:true,mode:this.mode,site:speed?'local-straight-45-degrees':'city-long-itinerary',frozen:!!this.frozen,phase:state.phase,presentationRate:this.presentationRates[this.mode],performanceSeconds:state.performanceSeconds,routeProgress,travelSceneDistance:routeProgress*(speed?this.flightExtent:this.streetLength*routeSpan),finishMap:speed?null:this.street.getPointAt(this.finishU).toArray(),rayDirection:speed?this.flightDirection.toArray():null,rayElevation:speed?45:null,worldFrozen:motion.worldFrozen,legProgress:motion.legProgress,afterimages:this.afterimages.ghosts.filter(g=>g.root.visible).length,...race,afterimageStrength:this.afterimages.strength,stationary:'capy-mage-on-cloth',commander:speed?'capy-speed-spectator':'capy-super-hover',actors:['capy-mage',speed?'capy-super':'capy-speed'],...s});
 }
 broadcastPose(){
  if(this.mode==='speed'){
   this.group.updateWorldMatrix(true,true);const points=this.flightFramePoints(),box=new THREE.Box3().setFromPoints(points),target=box.getCenter(new THREE.Vector3()),up=new THREE.Vector3(0,1,0).applyQuaternion(this.group.getWorldQuaternion(new THREE.Quaternion()));
   // A fixed side view of the flight plane; FlightSystem keeps the satellite at
   // its selected orbital radius and only aims/zooms its existing camera.
   return {label:'超拉 45° 追光挑戰',group:this.group,anchor:this.group.localToWorld(new THREE.Vector3(3,10,22)),target,up,bounds:points};
  }
  this.group.updateWorldMatrix(true,true);const opening=this.state?.prepare||this.state?.review,root=opening?this.mage:this.performer||this.mage,box=new THREE.Box3().setFromObject(root);
  if(opening){box.expandByObject(this.super);box.expandByObject(this.runner);box.expandByObject(this.carpet);box.expandByObject(this.flag.root)}else if(this.mode==='length')box.expandByObject(this.rulers[1]);
  for(const ghost of this.afterimages.ghosts)if(ghost.root.visible)box.expandByObject(ghost.root);
  const target=box.getCenter(new THREE.Vector3()),normal=this.runner.getWorldPosition(new THREE.Vector3()).normalize(),forward=new THREE.Vector3(0,0,1).applyQuaternion(this.runner.getWorldQuaternion(new THREE.Quaternion())).projectOnPlane(normal).normalize(),right=new THREE.Vector3().crossVectors(normal,forward).normalize(),bounds=[];
  for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z])bounds.push(new THREE.Vector3(x,y,z));
  return {label:'電俠奔跑量尺',group:this.group,anchor:target.clone().addScaledVector(forward,9).addScaledVector(right,5).addScaledVector(normal,8),target,up:normal,bounds};
 }

 openingFramePoints(){
  this.group.updateWorldMatrix(true,true);const box=new THREE.Box3();for(const root of [this.super,this.runner,this.mage,this.carpet,this.flag.root,...(this.mode==='length'?this.rulers:[])])box.expandByObject(root);
  const points=[];for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z])points.push(new THREE.Vector3(x,y,z));return points;
 }
 flightFramePoints(){
  const points=[...(this.openingPoints||this.openingFramePoints())];for(let i=0;i<2;i++)for(const progress of [0,1])points.push(this.group.localToWorld(this.lightTrackPoint(i,progress)));
  const displacement=this.flightDirection.clone().transformDirection(this.group.matrixWorld).multiplyScalar(this.flightExtent);
  // Include the whole traveller at the remote endpoint, not just the two dots.
  const box=new THREE.Box3().setFromObject(this.super),current=this.super.position.clone().sub(this.flightStart).applyQuaternion(this.group.getWorldQuaternion(new THREE.Quaternion()));
  for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z])points.push(new THREE.Vector3(x,y,z).sub(current).add(displacement));
  return points;
 }
 cameraPose(aspect){
  if(!this.cameraFrames||this.cameraFrames.aspect!==aspect){
   const points=this.mode==='speed'?this.flightFramePoints():[...(this.openingPoints||this.openingFramePoints())];if(this.mode!=='speed')for(let i=0;i<=36;i++){const {f}=this.routeFrame(.02+(this.finishU-.02)*i/36);for(const h of [.2,2.2])points.push(f.normal.clone().multiplyScalar(18.3+h).applyQuaternion(this.globe.quaternion))}
   const up=new THREE.Vector3(0,1,0),q=this.group.getWorldQuaternion(new THREE.Quaternion());
   this.cameraFrames={aspect,close:comparisonCamera(this.openingPoints||this.openingFramePoints(),new THREE.Vector3(1.15,.95,1.8).applyQuaternion(q),up,aspect),wide:comparisonCamera(points,this.mode==='speed'?new THREE.Vector3(.15,.45,2).applyQuaternion(q):new THREE.Vector3(.1,1,.9).applyQuaternion(this.globe.quaternion),up,aspect)};
  }
  const blend=lightCameraBlend(this.time,this.state?.physics.beta??.8),{close,wide}=this.cameraFrames,position=close.position.clone().lerp(wide.position,blend),target=close.target.clone().lerp(wide.target,blend);
  document.body.dataset.lightCamera=JSON.stringify({phaseTime:this.state?.phaseTime??0,blend,shot:blend===0?'heroes':blend===1?'wide':'transition',distance:position.distanceTo(target)});
  return {position,target};
 }
}
