import * as THREE from 'three';
import {cloudTracks,cloudPose,blocksSolarView,blocksSubjectView,cloudViewOpacity} from './cloud-drift.mjs?v=996321243fec';
const UP=new THREE.Vector3(0,1,0);
export class CloudDriftSystem{
 constructor({clouds,seed=Math.floor(Math.random()*4294967296)}){
  this.seed=seed>>>0;this.time=0;this.clearanceEnabled=false;this.subjectCount=0;this.sun=new THREE.Vector3();this.sunArray=[0,0,0];this.eye=new THREE.Vector3();this.subjectOffsets=[];const tracks=cloudTracks(clouds.length,this.seed);
  this.clouds=clouds.map(({root,p},i)=>{
   const track=tracks[i],fade={value:1},materials=new Map();root.scale.multiplyScalar(track.size);
   root.traverse(node=>{if(!node.isMesh)return;const clone=original=>{
    if(materials.has(original))return materials.get(original);const material=original.clone(),previous=original.onBeforeCompile,key=original.customProgramCacheKey();
    material.transparent=true;material.depthWrite=false;material.forceSinglePass=true;
    material.onBeforeCompile=function(shader,renderer){previous.call(this,shader,renderer);shader.uniforms.uCloudViewOpacity=fade;shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nuniform float uCloudViewOpacity;').replace('#include <opaque_fragment>','diffuseColor.a*=uCloudViewOpacity;\n#include <opaque_fragment>')};
    material.customProgramCacheKey=()=>key+'|cloud-view-opacity-1';materials.set(original,material);return material;
   };node.material=Array.isArray(node.material)?node.material.map(clone):clone(node.material)});
   root.updateWorldMatrix(true,true);const sphere=new THREE.Box3().setFromObject(root).getBoundingSphere(new THREE.Sphere()),scale=root.matrixWorld.getMaxScaleOnAxis();root.worldToLocal(sphere.center);sphere.radius/=scale;
   return {root,track,fade,materials:[...materials.values()],radius:root.position.length(),localSphere:sphere,worldSphere:new THREE.Sphere(),offset:[0,0,0],normal:new THREE.Vector3(),phase:track.phase,target:1,name:p?.name||'雲朵'};
  });this.applyPoses();
 }
 applyPoses(){for(const cloud of this.clouds){const pose=cloudPose(cloud.track,this.time,cloud.radius);cloud.root.position.set(pose.x,pose.y,pose.z);cloud.normal.copy(cloud.root.position).normalize();cloud.root.quaternion.setFromUnitVectors(UP,cloud.normal);cloud.root.rotateY(pose.yaw);cloud.phase=pose.phase}}
 advance(seconds){if(!(seconds>0))return;this.time+=seconds;this.applyPoses()}
 updateView(seconds,{enabled,camera,sunDirection,subjects=[]}){
  this.subjectCount=0;for(const subject of subjects||[])if(subject.visible!==false)this.subjectCount++;
  this.clearanceEnabled=!!enabled||this.subjectCount>0;if(this.clearanceEnabled){camera.getWorldPosition(this.eye);if(enabled)this.sun.copy(sunDirection).normalize().toArray(this.sunArray)}
  let count=0;for(const subject of subjects||[]){if(subject.visible===false)continue;const cached=this.subjectOffsets[count]??(this.subjectOffsets[count]={offset:[0,0,0],radius:0});cached.offset[0]=subject.center.x-this.eye.x;cached.offset[1]=subject.center.y-this.eye.y;cached.offset[2]=subject.center.z-this.eye.z;cached.radius=subject.radius;count++}
  for(const cloud of this.clouds){
   cloud.target=1;if(this.clearanceEnabled&&cloud.root.visible){cloud.worldSphere.copy(cloud.localSphere).applyMatrix4(cloud.root.matrixWorld);cloud.worldSphere.center.sub(this.eye).toArray(cloud.offset);if(enabled&&blocksSolarView(cloud.offset,cloud.worldSphere.radius,this.sunArray))cloud.target=.035;for(let i=0;cloud.target===1&&i<count;i++){const subject=this.subjectOffsets[i];if(blocksSubjectView(cloud.offset,cloud.worldSphere.radius,subject.offset,subject.radius))cloud.target=.035}}
   if(cloud.fade.value!==cloud.target)cloud.fade.value=cloudViewOpacity(cloud.fade.value,cloud.target,seconds);
  }
 }
 report(){return {time:this.time,seed:this.seed,clearanceEnabled:this.clearanceEnabled,subjectCount:this.subjectCount,model:'simplified spherical wind bands',clouds:this.clouds.map(c=>({name:c.name,position:c.root.position.toArray(),phase:c.phase,angularSpeed:c.track.speed,altitude:c.root.position.length()-18,viewOpacity:c.fade.value,targetOpacity:c.target}))}}
}
