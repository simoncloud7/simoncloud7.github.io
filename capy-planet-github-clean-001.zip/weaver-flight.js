import {setFlightPose,setGaitPose} from './hero-style.js?v=fb41883b52d5';
import {suspendedCapePoint} from './cape-motion.mjs?v=fb41883b52d5';

export function poseSuspendedWeaver(model,time,lift=1){
 setFlightPose(model,1);setGaitPose(model,0,false);
 const head=model.getObjectByName('head-pivot');if(head)head.rotation.x=-.04*lift;
 for(const side of [-1,1]){
  const arm=model.getObjectByName('arm-'+side),leg=model.getObjectByName('leg-'+side);
  if(arm){arm.rotation.x=lift*(-.14+.025*Math.sin(time*1.7+side));arm.rotation.z=side*.13*lift}
  if(leg){leg.rotation.x=.035*lift;leg.rotation.z=side*.045*lift}
 }
}
export function updateSuspendedCape(cloth,time,lift){
 for(const {mesh,base} of cloth){
  mesh.position.set(0,0,0);mesh.rotation.set(0,0,0);mesh.scale.set(1,1,1);
  const p=mesh.geometry.attributes.position;for(let i=0;i<p.count;i++)p.setXYZ(i,...suspendedCapePoint(base[i*3],base[i*3+1],base[i*3+2],lift,time));
  p.needsUpdate=true;mesh.geometry.computeVertexNormals();mesh.geometry.computeBoundingBox();mesh.geometry.computeBoundingSphere();
 }
}
