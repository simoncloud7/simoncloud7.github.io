const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),unit=a=>{const n=Math.hypot(...a);return a.map(v=>v/n)};
export function tidalOrbitAxes(anchor,sunDirection){
 const a=unit(anchor),sun=unit(sunDirection);let b=sun.map((v,i)=>v-dot(sun,a)*a[i]);
 if(Math.hypot(...b)<1e-8){const axis=Math.abs(a[1])<.9?[0,1,0]:[1,0,0];b=axis.map((v,i)=>v-dot(axis,a)*a[i])}
 b=unit(b);return {a,b,newPhase:Math.atan2(dot(sun,b),dot(sun,a))};
}
export const tidalWorldDirection=(phase,{a,b})=>a.map((v,i)=>v*Math.cos(phase)+b[i]*Math.sin(phase));
// Parallel stellar light, spherical satellite, geometric fraction; not an eclipse solver.
export function satelliteIllumination(satellite,observer,sunDirection){
 const view=unit(observer.map((v,i)=>v-satellite[i])),sun=unit(sunDirection);
 return Math.max(0,Math.min(1,(1+dot(view,sun))/2));
}
