import * as THREE from 'three';

// Original coral/indigo starting flag, shared as a reusable procedural prop.
export class StarterSignal{
 constructor(){
  this.root=new THREE.Group();
  const pole=new THREE.Mesh(new THREE.CylinderGeometry(.016,.021,.72,10),new THREE.MeshStandardMaterial({color:0xd7d5b9,metalness:.4,roughness:.4}));pole.position.y=.36;this.root.add(pole);
  const positions=[],colors=[];
  for(let row=0;row<3;row++)for(let col=0;col<5;col++){
   const x=.02+col*.09,y=.42+row*.095,c=new THREE.Color((row+col)%2?0xe89060:0x364b76);
   for(const [u,v] of [[0,0],[1,0],[1,1],[0,0],[1,1],[0,1]]){positions.push(x+u*.09,y+v*.095,0);colors.push(c.r,c.g,c.b)}
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geometry.computeVertexNormals();
  this.cloth=new THREE.Mesh(geometry,new THREE.MeshStandardMaterial({vertexColors:true,side:THREE.DoubleSide,roughness:.85}));this.cloth.castShadow=true;this.root.add(this.cloth);this.base=geometry.attributes.position.array.slice();
 }
 update(time){const p=this.cloth.geometry.attributes.position;for(let i=0;i<p.count;i++){const x=this.base[i*3];p.setZ(i,.035*(x/.47)*Math.sin(time*6-x*10+this.base[i*3+1]*4))}p.needsUpdate=true;this.cloth.geometry.computeVertexNormals()}
}
