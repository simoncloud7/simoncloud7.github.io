import * as THREE from 'three';

const Y=new THREE.Vector3(0,1,0),Z=new THREE.Vector3(0,0,1),PIVOT=new THREE.Vector3(0,1.10,-.30);
const REST=[57,19,-19,-57].map((degrees,row)=>{const angle=degrees*Math.PI/180,p=new THREE.Vector3(.25,[1.36,1.19,1.02,.85][row],-.34),points=[p.toArray()];for(const [reach,depth] of [[.26,-.04],[.39,.15],[.08,.47]]){p.add(new THREE.Vector3(reach*Math.cos(angle),reach*Math.sin(angle),depth));points.push(p.toArray())}return points});
export const SPIDER_TIPS=['L','R'].flatMap(side=>Array.from({length:4},(_,row)=>'spider-tip-'+side+row));
export class SpiderRig{
 constructor(root){
  this.root=root;this.harness=root.getObjectByName('spider-harness');
  this.legs=[-1,1].flatMap(side=>REST.map((row,i)=>{const key=(side<0?'L':'R')+i,points=row.map(p=>new THREE.Vector3(p[0]*side,p[1],p[2]).sub(PIVOT)),segments=[0,1,2].map(j=>root.getObjectByName('spider-segment-'+key+'-'+j)),joints=[0,1,2,3].map(j=>root.getObjectByName('spider-joint-'+key+'-'+j)),tip=root.getObjectByName('spider-tip-'+key);if(!tip||segments.some(n=>!n)||joints.some(n=>!n))throw Error('Incomplete eight-leg spider rig: '+key);return {key,side,row:i,points,segments,joints,tip,lengths:points.slice(1).map((p,j)=>p.distanceTo(points[j]))}}));
 }
 pose(time,{working=false,deploy=1,targets=[],contacts=[],contactNormal=null}={}){
  this.harness.updateWorldMatrix(true,true);this.legs.forEach((leg,i)=>{
   const points=[leg.points[0].clone()],wave=working?Math.sin(time*3.8+leg.row*1.9+leg.side*.4):Math.sin(time*1.1+leg.row)*.12;
   // Fold and articulate directions, keeping every segment's authored length.
   for(let j=0;j<3;j++){const rest=leg.points[j+1].clone().sub(leg.points[j]).normalize(),folded=new THREE.Vector3(leg.side*.12,j===0?.30:-.85,-.18).normalize(),direction=folded.lerp(rest,deploy).normalize().applyAxisAngle(Z,leg.side*wave*(j===0?.07:j===1?-.05:.035));points.push(points[j].clone().addScaledVector(direction,leg.lengths[j]))}
   let gripDirection=null;
   if(contacts[i]&&contactNormal){
    gripDirection=contactNormal.clone().transformDirection(this.harness.matrixWorld.clone().invert());const goal=this.harness.worldToLocal(contacts[i].clone()).addScaledVector(gripDirection,-.09),base=points[0].clone(),reach=leg.lengths.reduce((a,b)=>a+b,0);
    if(goal.distanceTo(base)>reach-1e-6)goal.sub(base).setLength(reach-1e-6).add(base);
    for(let iteration=0;iteration<32;iteration++){
     points[3].copy(goal);for(let j=2;j>=0;j--)points[j].sub(points[j+1]).setLength(leg.lengths[j]).add(points[j+1]);points[0].copy(base);for(let j=0;j<3;j++)points[j+1].sub(points[j]).setLength(leg.lengths[j]).add(points[j]);if(points[3].distanceToSquared(goal)<1e-12)break;
    }
   }
   leg.segments.forEach((node,j)=>{const direction=points[j+1].clone().sub(points[j]);node.position.copy(points[j]).lerp(points[j+1],.5);node.quaternion.setFromUnitVectors(Y,direction.clone().normalize());node.scale.set(1,direction.length()/leg.lengths[j],1)});
   leg.joints.forEach((node,j)=>node.position.copy(points[j]));leg.tip.position.copy(points[3]);
   if(gripDirection)leg.tip.quaternion.setFromUnitVectors(Z,gripDirection);else if(targets[i]){const goal=this.harness.worldToLocal(targets[i].clone());leg.tip.quaternion.setFromUnitVectors(Z,goal.sub(points[3]).normalize())}else leg.tip.quaternion.identity();
  });this.root.updateWorldMatrix(true,true);
 }
 emitters(){return this.legs.map(leg=>leg.tip.localToWorld(new THREE.Vector3(0,0,.09)))}
}

// Cylindrical silk remains visible from a wide shot. Each strand starts at
// its own real nozzle; the pulse travels along the same curved thread.
export class SpiderSilk{
 constructor(parent){this.group=new THREE.Group();this.group.userData.sensorOverlay=true;parent.add(this.group);const material=new THREE.MeshBasicMaterial({color:0xc8f6e9}),geometry=new THREE.CylinderGeometry(.009,.009,1,6);this.strands=Array.from({length:8},()=>{const group=new THREE.Group();this.group.add(group);const pieces=Array.from({length:16},()=>{const mesh=new THREE.Mesh(geometry,material);group.add(mesh);return mesh}),pulse=new THREE.Mesh(new THREE.SphereGeometry(.032,8,6),new THREE.MeshBasicMaterial({color:0xf6efd0}));group.add(pulse);return {group,pieces,pulse}})}
 update(origins,targets,extension,time,{active,taut=false,pulse=true}={}){
  this.group.updateWorldMatrix(true,true);this.strands.forEach((strand,i)=>{strand.group.visible=extension>.001&&(!active||active[i]);if(!strand.group.visible)return;const start=this.group.worldToLocal(origins[i].clone()),goal=this.group.worldToLocal(targets[i].clone()),end=start.clone().lerp(goal,extension),middle=start.clone().lerp(end,.5);if(!taut)middle.y-=Math.min(.12,start.distanceTo(end)*.025);const curve=new THREE.QuadraticBezierCurve3(start,middle,end),points=curve.getPoints(16);strand.pieces.forEach((mesh,j)=>{const a=points[j],b=points[j+1],d=b.clone().sub(a);mesh.position.copy(a).lerp(b,.5);mesh.quaternion.setFromUnitVectors(Y,d.clone().normalize());mesh.scale.y=Math.max(.001,d.length())});strand.pulse.visible=pulse;strand.pulse.position.copy(curve.getPoint((time*1.5+i*.13)%1))});
 }
}
