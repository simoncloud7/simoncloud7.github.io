import * as THREE from 'three';
import {solarGeometry,solarMomentDelta,solarClock,PLANET_NORTH} from './daylight.mjs?v=00deb652dc05';
const $=s=>document.querySelector(s),NORTH=new THREE.Vector3(...PLANET_NORTH);
// Approximate atmospheric fill near the surface, not a second star. Evaluate
// each fragment's location so the night hemisphere and distant satellites stay dark.
export function installDaylightFill(scene,uniforms){
 const materials=new Set();scene.traverse(n=>{for(const m of Array.isArray(n.material)?n.material:[n.material])if(m&&(m.isMeshStandardMaterial||m.isMeshLambertMaterial||m.isMeshPhongMaterial||m.isMeshToonMaterial))materials.add(m)});
 for(const m of materials){
  const previous=m.onBeforeCompile,previousKey=m.customProgramCacheKey();
  m.onBeforeCompile=function(shader,renderer){
   previous.call(this,shader,renderer);Object.assign(shader.uniforms,uniforms);
   shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nuniform float uDaylightFill;uniform vec3 uDaylightSun;uniform vec3 uDaylightCenter;');
   shader.fragmentShader=shader.fragmentShader.replace('#include <lights_fragment_begin>',`#include <lights_fragment_begin>
    vec3 skyView=geometryPosition;
    vec3 skyPosition=cameraPosition+vec3(dot(viewMatrix[0].xyz,skyView),dot(viewMatrix[1].xyz,skyView),dot(viewMatrix[2].xyz,skyView))-uDaylightCenter;
    vec3 skyUp=normalize(skyPosition);
    float skyDay=smoothstep(-.10,.30,dot(skyUp,uDaylightSun));
    float skyAtmosphere=1.-smoothstep(26.,32.,length(skyPosition));
    float skyFacing=.32+.68*max(0.,dot(inverseTransformDirection(geometryNormal,viewMatrix),skyUp));
    irradiance+=vec3(1.55,1.85,2.25)*uDaylightFill*skyDay*skyAtmosphere*skyFacing;
   `);
  };m.customProgramCacheKey=()=>previousKey+'|surface-daylight-fill-1';m.needsUpdate=true;
 }
 return materials.size;
}
export class DaylightScene{
 constructor({scene,globe,sun,stars,observer,camera}){
  Object.assign(this,{scene,globe,sun,stars,observer,camera});this.lastReport=-Infinity;
  this.fillUniforms={uDaylightFill:{value:0},uDaylightSun:{value:sun.position.clone().normalize()},uDaylightCenter:{value:new THREE.Vector3()}};
  this.fillMaterialCount=installDaylightFill(scene,this.fillUniforms);
  this.sunDisc=new THREE.Mesh(new THREE.SphereGeometry(.9,24,16),new THREE.MeshBasicMaterial({color:0xffecc0}));this.sunDisc.name='distant-stellar-disc';this.sunDisc.userData.hideFromSatelliteFeed=true;this.sunDisc.visible=false;scene.add(this.sunDisc);
  this.sky=new THREE.Mesh(new THREE.SphereGeometry(400,32,16),new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,depthTest:false,uniforms:{up:{value:new THREE.Vector3(0,1,0)},sun:{value:new THREE.Vector3(1,0,0)},horizonAngle:{value:0}},vertexShader:'varying vec3 direction;void main(){direction=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:`
   varying vec3 direction;uniform vec3 up;uniform vec3 sun;uniform float horizonAngle;
   void main(){vec3 d=normalize(direction);float h=sin(asin(clamp(dot(d,up),-1.,1.))-horizonAngle),alt=sin(asin(clamp(dot(sun,up),-1.,1.))-horizonAngle);float day=smoothstep(-.14,.09,alt);float horizon=pow(1.-max(0.,h),4.);vec3 night=mix(vec3(.0006,.0012,.004),vec3(.003,.006,.015),horizon);vec3 blue=mix(vec3(.11,.39,.83),vec3(.62,.82,.96),horizon);vec3 color=mix(night,blue,day);float dusk=(1.-smoothstep(.03,.30,abs(alt)))*smoothstep(-.32,-.02,alt);float toward=pow(max(0.,dot(d,sun)),5.);color=mix(color,vec3(.93,.36,.15),dusk*horizon*(.15+.70*toward));gl_FragColor=vec4(color,1.);
   #include <tonemapping_fragment>
   #include <colorspace_fragment>
   }
  `}));this.sky.name='surface-day-night-sky';this.sky.renderOrder=-1000;this.sky.frustumCulled=false;this.sky.userData.hideFromSatelliteFeed=true;this.sky.visible=false;scene.add(this.sky);
  for(const moment of ['sunrise','noon','sunset','midnight'])$('#sky-'+moment).onclick=()=>this.showMoment(moment);
  $('#sky-sun-view').onclick=()=>observer.aimAtSun();
  this.diagramRoots=[];scene.traverse(n=>{if(n.userData.sensorOverlay)this.diagramRoots.push(n)});
 }
 get natural(){return $('#lighting-mode').value==='natural'}
 clearSkyDiagrams(){
  if(!this.sky.visible)return ()=>{};const saved=this.diagramRoots.map(n=>n.visible);for(const n of this.diagramRoots)n.visible=false;return ()=>{this.diagramRoots.forEach((n,i)=>n.visible=saved[i])};
 }
 spinAxis(){return NORTH.clone().applyQuaternion(this.globe.getWorldQuaternion(new THREE.Quaternion())).normalize()}
 showMoment(moment){
  if(!this.natural||!this.observer.enabled||!this.observer.anchor||this.observer.followSubpoint)return false;
  const n=this.observer.anchor.clone().normalize().applyQuaternion(this.globe.getWorldQuaternion(new THREE.Quaternion())),delta=solarMomentDelta(n.toArray(),this.sun.position.toArray(),this.spinAxis().toArray(),moment,this.observer.currentPose?.geometry.horizonElevation||0);if(delta===null)return false;
  this.globe.rotateY(delta);this.observer.lastSightTime=-1;this.lastReport=-Infinity;return true;
 }
 update(elapsed,groundActive,guideActive=false){
  const sun=this.sun.position.clone().normalize(),pose=this.observer.currentPose,natural=this.natural,ground=natural&&groundActive&&!!pose;
  this.fillUniforms.uDaylightFill.value=natural?1:0;this.fillUniforms.uDaylightSun.value.copy(sun);this.globe.getWorldPosition(this.fillUniforms.uDaylightCenter.value);
  this.sunDisc.visible=natural&&(ground||!guideActive);this.sunDisc.position.copy(this.camera.position).addScaledVector(sun,120);this.sky.visible=ground;
  let state=null;if(pose)state=solarGeometry(pose.localVertical.toArray(),sun.toArray(),this.spinAxis().toArray(),pose.geometry.horizonElevation);
  if(ground){this.sky.position.copy(this.camera.position);this.sky.material.uniforms.up.value.copy(pose.localVertical);this.sky.material.uniforms.sun.value.copy(sun);this.sky.material.uniforms.horizonAngle.value=state.horizonElevation*Math.PI/180;this.stars.material.opacity=1-THREE.MathUtils.smoothstep(state.heightAboveHorizon,-16,-2)}else this.stars.material.opacity=.65;
  const reportKey=[this.observer.siteKey,this.observer.enabled,this.observer.followSubpoint,state?.elevation.toFixed(5),state?.hours?.toFixed(5)].join(':');
  if(elapsed-this.lastReport<.2&&this.lastMode===natural&&this.lastGround===ground&&(elapsed!==this.lastReport||reportKey===this.lastReportKey))return;this.lastReport=elapsed;this.lastMode=natural;this.lastGround=ground;this.lastReportKey=reportKey;
  const ready=natural&&this.observer.enabled&&!!pose,fixed=ready&&!this.observer.followSubpoint;
  $('#ground-sky-status').textContent=!natural?'在場景設定選擇「自然晝夜」，可觀看當地天空。':!pose?'選擇觀測地點後，可觀看當地日照與衛星位置。':state.period+' · 當地日照時刻 '+solarClock(state.hours)+' · 恆星仰角 '+state.elevation.toFixed(1)+'°';
  $('#ground-sky-hint').textContent=this.observer.followSubpoint?'目前視點跟隨衛星移動；先取消「自動保持在衛星正下方」，才能比較同一地點的晝夜。':'選定同一地點，比較日出、正午、日落與午夜；想停留觀看，可暫停宇宙。';
  for(const moment of ['sunrise','noon','sunset','midnight'])$('#sky-'+moment).disabled=!fixed||solarMomentDelta(pose.localVertical.toArray(),sun.toArray(),this.spinAxis().toArray(),moment,state.horizonElevation)===null;
  $('#sky-sun-view').disabled=!ready||state.heightAboveHorizon<-1e-6;
  document.body.dataset.daylight=JSON.stringify({mode:$('#lighting-mode').value,groundSky:ground,sunDirection:sun.toArray(),spinAxis:this.spinAxis().toArray(),site:this.observer.siteKey||null,followSubpoint:this.observer.followSubpoint,solar:state,starOpacity:this.stars.material.opacity,surfaceSkyFill:natural,model:'parallel stellar light; local solar geometry; illustrative atmospheric fill, sky and display periods; no eclipse solver'});
 }
}
