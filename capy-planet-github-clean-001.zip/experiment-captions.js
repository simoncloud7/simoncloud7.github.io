import * as THREE from 'three';

const overlaps=(a,b)=>a.x<b.x+b.width&&a.x+a.width>b.x&&a.y<b.y+b.height&&a.y+a.height>b.y;
export function visibleExperimentPoints(root,padding=0){
 const bounds=new THREE.Box3();root.updateWorldMatrix(true,true);const inverse=root.matrixWorld.clone().invert();root.traverseVisible(n=>{if(!n.isMesh)return;if(!n.geometry.boundingBox)n.geometry.computeBoundingBox();bounds.union(n.geometry.boundingBox.clone().applyMatrix4(inverse.clone().multiply(n.matrixWorld)))});bounds.expandByScalar(padding);const points=[];for(const x of [bounds.min.x,bounds.max.x])for(const y of [bounds.min.y,bounds.max.y])for(const z of [bounds.min.z,bounds.max.z])points.push(new THREE.Vector3(x,y,z).applyMatrix4(root.matrixWorld));return points;
}
export function visibleExperimentBounds(root){return new THREE.Box3().setFromPoints(visibleExperimentPoints(root))}
export function placeExperimentCaptions(items,blocked,width,height,labelWidth=198,labelHeight=58,previous=[]){
 const used=[...blocked],result=[];
 const reserve=p=>{result.push(p);if(p)used.push({...p,x:p.x-10,y:p.y-8,width:p.width+20,height:p.height+16})};
 for(const [i,{x,y,box,side,pinned,pinBox,pinAnchor,follow}] of items.entries()){
  // Pinned annotations stay beside their chosen attachment, instead of
  // searching for a distant free patch of scenery.
  if(pinned){const attach=pinBox||box;reserve({x:pinAnchor?pinAnchor.x-labelWidth/2:attach.x+(attach.width-labelWidth)/2,y:side==='front'?pinAnchor.y-labelHeight/2:side==='below'?attach.y+attach.height+8:attach.y-labelHeight-8,width:labelWidth,height:labelHeight});continue}
  if(follow){
   // A moving hero owns its caption's row. Obstacles may displace the text
   // sideways, but must never strand it at an earlier flight/run height.
   const row=side==='below'?box.y+box.height+18:box.y-labelHeight-18,goal=Math.max(12,Math.min(width-labelWidth-12,box.x+(box.width-labelWidth)/2)),at=cx=>({x:cx,y:row,width:labelWidth,height:labelHeight}),valid=p=>p.x>=12&&p.y>=50&&p.x+p.width<=width-12&&p.y+p.height<=height-12&&!used.some(b=>overlaps(p,b)),old=previous[i];
   if(old&&valid(at(old.x))){
    const next=at(old.x+Math.max(-6,Math.min(6,(goal-old.x)*.12))),sweep={...next,x:Math.min(old.x,next.x),width:labelWidth+Math.abs(next.x-old.x)};reserve(used.some(b=>overlaps(sweep,b))?at(old.x):next);continue;
   }
   const xs=[goal,12,width-labelWidth-12,...used.flatMap(b=>[b.x-labelWidth-2,b.x+b.width+2])],options=xs.map(at).filter(valid);options.sort((a,b)=>Math.abs(a.x-(old?.x??goal))-Math.abs(b.x-(old?.x??goal)));reserve(options[0]||null);continue;
  }
  const sameSide=p=>side==='above'?p.y+labelHeight<=box.y-10:side==='below'?p.y>=box.y+box.height+10:true;
  const valid=p=>sameSide(p)&&p.x>=12&&p.y>=50&&p.x+p.width<=width-12&&p.y+p.height<=height-12&&!used.some(b=>overlaps(p,b)),old=previous[i];
  if(old&&valid(old)){reserve(old);continue}
  const candidates=[];
  if(old){
   // If a moving obstacle reaches the caption, choose the closest clear edge
   // rather than jumping to one of the coarse global search rows.
   const xs=[Math.max(12,Math.min(width-labelWidth-12,old.x)),...used.flatMap(b=>[b.x-labelWidth-2,b.x+b.width+2])],ys=[Math.max(50,Math.min(height-labelHeight-12,old.y)),...used.flatMap(b=>[b.y-labelHeight-2,b.y+b.height+2]),side==='above'?box.y-labelHeight-18:box.y+box.height+18];
   for(const cx of xs)for(const cy of ys)candidates.push({x:cx,y:cy});
  }
  for(const gap of [18,48,88,140,210])candidates.push({x:box.x+(box.width-labelWidth)/2,y:box.y-labelHeight-gap},{x:box.x-labelWidth-gap,y:y-labelHeight/2},{x:box.x+box.width+gap,y:y-labelHeight/2},{x:box.x+(box.width-labelWidth)/2,y:box.y+box.height+gap});
  for(let cy=64;cy<height-labelHeight-20;cy+=72)for(let cx=20;cx<width-labelWidth-20;cx+=Math.max(80,labelWidth/2))candidates.push({x:cx,y:cy});
  const options=candidates.map(p=>({...p,width:labelWidth,height:labelHeight})).filter(valid),score=p=>(old?Math.hypot(p.x-old.x,p.y-old.y):0)+Math.hypot(p.x+p.width/2-x,p.y+p.height/2-y)*(old?.015:1);
  options.sort((a,b)=>score(a)-score(b));reserve(options[0]||null);
 }
 return result;
}

export class ExperimentCaptions{
 constructor(){
  this.root=document.createElement('div');this.root.className='experiment-captions';this.root.setAttribute('aria-hidden','true');this.root.hidden=true;
  this.labels=Array.from({length:2},()=>{const element=document.createElement('div'),title=document.createElement('span'),value=document.createElement('strong');element.className='experiment-caption';element.append(title,value);this.root.append(element);return {element,title,value}});document.body.append(this.root);
 }
 set(payload){if(!payload)this.placements=null;this.payload=payload;this.root.hidden=!payload}
 update(camera){
  if(!this.payload)return;const width=innerWidth,height=innerHeight,project=p=>{const v=p.clone().project(camera);return {x:(v.x+1)*width/2,y:(1-v.y)*height/2,z:v.z}},bounds=root=>{const points=(this.payload.bounds?.get(root)||visibleExperimentPoints(root,this.payload.padding||0)).map(project);const minX=Math.min(...points.map(p=>p.x)),minY=Math.min(...points.map(p=>p.y));return {x:minX-10,y:minY-10,width:Math.max(...points.map(p=>p.x))-minX+20,height:Math.max(...points.map(p=>p.y))-minY+20}};
  const blocked=this.payload.subjects.map(bounds);for(const selector of ['.intro','#controls-dock','#f8-monitor','nav','header']){const element=document.querySelector(selector);if(element&&!element.hidden){const r=element.getBoundingClientRect();if(r.width&&r.height)blocked.push({x:r.x-8,y:r.y-8,width:r.width+16,height:r.height+16})}}
  const items=this.payload.items.map(item=>({...project(item.anchor),box:bounds(item.root),pinBox:item.pinRoot?bounds(item.pinRoot):null,pinAnchor:item.pinAnchor?project(item.pinAnchor):null,side:item.side,pinned:!!item.pinned,follow:!!item.follow})),sameRoots=this.lastRoots?.length===items.length&&this.lastRoots.every((r,i)=>r===this.payload.items[i].root);let previous=this.payload.stable&&sameRoots?this.placements||[]:[];
  if(this.payload.tracking&&sameRoots&&this.lastItems&&this.lastViewport===width+':'+height)previous=previous.map((p,i)=>{
   if(!p||items[i].pinned)return p;const box=items[i].box,old=this.lastItems[i].box,tracked={...p,x:p.x+box.x+box.width/2-old.x-old.width/2,y:p.y+box.y+box.height/2-old.y-old.height/2};if(items[i].follow)return tracked;if(items[i].side==='above')tracked.y=Math.min(tracked.y,box.y-58-18);if(items[i].side==='below')tracked.y=Math.max(tracked.y,box.y+box.height+18);
   // Once the whole return path is clear, ease back beside the actor rather
   // than leaving a collision-avoidance offset stranded over distant scenery.
   const goal={x:box.x+(box.width-198)/2,y:items[i].side==='below'?box.y+box.height+18:box.y-58-18},sweep={x:Math.min(tracked.x,goal.x),y:Math.min(tracked.y,goal.y),width:198+Math.abs(tracked.x-goal.x),height:58+Math.abs(tracked.y-goal.y)},obstacles=[...blocked,...(this.placements||[]).filter((other,j)=>other&&j!==i)];
   if(goal.x>=12&&goal.y>=50&&goal.x+198<=width-12&&goal.y+58<=height-12&&!obstacles.some(b=>overlaps(sweep,b))){const dx=goal.x-tracked.x,dy=goal.y-tracked.y,step=Math.min(.08,6/Math.max(1,Math.abs(dx),Math.abs(dy)));tracked.x+=dx*step;tracked.y+=dy*step}return tracked;
  });
  const placements=placeExperimentCaptions(items,blocked,width,height,198,58,previous);this.placements=placements;this.lastRoots=this.payload.items.map(i=>i.root);this.lastItems=items;this.lastViewport=width+':'+height;
  document.body.dataset.experimentCaptions=JSON.stringify({items,blocked,placements,stable:!!this.payload.stable,tracking:!!this.payload.tracking});
  this.labels.forEach((label,i)=>{const item=this.payload.items[i],p=placements[i],anchor=items[i],visible=!!p&&anchor.z>=-1&&anchor.z<=1&&anchor.x>=0&&anchor.x<=width&&anchor.y>=0&&anchor.y<=height;label.element.hidden=!visible;if(!visible)return;label.title.textContent=item.title;label.value.textContent=item.value;label.element.style.transform=`translate(${p.x}px,${p.y}px)`;label.element.style.borderColor=item.color;});
 }
}
