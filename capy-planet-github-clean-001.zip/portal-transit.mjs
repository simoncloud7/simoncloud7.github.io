import {foldedPoint} from './interstellar.mjs?v=3f5a2fef0fc5';

// Mouth orientation is independent of the folded sheet's slope. The two short
// access corridors lead toward the destination. A tightly folded diagram can
// compress their drawn scale, while physical access lengths and clocks stay fixed.
export function portalLayout(config,scale=1.7,lane=-1.1,destinationOverride=null){
 const at=s=>foldedPoint(s,lane,config.distance,config.fold).map(v=>v*scale),source=at(-config.distance/2),destination=destinationOverride||at(config.distance/2),delta=destination.map((v,i)=>v-source[i]),length=Math.hypot(delta[0],delta[2]);
 const forward=[delta[0]/length,0,delta[2]/length],accessDraw=Math.min(config.access*scale,length*.28),accessScale=config.access?accessDraw/config.access:scale,entry=source.map((v,i)=>v+forward[i]*accessDraw),exit=destination.map((v,i)=>v-forward[i]*accessDraw);
 exit[1]=entry[1];
 const exitDrawScale=config.access?Math.hypot(...destination.map((v,i)=>v-exit[i]))/config.access:scale;
 return {scale,accessScale,accessDraw,exitDrawScale,access:config.access,source,destination,entry,exit,entryFacing:forward,exitFacing:forward.map(v=>-v),forward,up:[0,1,0]};
}
export function portalExteriorPoint(layout,side,offset){if(side==='exit'&&offset>=0&&layout.access)return layout.exit.map((v,i)=>v+(layout.destination[i]-v)*offset/layout.access);return layout[side].map((v,i)=>v+layout.forward[i]*offset*layout.accessScale)}

// A longitudinal coordinate diagram, not a Euclidean isometric embedding.
// l is radial proper distance; r(l) is the areal radius of each drawn ring.
export function throatSection(l,b=1){if(!Number.isFinite(l)||!(b>0))throw RangeError('Finite distance and positive throat radius required');return {center:[l,0,0],radius:Math.hypot(b,l)}}
export {capeFlight} from './cape-motion.mjs?v=3f5a2fef0fc5';

// Extended display figures cross the mouth planes; the timed worldline stays at their centre.
// This helper never changes journey distances, velocities or elapsed/proper times.
export function portalBodyState(config,state,halfSpan=.95){
 const d=state.wormhole.distance,entry=d-config.access,exit=d-config.access-config.throat,open=config.gateOpen;
 return {entryOffset:entry,exitOffset:exit,entryVisible:open&&entry<halfSpan,exitVisible:open&&exit>-halfSpan,insideVisible:open&&entry>-halfSpan&&exit<halfSpan,
  crossingEntry:open&&Math.abs(entry)<halfSpan,crossingExit:open&&Math.abs(exit)<halfSpan,halfSpan};
}
