// The total lives on Abacus; first-party storage only remembers whether this
// browser has been counted. No third-party cookie, tracker script, or polling.
export const VISITOR_HOSTS=['simoncloud7.github.io'];
export const VISITOR_KEY='capy-planet-visitor-counted-v1';
const COUNTER='simoncloud7.github.io/capy-planet-visitors-v1';
export function canCountVisitors(location){return location?.protocol==='https:'&&VISITOR_HOSTS.includes(location.hostname)}
export function visitorTotal(payload){const n=payload?.value;return Number.isSafeInteger(n)&&n>=0?n:null}

export async function requestVisitorStats({env=globalThis,timeout=10000}={}){
 if(!canCountVisitors(env.location))return {status:'local',visitors:null};
 const request=async()=>{
  let storage,marked=false;
  try{storage=env.localStorage;marked=!!storage.getItem(VISITOR_KEY);if(!marked)storage.setItem(VISITOR_KEY,'pending')}catch{storage=null}
  // Without storage, read only; refreshing a privacy-restricted browser must
  // not manufacture a new visitor. A pending claim is also read only after an
  // ambiguous timeout, since the server might already have accepted the hit.
  const increment=!!storage&&!marked,controller=new env.AbortController();
  const timer=env.setTimeout(()=>controller.abort(),timeout);
  try{
   const response=await env.fetch('https://abacus.jasoncameron.dev/'+(increment?'hit/':'get/')+COUNTER,{signal:controller.signal,cache:'no-store',credentials:'omit',referrerPolicy:'no-referrer'});
   if(!response.ok)throw new Error('Visitor counter unavailable');
   const total=visitorTotal(await response.json());if(total===null)throw new Error('Invalid visitor count');
   if(increment)try{storage.setItem(VISITOR_KEY,'counted')}catch{}
   return {status:'ready',visitors:total};
  }catch{return {status:'unavailable',visitors:null}}
  finally{env.clearTimeout(timer)}
 };
 // Supported on current iPad/iPhone and PC browsers; serialize simultaneous
 // first visits in multiple tabs so only one of them increments the total.
 return env.navigator?.locks?.request?env.navigator.locks.request('capy-planet-visitor',request):request();
}

let current;
export function getVisitorStats(){
 if(!current){
  const publish=value=>{if(globalThis.document?.body)document.body.dataset.visitorStats=JSON.stringify({...value,provider:'Abacus',metric:'estimated-unique-browsers'});return value};
  publish({status:canCountVisitors(globalThis.location)?'loading':'local',visitors:null});
  current=requestVisitorStats().then(publish).catch(()=>publish({status:'unavailable',visitors:null}));
 }
 return current;
}
