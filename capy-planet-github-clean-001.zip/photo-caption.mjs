const taipeiClock=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Taipei',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
export function photoTimestamp(iso){return taipeiClock.format(new Date(iso))+' UTC+8'}
export function photoFilename(iso){return '浮鯊衛星-明水覃-'+taipeiClock.format(new Date(iso)).replace(/[ :]/g,'-')+'.png'}
