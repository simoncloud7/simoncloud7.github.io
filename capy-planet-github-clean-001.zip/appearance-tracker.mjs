// Detect arrivals independently of camera motion, including skipped quiet frames.
export class AppearanceTracker{
 constructor({onAppear,onDisappear=()=>{}}){Object.assign(this,{onAppear,onDisappear});this.enabled=false;this.suspended=false;this.pending=false;this.visible=false;this.key=null}
 setEnabled(enabled){const starting=enabled&&!this.enabled;this.enabled=enabled;if(!enabled)this.pending=false;if(starting&&this.visible){if(this.suspended)this.pending=true;else this.onAppear()}}
 setSuspended(suspended){if(this.suspended===suspended)return;this.suspended=suspended;if(this.enabled)this.pending=true}
 sample(visible,key){
  const arrived=visible&&(!this.visible||key!==this.key),left=!visible&&this.visible;
  this.visible=visible;this.key=key;
  if(!this.enabled||this.suspended)return;
  if(visible&&(arrived||this.pending)){this.pending=false;this.onAppear()}else if(left)this.onDisappear();
 }
}
