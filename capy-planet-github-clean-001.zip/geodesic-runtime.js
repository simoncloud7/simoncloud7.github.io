import * as THREE from 'three';
import {traceNullRay} from './gravity.mjs?v=487184046c10';
import {ExperimentLabel} from './experiment-label.js?v=487184046c10';
import {slicePoint} from './geodesic-projection.mjs?v=487184046c10';
import {comparisonCamera} from './comparison-view.js?v=487184046c10';
import {C,REFERENCE_RADIUS} from './relativity.mjs?v=487184046c10';
export class GeodesicSystem{
 constructor({scene,onShow}){
  this.group=new THREE.Group();this.group.userData.sensorOverlay=true;scene.add(this.group);this.group.visible=false;this.k=0;this.impact=1.6;this.phase=0;this.rays=[];this.emissionEnabled=true;this.endpointLabel=new ExperimentLabel();this.group.add(this.endpointLabel.sprite);
  this.onShow=onShow;document.querySelector('#geodesic-toggle').onclick=()=>this.setVisible(!this.group.visible,true);
  document.querySelector('#ray-impact').oninput=e=>{this.impact=Number(e.target.value);if(this.group.visible)this.rebuild()};
 }
 setVisible(visible,notify=false){const changed=this.group.visible!==visible;this.group.visible=visible;document.querySelector('#geodesic-toggle').textContent=visible?'收起星球上的光路':'在星球顯示光路';if(visible&&changed)this.rebuild();if(visible&&notify)this.onShow()}
 setEmissionEnabled(enabled){this.emissionEnabled=enabled;for(const r of this.rays){r.photon.visible=enabled;if(r.line)r.line.visible=enabled}if(this.endpoint)this.endpoint.visible=enabled;this.endpointLabel.sprite.visible=enabled}
 setMass(mass){this.k=mass.compactness;if(this.group.visible)this.rebuild()}
 rebuild(){
  for(const child of [...this.group.children]){if(child===this.endpointLabel.sprite)continue;child.geometry?.dispose();child.material?.dispose();this.group.remove(child)}this.rays=[];this.phase=0;
  document.querySelector('#impact-value').textContent=this.impact.toFixed(2)+' R';
  for(const delta of [0]){
   const ray=traceNullRay(this.k,this.impact+delta,{extent:3}),points=ray.points.map(p=>new THREE.Vector3(...slicePoint(p,this.k)));
   const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),new THREE.LineBasicMaterial({color:ray.status==='surface-hit'?0xff9871:0xe9cc88,transparent:true,opacity:delta===0?1:.5}));this.group.add(line);
   const flat=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(-Math.sqrt(9-(this.impact+delta)**2)*18,-21.9,(this.impact+delta)*18),new THREE.Vector3(Math.sqrt(9-(this.impact+delta)**2)*18,-21.9,(this.impact+delta)*18)]),new THREE.LineDashedMaterial({color:0x8ba9af,dashSize:.65,gapSize:.6,transparent:true,opacity:.4}));flat.computeLineDistances();this.group.add(flat);
   const photon=new THREE.Mesh(new THREE.SphereGeometry(delta===0?.5:.3,10,8),new THREE.MeshBasicMaterial({color:0xfff4cd}));this.group.add(photon);this.rays.push({ray,photon,points,line});
  }
  const ray=this.rays[0].ray;this.endpoint=new THREE.Mesh(new THREE.SphereGeometry(.6,16,12),new THREE.MeshBasicMaterial({color:ray.status==='surface-hit'?0xff9871:ray.status==='escaped'?0xa4d9dd:0xe9cc88}));this.endpoint.position.copy(this.rays[0].points.at(-1));this.group.add(this.endpoint);this.setEmissionEnabled(this.emissionEnabled);
  document.body.dataset.geodesic=JSON.stringify({compactness:this.k,impact:this.impact,status:ray.status,deflection:ray.deflection,closest:ray.closest,maxResidual:ray.maxResidual,solver:'Schwarzschild null Binet RK4',reference:'parallel incoming asymptote at infinity',projection:'Schwarzschild constant-time spatial slice',worldPoints:this.rays[0].points.filter((_,i)=>i%100===0).map(p=>p.toArray())});
 }
 cameraPose(aspect){const points=[];for(let i=0;i<48;i++){const a=i/48*Math.PI*2;points.push(new THREE.Vector3(Math.cos(a)*54,-22,Math.sin(a)*54),new THREE.Vector3(Math.cos(a)*18,-52,Math.sin(a)*18))}for(const axis of [[18,0,0],[-18,0,0],[0,18,0],[0,-18,0],[0,0,18],[0,0,-18]])points.push(new THREE.Vector3(...axis));return comparisonCamera(points,new THREE.Vector3(.7,.72,1.1),new THREE.Vector3(0,1,0),aspect)}

 update(dt,camera){if(!this.group.visible||!this.emissionEnabled)return;this.phase+=dt*C/REFERENCE_RADIUS;for(const {ray,photon,points} of this.rays){const t=this.phase%Math.max(.01,ray.duration);let lo=0,hi=ray.points.length-1;while(lo+1<hi){const m=(lo+hi)>>1;if(ray.points[m].time<=t)lo=m;else hi=m}const a=ray.points[lo],b=ray.points[hi],f=Math.max(0,Math.min(1,(t-a.time)/Math.max(1e-9,b.time-a.time)));photon.position.copy(points[lo]).lerp(points[hi],f)}const hit=this.rays[0].ray.status==='surface-hit',escaped=this.rays[0].ray.status==='escaped';if(camera){const p=this.endpoint.position.clone().addScaledVector(new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld,1),6);this.endpointLabel.update(camera,p,hit?'到達星球表面':escaped?'飛出顯示範圍':'接近臨界光路',hit?'停止追蹤':escaped?'光繼續前進':'本段追蹤結束',hit?'切片內圈 · r = R':escaped?'切片外圈 · r = 3R':'達到數值追蹤範圍',170)}}
}
