import {clockDialPeriod} from './clock-motion.mjs?v=3be149e938ab';
import {traceNullRay} from './gravity.mjs?v=3be149e938ab';
import {C,REFERENCE_RADIUS} from './relativity.mjs?v=3be149e938ab';

const $=selector=>document.querySelector(selector);
export class ClockLab{
 constructor(){
  this.experiment='clocks';this.phase=0;this.rayKey='';this.mode='clocks';
  this.parts={mass:$('.planet-mass-settings'),speed:$('.speed-control'),position:$('.clock-position'),toggle:$('#clock-gravity').closest('label'),reference:$('#clock-reference').closest('label'),guide:$('#clock-display-control'),bench:$('#clock-bench'),scale:$('#physics-scale-label'),status:$('#physical-time-status')};
  this.homes=Object.values(this.parts).map(node=>{const marker=document.createComment('clock-lab home');node.before(marker);return {node,marker}});
  for(const button of document.querySelectorAll('[data-clock-speed]'))button.onclick=()=>{const speed=$('#speed');speed.value=button.dataset.clockSpeed;speed.dispatchEvent(new Event('input',{bubbles:true}))};
  for(const button of document.querySelectorAll('[data-clock-radius]'))button.onclick=()=>{const radius=$('#clock-radius');radius.value=button.dataset.clockRadius;radius.dispatchEvent(new Event('input',{bubbles:true}))};
  for(const button of document.querySelectorAll('[data-gravity-mode]'))button.onclick=()=>{this.mode=button.dataset.gravityMode;this.syncMode();this.onModeChange?.()};
  $('#clock-normal-speed').onclick=()=>{const scale=$('#physics-time-scale');scale.value='1';scale.dispatchEvent(new Event('input',{bubbles:true}))};
  $('#ray-slow').onclick=()=>{const scale=$('#physics-time-scale');scale.value=scale.value==='.02'?'1':'.02';scale.dispatchEvent(new Event('input',{bubbles:true}))};
  this.select('clocks');
 }
 select(tab){
  if(this.selectedTab===tab)return false;this.selectedTab=tab;
  for(const {node,marker} of this.homes)marker.after(node);
  const before=this.experiment;
  if(tab==='clocks'||tab==='gravity'){
   this.experiment=tab;
   const mount=(part,slot)=>$(slot).append(this.parts[part]);
   mount('bench',tab==='clocks'?'#time-bench-slot':'#gravity-bench-slot');
   mount('guide',tab==='clocks'?'#time-guide-slot':'#gravity-guide-slot');
   mount('mass',tab==='clocks'?'#time-mass-slot':'#gravity-mass-slot');
   mount('position',tab==='clocks'?'#time-height-slot':'#gravity-height-slot');
   mount('scale',tab==='clocks'?'#time-playback-slot':'#gravity-playback-slot');
   mount('status',tab==='clocks'?'#time-playback-slot':'#gravity-playback-slot');
   mount('toggle','#time-combine-slot');
   if(tab==='clocks')mount('speed','#time-speed-slot');
   else mount('reference','#gravity-reference-slot');
  }
  if(tab==='light')$('#light-speed-slot').append(this.parts.speed);
  $('#traveler-speed-caption').textContent=tab==='clocks'?'移動速度':tab==='light'?'移動尺速度':'旅行者局部速度';
  $('#planet-mass-caption').textContent=tab==='gravity'||tab==='clocks'?'星球質量':'共用星球質量（對數刻度）';
  this.syncMode();return before!==this.experiment;
 }
 syncMode(){
  $('#gravity').dataset.visual=this.mode;
  for(const button of document.querySelectorAll('[data-gravity-mode]'))button.setAttribute('aria-pressed',String(button.dataset.gravityMode===this.mode));
  const down=$('#science-entrance-down');if(down){down.disabled=this.mode!=='light';if(this.mode!=='light'&&$('#science-entrance').value==='down')$('#science-entrance').value='up'}
  $('#gravity-clocks').hidden=this.mode!=='clocks';$('#gravity-light').hidden=this.mode!=='light';
 }
 render({rate,beta,rho,compactness,elapsed,referenceSeconds,sampleSeconds}){
  const isGravity=this.experiment==='gravity',combined=$('#clock-gravity').checked;
  $('#time-gravity-controls').hidden=!combined;
  $('#clocks').classList.toggle('has-gravity',combined);
  const ref=rate.withGravity?(rate.referenceChoice==='surface'?'地表鐘':'無限遠參考鐘'):'靜止鐘';
  const sample=isGravity?(rho===1?'表面鐘':'高處鐘'):'移動鐘';
  $('#reference-clock-label').textContent=ref;$('#clock-sample-label').textContent=sample;
  $('#compare-reference-label').textContent=ref;$('#compare-sample-label').textContent=sample;
  $('#compare-sample-seconds').textContent=(10*rate.ratio).toFixed(3)+' s';
  const max=Math.max(1,rate.ratio);$('#compare-reference-bar').style.width=100/max+'%';$('#compare-sample-bar').style.width=rate.ratio*100/max+'%';
  const difference=10*(rate.ratio-1);$('#clock-difference').textContent=Math.abs(difference)<.0000000001?'一樣快':(difference>0?'快 ':'慢 ')+Math.abs(difference).toFixed(Math.abs(difference)<.001?9:3)+' s';
  $('#clock-difference').dataset.direction=difference>0?'faster':difference<0?'slower':'same';
  $('#earth-clock').innerHTML=referenceSeconds.toFixed(3)+' <small>s</small>';$('#ship-clock').innerHTML=sampleSeconds.toFixed(3)+' <small>s</small>';
  const period=clockDialPeriod(Number($('#physics-time-scale').value));$('.clock-dials').setAttribute('aria-label','實際累積走時，每圈 '+period+' 秒');$('#reference-hand').setAttribute('transform','rotate('+(referenceSeconds/period*360%360)+' 32 32)');$('#traveler-hand').setAttribute('transform','rotate('+(sampleSeconds/period*360%360)+' 32 32)');
  $('#motion-capy').setAttribute('transform','translate('+(32+((elapsed*beta*.45)%1)*240)+' 48)');
  const y=65-(rho-1)*16;$('#height-sample').setAttribute('cy',String(y));$('#height-radius').setAttribute('y2',String(y));$('#height-rho-label').setAttribute('y',String(Math.max(12,y-10)));$('#height-rho-label').textContent=(6371*(rho-1)).toLocaleString('zh-TW',{maximumFractionDigits:0})+' km';
  const surface=rate.referenceChoice==='surface';$('#height-reference').setAttribute('cx',surface?'123':'77');$('#height-reference').setAttribute('cy',surface?'72':'20');$('#height-reference-position').textContent=surface?'地表':'∞';$('#height-reference-position').setAttribute('x',surface?'105':'68');$('#height-reference-position').setAttribute('y',surface?'63':'13');
  $('#gravity-position-diagram').setAttribute('aria-label',ref+'與 '+rho.toFixed(2)+' R '+sample+'的位置示意');
  for(const button of document.querySelectorAll('[data-clock-speed]'))button.setAttribute('aria-pressed',String(Math.abs(beta-Number(button.dataset.clockSpeed))<1e-10));
  for(const button of document.querySelectorAll('[data-clock-radius]'))button.setAttribute('aria-pressed',String(Math.abs(rho-Number(button.dataset.clockRadius))<1e-10));
  const slow=$('#physics-time-scale').value==='.02';$('#clock-normal-speed').hidden=!slow;$('#ray-slow').setAttribute('aria-pressed',String(slow));$('#ray-slow').textContent=slow?'恢復光點速度':'慢放光點';
  if($('.science').dataset.modelTab==='gravity'&&this.mode==='light')this.renderRay(compactness);
 }
 renderRay(k){
  const impact=Number($('#ray-impact').value),key=k+':'+impact;
  if(this.rayKey!==key){
   this.rayKey=key;this.ray=traceNullRay(k,impact);
   const point=p=>[160+p.x*38,126-p.y*38];
   $('#lab-ray-path').setAttribute('d',this.ray.points.map((p,i)=>(i?'L':'M')+point(p).map(n=>n.toFixed(3)).join(' ')).join(' '));
   const baseline=126-impact*38;$('#lab-ray-flat').setAttribute('d',`M38 ${baseline}H282`);
   $('#impact-value').textContent=impact.toFixed(2)+' R';
   const degrees=this.ray.deflection*180/Math.PI;
   $('#ray-result').textContent=this.ray.status==='escaped'?'偏折 '+(degrees<.001?(degrees*3600).toPrecision(3)+' 角秒':degrees.toFixed(3)+'°'):this.ray.status==='surface-hit'?'碰到星球表面':'接近臨界光路';
   $('#ray-nearest').textContent='最近 '+this.ray.closest.toFixed(3)+' R';
   $('#lab-ray-status').textContent=this.ray.status==='surface-hit'?'光被表面擋住':'金色光路';
  }
  const points=this.ray.points,t=this.phase%Math.max(.01,this.ray.duration);let lo=0,hi=points.length-1;
  while(lo+1<hi){const m=(lo+hi)>>1;if(points[m].time<=t)lo=m;else hi=m}
  const a=points[lo],b=points[hi],f=Math.max(0,Math.min(1,(t-a.time)/Math.max(1e-9,b.time-a.time)));
  $('#lab-photon').setAttribute('cx',String(160+(a.x+(b.x-a.x)*f)*38));$('#lab-photon').setAttribute('cy',String(126-(a.y+(b.y-a.y)*f)*38));
 }
 advance(physicsDt){this.phase+=physicsDt*C/REFERENCE_RADIUS}
}
