// Segment/sphere intersection, including a safety radius for the limb.
export function clearPlanetSight(camera,target,radius=18.4){
 const delta=target.map((v,i)=>v-camera[i]),distance=Math.hypot(...delta);
 if(!Number.isFinite(distance)||distance<1e-8)return false;
 const direction=delta.map(v=>v/distance),b=camera.reduce((s,v,i)=>s+v*direction[i],0),disc=b*b-camera.reduce((s,v)=>s+v*v,0)+radius*radius;
 if(disc<0)return true;const near=-b-Math.sqrt(disc),far=-b+Math.sqrt(disc);
 return !(far>0&&near<distance-.1);
}
