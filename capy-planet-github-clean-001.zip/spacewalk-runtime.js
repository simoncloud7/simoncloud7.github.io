import * as THREE from 'three';
import {spacewalkPose} from './spacewalk.mjs?v=68b46a776e0d';
export class SpacewalkSystem{
 preview(){if(this.time%144<16||this.time%144>70){this.time=22;this.update(0,false)}this.previewEnd=Math.floor(this.time/144)*144+75}
 get performanceActive(){return this.previewEnd!==undefined&&this.time<this.previewEnd}
 constructor({spacecraft,cloneAsset,assets}){
  this.time=0;this.spacecraft=spacecraft;this.crew=[];
  const ring=new THREE.Mesh(new THREE.TorusGeometry(.26,.025,8,40),new THREE.MeshStandardMaterial({color:0x91b8ba,roughness:.6}));ring.rotation.x=-Math.PI/2;ring.position.set(0,1.30,.75);spacecraft.add(ring);
  const hole=new THREE.Mesh(new THREE.CircleGeometry(.245,40),new THREE.MeshBasicMaterial({color:0x152630,side:THREE.DoubleSide}));hole.rotation.x=-Math.PI/2;hole.position.set(0,1.301,.75);spacecraft.add(hole);
  this.hatch=new THREE.Group();this.hatch.position.set(.26,1.305,.75);const lid=new THREE.Mesh(new THREE.CircleGeometry(.25,40),new THREE.MeshStandardMaterial({color:0xdde6dd,side:THREE.DoubleSide,roughness:.8}));lid.rotation.x=-Math.PI/2;lid.position.x=-.26;this.hatch.add(lid);spacecraft.add(this.hatch);
  for(const [index,key] of ['astronaut-engineer','astronaut-surveyor'].entries()){
   const {root,gltf}=cloneAsset(assets[key].id,.58);spacecraft.add(root);root.visible=false;
   const geometry=new THREE.BufferGeometry().setFromPoints(Array.from({length:17},()=>new THREE.Vector3())),tether=new THREE.Line(geometry,new THREE.LineBasicMaterial({color:0xa8d4d9,transparent:true,opacity:.7}));spacecraft.add(tether);tether.visible=false;
   this.crew.push({root,index,tether,mixer:new THREE.AnimationMixer(root),animations:gltf.animations,clip:null});
  }
  this.glint=new THREE.Mesh(new THREE.SphereGeometry(.035,8,6),new THREE.MeshBasicMaterial({color:0xc4f4ff}));this.glint.position.set(-.53,1.0,.05);this.glint.visible=false;spacecraft.add(this.glint);this.repairBeam=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),new THREE.Vector3()]),new THREE.LineBasicMaterial({color:0xb3edfa,transparent:true,opacity:.6}));spacecraft.add(this.repairBeam);this.repairBeam.visible=false;
 }
 update(dt,travelling){
  if(travelling){this.time=0;this.previewEnd=undefined}else this.time+=dt;const states=[],phase=this.time%144,opening=Math.min(1,phase/1.5)*Math.max(0,Math.min(1,(75-phase)/5));this.hatch.rotation.z=-1.45*opening;
  for(const c of this.crew){const p=spacewalkPose(this.time,c.index);c.root.visible=c.tether.visible=!travelling&&p.visible;if(!c.root.visible){states.push({index:c.index,stage:travelling?'返艙待航':p.stage,visible:false});continue}
   c.root.position.fromArray(p.position);c.root.lookAt(new THREE.Vector3(0,p.position[1],0));c.root.rotateZ(.10*Math.sin(this.time*.7+c.index));
   if(c.clip!==p.clip){c.mixer.stopAllAction();c.mixer.clipAction(c.animations.find(a=>a.name===p.clip)).play();c.clip=p.clip}c.mixer.update(dt);
   const attr=c.tether.geometry.attributes.position,end=c.root.position.clone().add(new THREE.Vector3(0,.65,-.15).applyQuaternion(c.root.quaternion)),start=new THREE.Vector3(0,1.05,.75);
   for(let i=0;i<17;i++){const t=i/16,v=start.clone().lerp(end,t);v.y-=.13*Math.sin(t*Math.PI);attr.setXYZ(i,v.x,v.y,v.z)}attr.needsUpdate=true;c.tether.geometry.computeBoundingSphere();states.push({index:c.index,stage:p.stage,visible:true,position:p.position,clip:p.clip});
  }
  this.glint.visible=!travelling&&states[0].stage==='檢修船身'&&Math.sin(this.time*13)>.78;this.repairBeam.visible=this.glint.visible;
  if(this.repairBeam.visible){this.spacecraft.updateMatrixWorld(true);const tip=this.spacecraft.worldToLocal(this.crew[0].root.getObjectByName('arm-1').localToWorld(new THREE.Vector3(0,-.65,.04))),p=this.repairBeam.geometry.attributes.position;p.setXYZ(0,tip.x,tip.y,tip.z);p.setXYZ(1,this.glint.position.x,this.glint.position.y,this.glint.position.z);p.needsUpdate=true;this.repairBeam.geometry.computeBoundingSphere()}
  document.body.dataset.spacewalk=JSON.stringify({time:this.time,travelling,crew:states,model:'artistic EVA; display seconds; safety tethers'});
 }
}
