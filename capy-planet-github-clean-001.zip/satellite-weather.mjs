export const STORM_PERIOD=96,STORM_START=18,STORM_DURATION=14;
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
export function foreheadStormState(time){
 const phase=((time%STORM_PERIOD)+STORM_PERIOD)%STORM_PERIOD,age=phase-STORM_START;
 const active=age>=0&&age<STORM_DURATION;
 const strength=active?smooth(age/2)*(1-smooth((age-11)/3)):0;
 return {phase,age:active?age:null,active,strength,stage:!active?'calm':age<2?'forming':age<11?'tornado':'fading'};
}
