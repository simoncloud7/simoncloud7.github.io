import {physicalLighting} from './daylight.mjs?v=6fa914aa3a5f';
const PHASES=[['tidal-phase-new',0,'朔'],['tidal-phase-crescent',.48,'細弧'],['tidal-phase-full',Math.PI,'滿相']];
export class TidalPhaseControls{
 constructor({marine,observer,lighting,onPreview,onResume,isRunning=()=>true,root=document}){
  Object.assign(this,{marine,observer,lighting,onPreview,onResume,isRunning,root});this.preview=null;
  this.$=id=>root.querySelector('#'+id);
  for(const [id,offset,name] of PHASES)this.$(id).onclick=()=>this.show(offset,name);
  this.$('tidal-phase-resume').onclick=()=>this.resume();
  lighting.addEventListener('change',()=>this.sync());
  for(const [id,event] of [['tide-auto','change'],['tide-phase','input']])this.$(id).addEventListener(event,()=>{this.preview=null;this.sync()});
  this.sync();
 }
 setOrbitRunning(enabled){this.marine.autoTide=enabled;this.$('tide-auto').checked=enabled}
 finishPreview(){if(this.preview){this.setOrbitRunning(this.preview.orbitWasRunning);this.preview=null}}
 show(offset,name){
  // Check here as well as disabling the buttons; never change the light mode.
  if(!physicalLighting(this.lighting.value)||!this.observer.enabled)return false;
  if(!this.preview)this.preview={orbitWasRunning:this.marine.autoTide,name};else this.preview.name=name;
  this.setOrbitRunning(false);
  const tau=2*Math.PI;this.marine.phase=((this.marine.tidalOrbit.newPhase+offset)%tau+tau)%tau;
  this.marine.updateSatellite();this.onPreview();this.sync();return true;
 }
 resume(){this.preview=null;this.setOrbitRunning(true);this.onResume();this.sync()}
 sync(){
  const stellar=physicalLighting(this.lighting.value);
  // A temporary preview must not leave a hidden pause when its feature is exited.
  if(this.preview&&(!stellar||!this.observer.enabled||!this.observer.viewActive))this.finishPreview();
  const allowed=stellar&&this.observer.enabled,running=this.isRunning();
  for(const [id] of PHASES)this.$(id).disabled=!allowed;
  this.$('tidal-phase-hint').textContent=stellar?'預覽會移到衛星正下方，暫停衛星繞行。看完可按「繼續衛星繞行」；離開地表觀測會恢復預覽前的繞行狀態。':'請先到「場景設定」將光照模式設為「自然晝夜」或「恆星明暗觀察」，再回到本頁使用相位預覽。';
  this.$('tidal-phase-motion').textContent=!running?'宇宙已暫停':this.preview?'正在預覽'+this.preview.name+' · 衛星繞行已暫停':this.marine.autoTide?'衛星繞行中 · 受光相位持續變化':'衛星繞行已暫停';
  const resume=this.$('tidal-phase-resume');resume.disabled=this.marine.autoTide&&running;resume.textContent=running?'繼續衛星繞行':'繼續宇宙與衛星繞行';
  this.root.body.dataset.tidalPhaseControls=JSON.stringify({allowed,lighting:this.lighting.value,preview:this.preview?.name||null,orbitRunning:this.marine.autoTide,sceneRunning:running,observerEnabled:this.observer.enabled,observerActive:this.observer.viewActive,phase:this.marine.phase});
 }
}
