import {twinTrip} from './relativity.mjs?v=c38a92d35e93';
export const TWIN_DURATION=36;
export const TWIN_INTRO_SECONDS=4;
const clamp=x=>Math.max(0,Math.min(1,x)),smooth=x=>{x=clamp(x);return x*x*(3-2*x)};
// Camera changes use presentation time only; no effect on the twins' proper times.
export function twinCameraBlend(seconds){return seconds<19?smooth(seconds/6):1-smooth((seconds-19)/17)}
// Once the ship is parked, finish on the twins instead of its full hull.
export function twinReunionBlend(seconds){return smooth((seconds-32)/4)}
export function twinStory(seconds,beta=.995,distanceLy=25){
 const t=Math.max(0,Math.min(TWIN_DURATION,seconds)),trip=twinTrip(beta,distanceLy);let phase,progress;
 if(t<4){phase='登船道別';progress=0}
 else if(t<7){phase='離開星球';progress=.03*smooth((t-4)/3)}
 else if(t<17){phase='去程';progress=.03+.47*(t-7)/10}
 else if(t<19){phase='折返';progress=.5}
 else if(t<29){phase='回程';progress=.5+.47*(t-19)/10}
 else if(t<32){phase='返回星球';progress=.97+.03*smooth((t-29)/3)}
 else if(t<36){phase='下船重逢';progress=1}
 else{phase='重逢';progress=1}
 const route=t<7?0:t<17?smooth((t-7)/10):t<19?1:t<29?1-smooth((t-19)/10):0;
 const lift=t<4?0:t<7?smooth((t-4)/3):t<29?1:t<32?1-smooth((t-29)/3):0;
 const homeAge=20+trip.earthYears*progress,travelerAge=20+trip.travelerYears*progress;
 return {t,phase,progress,route,lift,aboard:t>=4&&t<32,boarding:clamp(t/4),disembark:clamp((t-32)/4),returning:t>=18,complete:t>=36,homeAge,travelerAge,elder:clamp((homeAge-45)/20),...trip};
}
