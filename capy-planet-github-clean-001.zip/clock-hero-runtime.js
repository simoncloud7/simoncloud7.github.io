import * as THREE from 'three';
import {setFlightPose,setGaitPose,isHeroCloth} from './hero-style.js?v=898c7c496a3a';
import {capeMotion,clothRipple} from './cape-motion.mjs?v=898c7c496a3a';
import {poseSuspendedWeaver,updateSuspendedCape} from './weaver-flight.js?v=898c7c496a3a';
import {ExperimentStage} from './experiment-stage.js?v=898c7c496a3a';
import {visibleExperimentPoints} from './experiment-captions.js?v=898c7c496a3a';

const Y=new THREE.Vector3(0,1,0),Z=new THREE.Vector3(0,0,1),smooth=x=>{x=THREE.MathUtils.clamp(x,0,1);return x*x*(3-2*x)};
function frame(up,forward){const f=forward.clone().projectOnPlane(up);if(f.lengthSq()<1e-8)f.set(1,0,0).projectOnPlane(up);f.normalize();return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3().crossVectors(up,f).normalize(),up,f))}
function clothOf(root){const result=[];root.traverse(n=>{if(!n.isMesh)return;n.material=Array.isArray(n.material)?n.material.map(m=>m.clone()):n.material.clone();if(isHeroCloth(n.name)){n.geometry=n.geometry.clone();n.geometry.computeBoundingBox();result.push({mesh:n,base:n.geometry.attributes.position.array.slice(),center:n.geometry.boundingBox.getCenter(new THREE.Vector3()),size:n.geometry.boundingBox.getSize(new THREE.Vector3())})}});return result}
const paw=(root,side)=>root.getObjectByName('arm-'+side).localToWorld(new THREE.Vector3(0,-.49,0));
export const SPEED_CLOCK_INTRO_SECONDS=8.6;
export function chooseMageEntrance(mode,random=Math.random){const choices=mode==='ray'?['vertical','up','down']:['vertical','up'];return choices[Math.min(choices.length-1,Math.floor(random()*choices.length))]}

// This is the theatrical layer around the existing physics instruments. The
// sampled radii, proper times and Schwarzschild ray solver remain in their labs.
export class ClockHeroExperiment{
 constructor({scene,globe,cloneAsset,assets,mageAsset,gateAsset,guides,geodesic,fable,stage,onCaptions=()=>{}}){
  Object.assign(this,{scene,globe,guides,geodesic,fable,onCaptions});this.active=false;this.age=0;this.serial=0;
  this.group=new THREE.Group();this.group.userData.sensorOverlay=true;this.group.visible=false;scene.add(this.group);
  this.runner=cloneAsset(assets['capy-speed'].id,.9).root;this.super=cloneAsset(assets['capy-super'].id,.9).root;this.mage=cloneAsset(mageAsset.id,.9).root;this.group.add(this.runner,this.super,this.mage);
  this.runnerCloth=clothOf(this.runner);this.superCloth=clothOf(this.super);this.mageCloth=clothOf(this.mage);
  this.portal=new THREE.Group();const gate=cloneAsset(gateAsset.id).root,box=new THREE.Box3().setFromObject(gate),center=box.getCenter(new THREE.Vector3()),size=box.getSize(new THREE.Vector3());gate.position.sub(center);const ringScale=3.25/size.y;gate.scale.multiplyScalar(ringScale);gate.position.multiplyScalar(ringScale);this.portal.add(gate);
  this.portalDisc=new THREE.Mesh(new THREE.CircleGeometry(1.1,64),new THREE.MeshBasicMaterial({color:0x778eb5,transparent:true,opacity:.22,side:THREE.DoubleSide,depthWrite:false}));this.portalDisc.scale.y=1.3;this.portal.add(this.portalDisc);this.group.add(this.portal);
  this.clip=new THREE.Plane();this.lamp=this.makeLamp();this.group.add(this.lamp);this.audience=stage?new ExperimentStage({...stage,clearPeople:true,dataKey:'clockHeroStage'}):null;
  this.clockGrip=new THREE.Mesh(new THREE.CylinderGeometry(.027,.027,1,12),new THREE.MeshStandardMaterial({color:0xd9c184,metalness:.35,roughness:.5}));this.group.add(this.clockGrip);
  guides.actorSystem=this;
 }
 makeLamp(){
  const lamp=new THREE.Group(),metal=new THREE.MeshStandardMaterial({color:0x476a70,metalness:.35,roughness:.55}),rim=new THREE.MeshStandardMaterial({color:0xe5c780,metalness:.45,roughness:.4});
  const body=new THREE.Mesh(new THREE.CylinderGeometry(.58,.43,.70,32),metal);body.rotation.x=Math.PI/2;lamp.add(body);
  const ring=new THREE.Mesh(new THREE.TorusGeometry(.54,.045,10,48),rim);ring.position.z=.35;lamp.add(ring);
  this.lens=new THREE.Mesh(new THREE.CircleGeometry(.50,48),new THREE.MeshBasicMaterial({color:0xffedb2,side:THREE.DoubleSide}));this.lens.position.z=.36;lamp.add(this.lens);
  const grip=new THREE.Mesh(new THREE.BoxGeometry(.90,.11,.12),metal);grip.position.set(0,-.1,-.46);lamp.add(grip);
  for(const x of [-.34,.34]){const brace=new THREE.Mesh(new THREE.BoxGeometry(.07,.22,.27),metal);brace.position.set(x,0,-.37);lamp.add(brace)}
  lamp.name='weaver-large-searchlight';return lamp;
 }
 start(mode,entrance='random'){
  if(entrance==='random')entrance=chooseMageEntrance(mode);
  if(this.active)this.stop();this.active=true;this.mode=mode;this.entrance=mode==='gravity'&&entrance==='down'?'up':entrance;this.age=0;this.serial++;this.ready=false;this.group.visible=true;this.runner.visible=mode!=='ray';this.super.visible=mode==='speed';this.mage.visible=mode!=='speed';this.portal.visible=mode!=='speed';this.lamp.visible=mode==='ray';this.clockGrip.visible=mode==='gravity';this.fable?.setPerformance(true,false);this.audience?.finishRelease();this.audience?.begin();this.introWide=null;this.introClose=null;this.mageForward=null;for(const root of [this.runner,this.super,this.mage,this.portal,this.clockGrip])this.ghost(root,false);
 }
 stop(){if(!this.active)return;this.active=false;this.ready=true;this.group.visible=false;this.audience?.stop();this.fable?.setPerformance(false);if(this.ownsCaptions){this.onCaptions(null);this.ownsCaptions=false}for(const clock of [this.guides.groundClock,this.guides.movingClock]){clock.worldDialRadius=null;clock.group.traverse(n=>{if(n.material)n.material.clippingPlanes=[]});clock.label.visible=true}this.geodesic.setEmissionEnabled?.(true);document.body.dataset.clockHeroes=JSON.stringify({active:false})}
 advance(dt){if(!this.active)return;this.age+=dt;this.ready=this.age>=(this.mode==='speed'?SPEED_CLOCK_INTRO_SECONDS:4.4)}
 entryOffset(){const u=smooth(this.age/4.4);return this.entrance==='vertical'?new THREE.Vector3(0,0,-4.4*(1-u)):this.entrance==='down'?new THREE.Vector3(0,6.2*(1-u),0):new THREE.Vector3(0,-3.6*(1-u),0)}
 setPortal(anchor,q){
  const horizontal=this.entrance!=='vertical',local=horizontal?new THREE.Vector3(0,this.entrance==='down'?4.2:.08,0):new THREE.Vector3(0,1.5,-2.1);
  this.portal.position.copy(local.applyQuaternion(q).add(anchor));this.portal.quaternion.copy(q);if(horizontal)this.portal.quaternion.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1,0,0),-Math.PI/2));this.portal.scale.setScalar(smooth(this.age/.7));
  const normal=(horizontal?Y.clone().multiplyScalar(this.entrance==='down'?-1:1):Z.clone()).applyQuaternion(q);this.clip.setFromNormalAndCoplanarPoint(normal,this.portal.position);this.portalNormal=normal;
  this.mage.traverse(n=>{if(n.isMesh)for(const m of Array.isArray(n.material)?n.material:[n.material]){m.clippingPlanes=this.ready?[]:[this.clip];m.clipShadows=true}});
 }
 poseMage(anchor,up,forward){
  const q=frame(up,forward),offset=this.entryOffset().applyQuaternion(q);this.mage.position.copy(anchor).addScaledVector(up,.8).add(offset);this.mage.quaternion.copy(q);this.setPortal(anchor,q);
  if(this.entrance==='vertical'){
   setFlightPose(this.mage,1);setGaitPose(this.mage,0,false);for(const side of [-1,1])this.mage.getObjectByName('leg-'+side).rotation.x=-1.25;
   for(const {mesh,base,center,size} of this.mageCloth){const m=capeMotion(.5,center.toArray()),p=mesh.geometry.attributes.position;for(let i=0;i<p.count;i++){const x=base[i*3],y=base[i*3+1],z=base[i*3+2],r=clothRipple((x-center.x)/(size.x/2),(y-center.y)/(size.y/2),this.age,1);p.setXYZ(i,x+r.x,y+r.y,center.z+(z-center.z)*.08+r.z)}p.needsUpdate=true;mesh.rotation.set(m.rotation,0,0);mesh.scale.fromArray(m.scale);mesh.position.fromArray(m.center).add(new THREE.Vector3(0,.55,0)).sub(center.clone().multiply(mesh.scale).applyQuaternion(mesh.quaternion));mesh.geometry.computeVertexNormals();mesh.geometry.computeBoundingBox();mesh.geometry.computeBoundingSphere()}
  }else{poseSuspendedWeaver(this.mage,this.age,1);updateSuspendedCape(this.mageCloth,this.age,1)}
  return {q,offset};
 }
 poseClocks({camera,ground,sample,groundNormal,sampleNormal,tangent,rate}){
  if(!this.active||this.mode==='ray')return null;const cameraUp=new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld,1).normalize(),forward=camera.position.clone().sub(ground).projectOnPlane(groundNormal).normalize();
  this.runner.position.copy(ground).addScaledVector(groundNormal,.27);this.runner.quaternion.copy(frame(groundNormal,forward));setFlightPose(this.runner,1);setGaitPose(this.runner,0,false);this.runner.getObjectByName('arm-1').rotation.set(-2,0,1.2);this.runner.getObjectByName('arm-1').scale.y=1.55;this.runner.getObjectByName('head-pivot').rotation.x=-.06;this.runner.updateWorldMatrix(true,true);
  const groundPaw=paw(this.runner,1),groundDisplay=groundPaw.clone().addScaledVector(cameraUp,.70);let sampleDisplay,contact;
  if(this.mode==='speed'){
   const offsetHeight=groundPaw.clone().sub(ground).dot(groundNormal);sampleDisplay=sample.clone().addScaledVector(sampleNormal,offsetHeight).addScaledVector(cameraUp,.70);
   const f=tangent.clone().normalize(),chest=sampleNormal.clone().negate();this.super.position.copy(sample);this.super.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3().crossVectors(f,chest).normalize(),f,chest));setFlightPose(this.super,0,{single:rate.sampleBeta>=.999?1:0});this.super.updateWorldMatrix(true,true);
   const hands=rate.sampleBeta>=.999?[paw(this.super,-1)]:[paw(this.super,-1),paw(this.super,1)],mid=hands.reduce((a,b)=>a.add(b),new THREE.Vector3()).multiplyScalar(1/hands.length),push=f.clone().projectOnPlane(new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld,2));if(push.lengthSq()<1e-8)push.setFromMatrixColumn(camera.matrixWorld,0);push.normalize();contact=sampleDisplay.clone().addScaledVector(push,-.70);this.super.position.add(contact.clone().sub(mid));this.super.updateWorldMatrix(true,true);
   this.anchor=ground.clone();this.anchorUp=groundNormal.clone();this.anchorForward=forward.clone();this.contact={kind:'push',target:contact.toArray(),hands:rate.sampleBeta>=.999?[paw(this.super,-1).toArray()]:[paw(this.super,-1).toArray(),paw(this.super,1).toArray()]};
  }else{
   const front=this.mageForward||(this.mageForward=camera.position.clone().sub(sample).projectOnPlane(sampleNormal).normalize());this.poseMage(sample,sampleNormal,front);this.mage.getObjectByName('arm-1').rotation.set(-1.15,0,.95);this.mage.updateWorldMatrix(true,true);
   const hand=paw(this.mage,1),head=new THREE.Box3().setFromObject(this.mage.getObjectByName('head-pivot')),headCenter=head.getCenter(new THREE.Vector3()),away=hand.clone().sub(headCenter).projectOnPlane(new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld,2));if(away.lengthSq()<.001)away.setFromMatrixColumn(camera.matrixWorld,0);away.normalize();let headExtent=0;for(const x of [head.min.x,head.max.x])for(const y of [head.min.y,head.max.y])for(const z of [head.min.z,head.max.z])headExtent=Math.max(headExtent,new THREE.Vector3(x,y,z).sub(headCenter).dot(away));const gripLength=Math.max(.12,headExtent-hand.clone().sub(headCenter).dot(away)+.12);
   sampleDisplay=hand.clone().addScaledVector(away,.70+gripLength);this.headBounds=head;this.clockGrip.position.copy(hand).addScaledVector(away,gripLength/2);this.clockGrip.quaternion.setFromUnitVectors(Y,away);this.clockGrip.scale.y=gripLength;this.clockGrip.material.clippingPlanes=this.ready?[]:[this.clip];
   this.anchor=sample.clone();this.anchorUp=sampleNormal.clone();this.anchorForward=front.clone();this.contact={kind:'hold',hand:hand.toArray(),gripLength,away:away.toArray(),headCenter:headCenter.toArray(),headExtent};
  }
  for(const clock of [this.guides.groundClock,this.guides.movingClock])clock.worldDialRadius=.70;
  this.guides.movingClock.group.traverse(n=>{if(n.material)n.material.clippingPlanes=this.mode==='gravity'&&!this.ready?[this.clip]:[]});this.guides.groundClock.label.visible=this.mode!=='speed'||this.ready;this.guides.movingClock.label.visible=this.ready;
  this.clockDisplay={ground:groundDisplay,sample:sampleDisplay};this.lastSubjects=[this.runner,this.mode==='speed'?this.super:this.mage,this.guides.groundClock.group,this.guides.movingClock.group,...(this.mode==='gravity'?[this.portal,this.clockGrip]:[])];
  return {ground:groundDisplay,sample:sampleDisplay,groundTitle:'電俠 · 地面鐘',sampleTitle:this.mode==='speed'?'超拉 · 移動鐘':'奇異巴拉 · 高處鐘'};
 }
 placeCaption(camera){
  if(!this.active||this.mode!=='gravity'||!this.headBounds)return;
  const box=this.headBounds,clock=this.guides.movingClock,toPixel=p=>(1-p.project(camera).y)*innerHeight/2;let headTop=Infinity;for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z])headTop=Math.min(headTop,toPixel(new THREE.Vector3(x,y,z)));
  clock.group.updateWorldMatrix(true,true);const y=clock.label.position.y-clock.label.scale.y/2,bottom=toPixel(clock.group.localToWorld(new THREE.Vector3(0,y,0))),above=toPixel(clock.group.localToWorld(new THREE.Vector3(0,y+1,0))),pixelsPerUnit=bottom-above;
  if(pixelsPerUnit>1e-6)clock.label.position.y+=Math.max(0,bottom-headTop+14)/pixelsPerUnit;
  this.headCaptionTop=headTop;
 }
 poseRay(){
  if(!this.active||this.mode!=='ray'||!this.geodesic.rays.length)return;const points=this.geodesic.rays[0].points,source=points[0].clone(),direction=points[1].clone().sub(source).normalize(),forward=direction.clone().projectOnPlane(Y).normalize(),lampQ=frame(direction.clone().cross(new THREE.Vector3().crossVectors(Y,direction)).normalize(),direction),lampUp=Y.clone().projectOnPlane(direction).normalize();
  const handle=source.clone().addScaledVector(direction,-.82).addScaledVector(lampUp,-.10),body=handle.clone().addScaledVector(forward,-.429).addScaledVector(Y,-1.024),anchor=body.clone().addScaledVector(Y,-.8),pose=this.poseMage(anchor,Y,forward);for(const side of [-1,1])this.mage.getObjectByName('arm-'+side).rotation.set(-1.34,0,0);
  this.lamp.position.copy(source).addScaledVector(direction,-.36).add(pose.offset);this.lamp.quaternion.copy(lampQ);this.lamp.traverse(n=>{if(n.isMesh)n.material.clippingPlanes=this.ready?[]:[this.clip]});this.lens.material.color.setHex(this.ready?0xffefb0:0x9a9878);this.lamp.updateWorldMatrix(true,true);this.mage.updateWorldMatrix(true,true);
  this.anchor=anchor;this.anchorUp=Y.clone();this.anchorForward=forward;this.raySource=source;this.rayDirection=direction;this.lastSubjects=[this.mage,this.portal,this.lamp];this.geodesic.setEmissionEnabled?.(this.ready);
 }
 ghost(root,behind){root.traverse(n=>{if(!n.isMesh)return;n.renderOrder=behind?80:0;for(const m of Array.isArray(n.material)?n.material:[n.material]){m.userData.heroBase??={opacity:m.opacity,transparent:m.transparent,depthTest:m.depthTest,depthWrite:m.depthWrite};const base=m.userData.heroBase;m.depthTest=behind?false:base.depthTest;m.depthWrite=behind?false:base.depthWrite;m.transparent=behind||base.transparent;m.opacity=base.opacity*(behind?.40:1)}})}
 setBackside(groundBehind,sampleBehind){if(!this.active||this.mode==='ray')return;this.ghost(this.runner,groundBehind);this.ghost(this.mode==='speed'?this.super:this.mage,sampleBehind);if(this.mode==='gravity'){this.ghost(this.portal,sampleBehind);this.ghost(this.clockGrip,sampleBehind)}}
 updateStage(dt,camera,satellite){
  if(!this.active){this.audience?.update(dt);return}this.group.visible=this.mode==='ray'?this.geodesic.group.visible:this.guides.clockEnabled;if(this.mode==='ray')this.poseRay();const subjects=this.lastSubjects||[];this.audience?.update(dt,{camera,satellite,subjects,targets:subjects.filter(x=>x.visible).slice(0,2).map(root=>root.getWorldPosition(new THREE.Vector3()))});
  if(this.mode==='speed'&&!this.ready){
   // A take belongs to one actor. Clock sprites include large text planes;
   // keep both out of these close shots, including the other actor's label.
   this.guides.groundClock.label.visible=false;this.guides.movingClock.label.visible=false;
   const root=this.age<2.9?this.runner:this.super,hold=this.age<2.5||this.age>=3.3&&this.age<6.3;
   this.onCaptions(hold?{subjects:[this.runner,this.super],items:[{root,anchor:root.getWorldPosition(new THREE.Vector3()),title:root===this.runner?'電俠 · 地面鐘':'超拉 · 移動鐘',value:root===this.runner?'地面就位':'準備推鐘繞行',side:'below',pinned:true,color:'#a8d7d4'}],stable:true,tracking:true}:null);this.ownsCaptions=true;
  }else if(this.ownsCaptions){this.onCaptions(null);this.ownsCaptions=false;this.guides.groundClock.label.visible=true;this.guides.movingClock.label.visible=true}
  const status=document.querySelector('[data-experiment-status="'+(this.mode==='speed'?'clocks':'gravity')+'"]');if(status)status.textContent=this.ready?'實驗進行中':this.mode==='speed'?'電俠與超拉就位中':'奇異巴拉跨門進場中';
  document.body.dataset.clockHeroes=JSON.stringify({active:true,mode:this.mode,age:this.age,ready:this.ready,entrance:this.entrance,portalVisible:this.portal.visible,portalNormal:this.portalNormal?.toArray(),portalPosition:this.portal.position.toArray(),magePosition:this.mage.position.toArray(),runnerPosition:this.runner.position.toArray(),superPosition:this.super.position.toArray(),contact:this.contact,source:this.raySource?.toArray(),lens:this.lens.getWorldPosition(new THREE.Vector3()).toArray(),rayDirection:this.rayDirection?.toArray(),clockPropsAreEnlargedSymbols:true});
 }
 prepareCamera(camera,wide){if(!this.anchor)return;const up=this.anchorUp,forward=this.anchorForward,right=new THREE.Vector3().crossVectors(up,forward).normalize();this.introWide={position:wide.position.clone(),target:wide.target.clone()};if(this.mode==='speed'){
   const direction=wide.position.clone().sub(wide.target).normalize(),halfFov=Math.min(THREE.MathUtils.degToRad(camera.fov/2),Math.atan(Math.tan(THREE.MathUtils.degToRad(camera.fov/2))*camera.aspect));
   const take=(actor,clock)=>{const box=new THREE.Box3().setFromPoints([...visibleExperimentPoints(actor),...visibleExperimentPoints(clock.group)]),target=box.getCenter(new THREE.Vector3()).addScaledVector(new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld,1),-.4),radius=box.getSize(new THREE.Vector3()).length()/2,distance=radius/Math.sin(halfFov)*1.16;return {position:target.clone().addScaledVector(direction,distance),target}};
   this.introClose=take(this.runner,this.guides.groundClock);this.introSuper=take(this.super,this.guides.movingClock);return;
  }if(this.mode==='gravity'){const target=this.runner.position.clone().lerp(this.anchor,.5).addScaledVector(up,2),direction=wide.position.clone().sub(wide.target).normalize(),distance=Math.max(30,this.runner.position.distanceTo(this.anchor)*2.1);this.introWide={position:target.clone().addScaledVector(direction,distance),target}}this.introClose={position:this.anchor.clone().addScaledVector(up,4.5).addScaledVector(forward,9).addScaledVector(right,5),target:this.anchor.clone().addScaledVector(up,1.6)}}
 cameraPose(){if(!this.introWide||!this.introClose)return null;if(this.mode==='speed'){
   if(this.age>SPEED_CLOCK_INTRO_SECONDS+.05)return null;let from=this.introClose,to=this.introSuper,t=smooth((this.age-2.5)/.8);if(this.age>=3.3){from=this.introSuper;to=this.introWide;t=smooth((this.age-6.3)/2.3)}return {position:from.position.clone().lerp(to.position,t),target:from.target.clone().lerp(to.target,t)};
  }const hold=4.4;if(this.age>hold+3.2)return null;const t=smooth((this.age-hold)/3.2);return {position:this.introClose.position.clone().lerp(this.introWide.position,t),target:this.introClose.target.clone().lerp(this.introWide.target,t)}}
 broadcastPose(){
  if(!this.active||!this.anchor)return null;const roots=this.lastSubjects||[],box=new THREE.Box3();for(const root of roots)if(root.visible)box.expandByObject(root);const points=[];for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z])points.push(new THREE.Vector3(x,y,z));const up=this.anchorUp,target=box.getCenter(new THREE.Vector3());return {label:this.mode==='speed'?'電俠與超拉 · 速度鐘差':this.mode==='gravity'?'電俠與奇異巴拉 · 高低時鐘':'奇異巴拉 · 探照燈與彎曲光路',group:this.group,groups:[this.group,this.guides.clockGroup,...(this.mode==='ray'?[this.geodesic.group]:[])],anchor:target.clone().addScaledVector(up,12).addScaledVector(this.anchorForward,12),target,up,bounds:points};
 }
}
