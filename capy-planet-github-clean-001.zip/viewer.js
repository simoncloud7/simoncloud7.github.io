import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
export class Viewer {
 constructor(host,{background=0xd3dccb}={}){
  this.host=host;this.scene=new THREE.Scene();this.scene.background=new THREE.Color(background);
  this.camera=new THREE.PerspectiveCamera(38,1,.01,1000);
  this.renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});this.renderer.setPixelRatio(Math.min(devicePixelRatio,2));this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.0;
  host.append(this.renderer.domElement);this.controls=new OrbitControls(this.camera,this.renderer.domElement);this.controls.enableDamping=true;
  this.scene.add(new THREE.HemisphereLight(0xffffff,0x758763,1.8));
  const light=new THREE.DirectionalLight(0xfff4df,2);light.position.set(4,8,5);this.scene.add(light);const fill=new THREE.DirectionalLight(0xdcecff,.7);fill.position.set(-4,2,-2);this.scene.add(fill);
  this.grid=new THREE.GridHelper(10,20,0xb7c7a8,0xd3ddc9);this.scene.add(this.grid);
  this.clock=new THREE.Clock();this.resourceErrors=[];this.manager=new THREE.LoadingManager();this.manager.onError=url=>this.resourceErrors.push(url);this.loader=new GLTFLoader(this.manager);this.generation=0;this.playing=true;
  this.observer=new ResizeObserver(()=>this.resize());this.observer.observe(host);this.resize();
  this.renderer.setAnimationLoop(()=>{const dt=this.clock.getDelta();if(this.mixer&&this.playing)this.mixer.update(dt);this.controls.update();this.renderer.render(this.scene,this.camera)});
 }
 resize(){let w=this.host.clientWidth,h=this.host.clientHeight;if(w<1||h<1)return;this.renderer.setSize(w,h,false);this.camera.aspect=w/h;this.camera.updateProjectionMatrix()}
 disposeObject(object){object.traverse(n=>{if(n.isMesh){n.geometry?.dispose();for(const m of Array.isArray(n.material)?n.material:[n.material]){for(const value of Object.values(m))if(value?.isTexture)value.dispose();m.dispose()}}})}
 clear(){if(this.object){this.scene.remove(this.object);this.disposeObject(this.object);this.object=null}if(this.mixer){this.mixer.stopAllAction();this.mixer=null}}
 async load(url,{normalize=true}={}){
  const generation=++this.generation;
  this.clear();this.resourceErrors=[];const gltf=await this.loader.loadAsync(url);
  if(generation!==this.generation){this.disposeObject(gltf.scene);return null}
  this.object=gltf.scene;this.animations=gltf.animations;
  const box=new THREE.Box3().setFromObject(this.object),size=box.getSize(new THREE.Vector3()),center=box.getCenter(new THREE.Vector3());
  if(normalize){const s=3/Math.max(size.x,size.y,size.z);this.object.scale.multiplyScalar(s);this.object.position.sub(center.multiplyScalar(s));this.object.position.y+=size.y*s/2}
  this.scene.add(this.object);if(gltf.animations.length){this.mixer=new THREE.AnimationMixer(this.object);this.mixer.clipAction(gltf.animations[0]).play()}
  this.reset();this.renderer.render(this.scene,this.camera);
  return {gltf,meshes:this.countMeshes(),animations:gltf.animations.length,renderer:this.renderer.info.render,resourceErrors:[...this.resourceErrors]};
 }
 countMeshes(){let n=0;this.object?.traverse(x=>{if(x.isMesh)n++});return n}
 playClip(index){if(!this.mixer||!this.animations[index])return;this.mixer.stopAllAction();this.mixer.clipAction(this.animations[index]).reset().play();this.playing=true}
 reset(){this.camera.position.set(4,3,5);this.controls.target.set(0,1.1,0);this.controls.update()}
 wireframe(on){this.object?.traverse(n=>{if(n.isMesh)for(const m of Array.isArray(n.material)?n.material:[n.material])m.wireframe=on})}
 destroy(){this.generation++;this.renderer.setAnimationLoop(null);this.observer.disconnect();this.controls.dispose();this.clear();this.renderer.dispose();this.renderer.domElement.remove()}
}
export {THREE,GLTFLoader};
