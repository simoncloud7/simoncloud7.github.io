import * as THREE from 'three';

// Frame fixed reference points, never the traveller's heading or current position.
export function comparisonCamera(points,direction,up,aspect,fov=43){
 const target=new THREE.Box3().setFromPoints(points).getCenter(new THREE.Vector3()),z=direction.clone().normalize(),x=new THREE.Vector3().crossVectors(up,z).normalize(),y=new THREE.Vector3().crossVectors(z,x),s=Math.tan(THREE.MathUtils.degToRad(fov/2));
 let distance=0;for(const p of points){const d=p.clone().sub(target);distance=Math.max(distance,d.dot(z)+Math.max(Math.abs(d.dot(y))/s,Math.abs(d.dot(x))/(s*aspect)))}
 return {position:target.clone().addScaledVector(z,distance*1.18+4),target,up:y};
}

export function referenceLabel(text,color='#efd19a'){
 const canvas=document.createElement('canvas');canvas.width=512;canvas.height=96;const c=canvas.getContext('2d');c.fillStyle='#101c2eea';c.fillRect(0,0,512,96);c.fillStyle=color;c.font='500 36px "Microsoft JhengHei",sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(text,256,48);
 const texture=new THREE.CanvasTexture(canvas),label=new THREE.Sprite(new THREE.SpriteMaterial({map:texture,depthTest:false,depthWrite:false}));label.scale.set(8,1.5,1);label.renderOrder=20;return label;
}
