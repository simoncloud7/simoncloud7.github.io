import * as THREE from 'three';
import {runnerExposure} from './fable.mjs?v=487184046c10';
export class RunnerAfterimages{
 constructor(globe,costume,animate,{delay=.055}={}){
  this.animate=animate;this.delay=delay;this.history=[];this.strength=0;
  // Shared geometry, five lightweight pose copies; no additional asset downloads.
  this.ghosts=Array.from({length:5},()=>{
   const root=new THREE.Group(),model=costume.clone(true),materials=[];root.add(model);root.visible=false;globe.add(root);
   model.traverse(n=>{if(!n.isMesh)return;n.castShadow=false;n.receiveShadow=false;const make=m=>{const c=m.clone();c.transparent=true;c.opacity=0;c.depthWrite=false;c.color.lerp(new THREE.Color(0x9de7d1),.24);materials.push(c);return c};n.material=Array.isArray(n.material)?n.material.map(make):make(n.material)});
   return {root,model,materials};
  });
 }
 reset(){this.history=[];this.strength=0;for(const g of this.ghosts)g.root.visible=false}
 update(runner,time,phase,beta,stride,strength=runnerExposure(phase,beta)){
  this.strength=strength;
  if(this.strength===0){this.history=[];for(const g of this.ghosts)g.root.visible=false;return}
  if(!this.history.length||time-this.history.at(-1).time>=.035)this.history.push({time,position:runner.position.clone(),quaternion:runner.quaternion.clone(),stride});
  while(this.history.length&&time-this.history[0].time>this.delay*6+.12)this.history.shift();
  this.ghosts.forEach((g,i)=>{
   const target=time-(i+1)*this.delay;let sample=null,next=null;for(const h of this.history){if(h.time<=target)sample=h;else{next=h;break}}
   g.root.visible=Boolean(sample);if(!sample)return;
   const mix=next?Math.max(0,Math.min(1,(target-sample.time)/(next.time-sample.time))):0;g.root.position.copy(sample.position);g.root.quaternion.copy(sample.quaternion);if(next){g.root.position.lerp(next.position,mix);g.root.quaternion.slerp(next.quaternion,mix)}this.animate(g.model,next?sample.stride+(next.stride-sample.stride)*mix:sample.stride,true);
   for(const m of g.materials)m.opacity=this.strength*.27*(1-i/6);
  });
 }
}
