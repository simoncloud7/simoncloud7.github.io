export class ExperimentSession{
 constructor(){this.active=null;this.complete=false;this.lastEnded=null}
 start(kind){const previous=this.active;this.active=kind;this.complete=false;this.lastEnded=null;return previous}
 stop(){const previous=this.active;if(previous)this.lastEnded=previous;this.active=null;this.complete=false;return previous}
 select(kind){return this.active&&this.active!==kind?this.stop():null}
 finish(){if(this.active)this.complete=true}
 finishAndStop(){if(!this.active)return null;const previous=this.stop();this.complete=true;return previous}
}
