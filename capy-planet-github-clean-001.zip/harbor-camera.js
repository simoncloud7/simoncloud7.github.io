import * as THREE from 'three';

// Transport one viewing frame around the globe. The boat can turn, reverse or
// spiral without rotating the camera. Respawns travel over, not through, water.
export class HarborCamera{
 reset(){this.normal=null}
 pose(root,globe,dt=0){
  globe.updateWorldMatrix(true,true);const p=globe.worldToLocal(root.getWorldPosition(new THREE.Vector3())),desired=p.clone().normalize();
  if(!this.normal){this.normal=desired.clone();const q=globe.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(root.getWorldQuaternion(new THREE.Quaternion())),forward=new THREE.Vector3(0,0,1).applyQuaternion(q).projectOnPlane(desired).normalize(),right=new THREE.Vector3().crossVectors(desired,forward).normalize();this.side=right.multiplyScalar(10).addScaledVector(forward,-10).normalize();this.radius=Math.max(18.1,p.length())}
  const elapsed=Math.max(0,dt),angle=this.normal.angleTo(desired),blend=Math.min(1-Math.exp(-elapsed*5),angle>1e-8?elapsed*.65/angle:1),turn=new THREE.Quaternion().setFromUnitVectors(this.normal,desired),step=new THREE.Quaternion().slerp(turn,blend);this.side.applyQuaternion(step);this.normal.applyQuaternion(step).normalize();this.side.projectOnPlane(this.normal).normalize();this.radius=THREE.MathUtils.lerp(this.radius,Math.max(18.1,p.length()),1-Math.exp(-elapsed*5));
  const target=this.normal.clone().multiplyScalar(this.radius+1.2),position=this.normal.clone().multiplyScalar(this.radius+8).addScaledVector(this.side,Math.sqrt(200));
  return {position:globe.localToWorld(position),target:globe.localToWorld(target),up:new THREE.Vector3(0,1,0)};
 }
}
