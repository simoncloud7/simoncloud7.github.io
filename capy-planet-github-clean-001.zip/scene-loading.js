export class SceneLoading{
 constructor(root,{nextFrame=()=>new Promise(resolve=>requestAnimationFrame(resolve))}={}){
  this.root=root;this.nextFrame=nextFrame;this.state=root?'loading':'disabled';this.loaded=0;this.total=0;if(!root)return;
  this.title=root.querySelector('[data-loading-title]');this.message=root.querySelector('[data-loading-message]');this.count=root.querySelector('[data-loading-count]');this.progress=root.querySelector('progress');this.retry=root.querySelector('button');this.retry.onclick=()=>location.reload();
  this.locked=[...document.querySelectorAll('body > main, body > section, body > aside, body > nav')].filter(node=>node!==root).map(node=>({node,inert:node.inert}));for(const {node} of this.locked)node.inert=true;
  this.onError=event=>{if(event.error)this.fail(event.error)};this.onRejection=event=>this.fail(event.reason);window.addEventListener('error',this.onError);window.addEventListener('unhandledrejection',this.onRejection);document.querySelector('#cosmos')?.setAttribute('aria-busy','true');this.update({message:'準備星球與場景設定…'});
 }
 update({loaded=this.loaded,total=this.total,message}={}){
  if(!this.root||!['loading','finishing'].includes(this.state))return;this.loaded=loaded;this.total=total;if(message)this.message.textContent=message;
  if(total>0){this.progress.value=Math.max(0,Math.min(1,loaded/total));this.count.textContent=`${loaded} / ${total} 個模型`}else{this.progress.removeAttribute('value');this.count.textContent='正在準備 3D 世界'}this.report();
 }
 report(){document.body.dataset.sceneLoading=JSON.stringify({state:this.state,loaded:this.loaded,total:this.total})}
 release(){for(const {node,inert} of this.locked||[])node.inert=inert;window.removeEventListener('error',this.onError);window.removeEventListener('unhandledrejection',this.onRejection);document.querySelector('#cosmos')?.setAttribute('aria-busy','false')}
 async ready(){
  if(!this.root||this.state!=='loading')return;this.state='finishing';this.update({message:'場景準備好了，正在進入卡皮星…'});await this.nextFrame();await this.nextFrame();if(this.state==='failed')return;
  this.state='ready';this.release();this.report();this.root.classList.add('is-ready');this.root.setAttribute('aria-hidden','true');setTimeout(()=>{this.root.hidden=true},450);
 }
 fail(error){
  if(!this.root||!['loading','finishing'].includes(this.state))return;this.state='failed';document.body.dataset.ready='failed';this.root.classList.add('is-failed');this.title.textContent='這次尚未載入完成';this.message.textContent=/webgl/i.test(String(error?.message||error))?'目前瀏覽器無法啟用 3D 顯示，請確認硬體加速或改用支援 WebGL 的瀏覽器。':'部分場景資源載入中斷，請重新載入頁面。';this.count.textContent='';this.progress.hidden=true;this.retry.hidden=false;this.report();
 }
}
