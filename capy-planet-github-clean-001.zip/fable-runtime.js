import * as THREE from 'three';
import {heroState,storyClockRates,advanceStory,lakeArrival,superStop,STORY_YEARS_PER_SECOND,FLY_RADIUS} from './fable.mjs?v=2d2193a1a37f';
import {isHeroCloth,setFlightPose,setGaitPose} from './hero-style.js?v=2d2193a1a37f';
import {RunnerAfterimages} from './runner-afterimages.js?v=2d2193a1a37f';
import {comparisonCamera} from './comparison-view.js?v=2d2193a1a37f';
import {RescueMemory} from './rescue-memory.js?v=2d2193a1a37f';
const $=s=>document.querySelector(s),up=new THREE.Vector3(0,1,0);
// Preserve the everyday lake-passing orbit. The camera must adapt to this plane.
export function superOrbitBasis(lakeNormal,lakeNorth){return {a:lakeNormal.clone().normalize(),b:lakeNorth.clone().negate().normalize()}}
// Positive angular motion is counterclockwise from the common orbit-front view.
export function superOrbitAngularVelocity(direction,beta){return -direction*(.6+beta*1.3)}
export class FableSystem{
 constructor({globe,cloneAsset,assets,ufoAsset,citizenSites,frameAt,paths,lake,onView,onSpeed}){
  Object.assign(this,{globe,frameAt,onView,onSpeed});this.time=0;this.superTime=0;this.speedTime=0;this.direction=-1;this.angle=0;this.routeDistance=0;this.clock={city:0,super:0,speed:0};this.history=[];
  const orbit=superOrbitBasis(lake.normal,lake.north);this.orbitA=orbit.a;this.orbitB=orbit.b;this.approach=null;
  $('#super-closeup').onclick=()=>this.onView('super');
  const make=(key,scale)=>{const root=cloneAsset(assets[key].id,scale).root;globe.add(root);return root};
  this.super=make('capy-super',.9);this.capeMeshes=[];this.super.traverse(n=>{if(n.isMesh&&isHeroCloth(n.name)){n.geometry=n.geometry.clone();this.capeMeshes.push({mesh:n,base:n.geometry.attributes.position.array.slice()})}});this.runner=new THREE.Group();globe.add(this.runner);this.costume=make('capy-speed',.85);this.civilian=make('capy-civilian',.85);this.runner.add(this.costume,this.civilian);
  this.afterimages=new RunnerAfterimages(globe,this.costume,(...args)=>this.animate(...args));
  this.memorial=make('capy-memorial',.85);this.place(this.memorial,-5.2,2.9,.05,.5);
  this.rescueMemory=new RescueMemory({cloneAsset,assetId:assets['capy-xiaoba'].id,ufoAssetId:ufoAsset.id,memorialAssetId:assets['capy-memorial'].id});
  // Existing street centerline: no shortcut through buildings. Reverse at the endpoints.
  this.street=new THREE.CatmullRomCurve3(paths[0].map(([x,z])=>new THREE.Vector3(x,0,z)));this.streetLength=this.street.getLength();
  this.citizens=(citizenSites?citizenSites.map(p=>[p.position[0],p.position[2]]):[[-7,5],[-1.4,2.1],[3,1.8],[8,2.6]]).map(([x,z],i)=>{const root=make('capy-civilian',.75);this.place(root,x,z,0,-.5+i*.4);root.traverse(n=>{if(n.isMesh){n.material=n.material.clone();if(n.name.startsWith('age-hair'))n.material.vertexColors=false;if(n.name.startsWith('elder-cane'))n.visible=false}});return root});
  this.trail=new THREE.Line(new THREE.BufferGeometry(),new THREE.LineBasicMaterial({color:0x87deef,transparent:true,opacity:.62}));globe.add(this.trail);
  this.lightning=new THREE.Group();globe.add(this.lightning);
  this.lightningLine=new THREE.LineSegments(new THREE.BufferGeometry(),new THREE.LineBasicMaterial({color:0xeb895e,transparent:true,opacity:.9}));this.lightning.add(this.lightningLine);
  this.burst=new THREE.Mesh(new THREE.TorusGeometry(.64,.035,10,44,Math.PI*1.6),new THREE.MeshBasicMaterial({color:0x85d8bb,transparent:true,opacity:.7}));this.burst.rotation.x=Math.PI/2;this.runner.add(this.burst);
  $('#super-replay').onclick=()=>{this.resumeDemoSpeed();this.superTime=0;this.approach=null;this.direction=-1;this.history=[];this.rescueMemory.start();this.onView('super-orbit')};
  $('#super-reverse').onclick=()=>{this.direction*=-1;this.superTime=Math.floor(this.superTime/31)*31;this.approach=null;this.history=[];this.rescueMemory.stop();this.onView('super-orbit')};
  $('#hero-light-limit').onclick=()=>{this.direction=1;this.superTime=Math.floor(this.superTime/31)*31;this.approach=null;this.history=[];this.rescueMemory.stop();this.onSpeed(.999);$('#hero-limit-message').textContent='已設為 0.999 c。接近光速只會改變累積的固有時間；順向或逆向繞行都不能回到過去。c 不是時間倒流的開關；有質量角色無法加速到 c。';this.onView('super-orbit')};
  $('#speed-replay').onclick=()=>{this.resumeDemoSpeed();this.speedTime=0;this.onView('speedster')};
  $('#speed-walk').onclick=()=>{this.speedTime=Math.floor(this.speedTime/28)*28+18;this.onView('speedster')};
  $('#story-reset').onclick=()=>this.reset();this.pose(0,.8,0);
  $('#story-forward').onclick=()=>{if(this.lastConfig)this.update(40,this.lastConfig);this.onView('speedster')};
 }
 resumeDemoSpeed(){if(Number($('#hero-speed').value)===0)this.onSpeed(.8)}
 watchPerformance(kind){const actor=kind==='speedster'?'speed':'super',time=actor==='speed'?this.speedTime:this.superTime,period=actor==='speed'?28:31;this.watchedPerformance={actor,end:(Math.floor(time/period)+1)*period}}
 get performanceActive(){const p=this.watchedPerformance;return !!p&&(p.actor==='speed'?this.speedTime:this.superTime)<p.end}
 setPerformance(enabled,keepRunner=false){this.performing=enabled;this.keepRunner=keepRunner;this.super.visible=!enabled;this.runner.visible=!enabled||keepRunner;if(enabled){this.rescueMemory.stop();this.trail.visible=false;if(!keepRunner){this.lightning.visible=false;for(const ghost of this.afterimages.ghosts)ghost.root.visible=false}}}
 reset(){this.clock={city:0,super:0,speed:0};this.time=0;this.superTime=0;this.speedTime=0;this.approach=null;this.parameterKey=null;this.updateAges()}
 place(root,x,z,h=0,rotation=0){const f=this.frameAt(x,z);root.position.copy(f.normal.multiplyScalar(18.23+h));root.quaternion.copy(f.q).multiply(new THREE.Quaternion().setFromAxisAngle(up,rotation))}
 animate(root,phase,run=false){setGaitPose(root,phase,run)}
 updateAges(){
  const age=Math.min(1,this.clock.city/65);
  for(const root of this.citizens){root.traverse(n=>{if(n.name.startsWith('age-hair')&&n.material){n.material.vertexColors=false;n.material.color.copy(new THREE.Color(0x856445)).lerp(new THREE.Color(0xe9e5d6),age)}if(n.name.startsWith('elder-cane'))n.visible=age>.55});root.scale.y=.75*(1-age*.12)}
 }
 pose(dt,beta,k){
  const s=heroState(this.superTime,'super'),r=heroState(this.speedTime,'speed'),stop=superStop(Math.floor(this.superTime/31));this.stop=stop;
  if(s.moving&&beta>0){
   const velocity=superOrbitAngularVelocity(this.direction,beta);
   if(s.phase<16){this.approach=null;this.angle+=velocity*dt}
   else{if(!this.approach||this.approach.direction!==this.direction||s.phase<this.approach.phase||this.approach.cycle!==stop.cycle)this.approach={angle:this.angle,phase:s.phase,remaining:20-s.phase,velocity,direction:this.direction,cycle:stop.cycle,stopAngle:stop.angle};const a=this.approach;this.angle=lakeArrival(a.angle,a.velocity,a.remaining,(s.phase-a.phase)/a.remaining,a.stopAngle).angle}
  }else if(s.mode==='hover'&&this.approach)this.angle=lakeArrival(this.approach.angle,this.approach.velocity,this.approach.remaining,1,this.approach.stopAngle).target;
  const a=this.angle,normal=this.orbitA.clone().multiplyScalar(Math.cos(a)).addScaledVector(this.orbitB,Math.sin(a)),tangent=this.orbitA.clone().multiplyScalar(-Math.sin(a)).addScaledVector(this.orbitB,Math.cos(a)).multiplyScalar(-this.direction);
  this.super.position.copy(normal).multiplyScalar(18*FLY_RADIUS+(s.mode==='hover'?Math.sin(this.time*2)*.13:0));
  const flying=s.mode==='flight'&&beta>0;
  if(flying){const chest=normal.clone().negate(),x=new THREE.Vector3().crossVectors(tangent,chest).normalize();this.super.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(x,tangent,chest))}else this.super.quaternion.copy(new THREE.Quaternion().setFromUnitVectors(up,normal));
  setFlightPose(this.super,flying?0:1,{single:beta>=.999?1:0});
  for(const {mesh,base} of this.capeMeshes){const p=mesh.geometry.attributes.position;for(let i=0;i<p.count;i++){const t=Math.max(0,Math.min(1,(1.42-base[i*3+1])/1.02));p.setZ(i,base[i*3+2]+.035*t*Math.sin(this.time*7+base[i*3]*5+t*4))}p.needsUpdate=true;mesh.geometry.computeVertexNormals()}
  if(dt>0){this.history.push(this.super.position.clone());if(this.history.length>38)this.history.shift()}this.trail.geometry.dispose();this.trail.geometry=new THREE.BufferGeometry().setFromPoints(this.history);this.trail.visible=s.moving&&beta>0;
  const speed=r.mode==='run'?(beta>0?10+beta*24:0):r.mode==='walk'?.25:0;this.routeDistance+=dt*speed;
  const u=(this.routeDistance/this.streetLength)%2,rev=u>1,p=this.street.getPointAt(rev?2-u:u),d=this.street.getTangentAt(rev?2-u:u).multiplyScalar(rev?-1:1);this.place(this.runner,p.x,p.z,.01,Math.atan2(d.x,d.z));
  this.costume.visible=r.mode==='run'||r.mode==='transform';this.civilian.visible=r.mode==='walk';this.burst.visible=r.mode==='transform';this.burst.scale.setScalar(1+.18*Math.sin(this.time*18));this.burst.position.y=.9;
  this.animate(this.costume,this.routeDistance*3,true);this.animate(this.civilian,this.routeDistance*6,false);
  this.afterimages.update(this.runner,this.speedTime,r.phase,beta,this.routeDistance*3);
  const sparks=[];if(r.mode==='run'&&beta>0){for(let i=0;i<18;i++)for(const offset of [0,.075]){let q=(this.routeDistance-i*.22-offset)/this.streetLength;q=((q%2)+2)%2;const v=this.street.getPointAt(q>1?2-q:q),f=this.frameAt(v.x,v.z);sparks.push(f.normal.multiplyScalar(18.48))}}this.lightningLine.geometry.dispose();this.lightningLine.geometry=new THREE.BufferGeometry().setFromPoints(sparks);this.lightning.visible=sparks.length>0;
  const rates=storyClockRates(k,beta,s.mode,r.mode);return {s,r,rates};
 }
 update(dt,{beta,compactness:k}){
  if(this.performing){this.setPerformance(true,false);return}
  if(this.rescueActive){this.trail.visible=false;this.lightning.visible=false;for(const g of this.afterimages.ghosts)g.root.visible=false;$('#super-state').textContent='超拉救援演出中 · 英雄故事時計暫停';document.body.dataset.heroStoryPaused='satellite-rescue';return}document.body.dataset.heroStoryPaused='';
  this.lastConfig={beta,compactness:k};
  const key=k+':'+beta;if(this.parameterKey!==key){this.reset();this.parameterKey=key}
  // Integrate the speed/rest duty cycle in small pieces; paused scene means no aging.
  let remaining=dt;while(remaining>1e-8){const step=Math.min(remaining,1/120),s=heroState(this.superTime,'super'),r=heroState(this.speedTime,'speed');this.clock=advanceStory(this.clock,step*STORY_YEARS_PER_SECOND,storyClockRates(k,beta,s.mode,r.mode));this.time+=step;this.superTime+=step;this.speedTime+=step;remaining-=step}
  const {s,r,rates}=this.pose(dt,beta,k);this.updateAges();
  $('#hero-beta-value').textContent=beta.toFixed(3)+' c';$('#hero-speed-hint').classList.toggle('is-stopped',beta===0);$('#hero-speed-hint').textContent=beta===0?'英雄速度為 0 c，飛行與疾跑已停止。按重播可恢復英雄的 0.8 c。':'英雄速度 '+beta.toFixed(3)+' c；懸浮、變裝與步行按各自週期播放。';
  $('#super-replay').textContent=beta===0?'恢復 0.8 c 並重播超拉':'重播逆向救援';$('#speed-replay').textContent='播放疾跑與重逢 · 0.999 c';
  $('#super-state').textContent=(beta===0?'停下，在目前位置懸浮':s.mode==='flight'?(this.direction<0?'逆向 · 逆時針繞行':'順向 · 順時針繞行'):this.stop.lake?'明水覃上空 · 懸浮停留':'環球巡遊 · 懸浮停留')+' · '+(s.mode==='flight'?beta.toFixed(3):'0.000')+' c';
  $('#super-reverse').textContent=this.direction<0?'改為順向（順時針）':'改為逆向（逆時針）';
  $('#speed-state').textContent=r.mode==='run'?(beta===0?'停下 · 零速度':this.afterimages.strength>.5?'高速殘影 · 珊瑚脈衝':r.phase<2.1?'起步 · 一般跑步':r.phase>13.8?'準備停步 · 一般跑步':'一般跑步'):r.mode==='transform'?'停下 · 變裝中':'便服 · 正常步行';
  $('#story-city-years').textContent=this.clock.city.toFixed(1);$('#story-super-years').textContent=this.clock.super.toFixed(1);$('#story-speed-years').textContent=this.clock.speed.toFixed(1);
  $('#city-age').textContent=(20+this.clock.city).toFixed(1);$('#runner-age').textContent=(20+this.clock.speed).toFixed(1);
  const memory=this.rescueMemory.update(this.superTime,this.direction<0,this.clock.city);$('#super-story').textContent=memory?.caption||(this.direction>0?'順向繞行，現在與超拉的固有時間都繼續前進。':this.superTime<20?'小芭在出發前已離世。卡皮超拉嘗試逆向飛回那一天。':this.superTime<25?'他停下來，紀念像還在，星球的日期卻更晚了。':'他能少經歷一些歲月，卻不能讓兩人的過去重來。');
  document.body.dataset.rescueMemory=JSON.stringify({active:this.rescueMemory.root.visible,victim:'capybara-xiaoba',lipstick:'rose',cause:'ufo-collision',historicalPlayhead:memory?.history??null,fall:memory?.fall??null,presentTime:this.clock.city,memorialVisible:this.memorial.visible,changesPast:false});
  document.body.dataset.runnerAfterimages=JSON.stringify({phase:r.phase,strength:this.afterimages.strength,visible:this.afterimages.ghosts.filter(g=>g.root.visible).length,mode:this.afterimages.strength>.5?'afterimages':r.mode==='run'?'normal-run':r.mode,visualOnly:true});
  const chestDirection=new THREE.Vector3(0,0,1).applyQuaternion(this.super.quaternion);
  if(this.performing)this.setPerformance(true,this.keepRunner);
  document.body.dataset.heroes=JSON.stringify({time:this.time,superMode:s.mode,speedMode:r.mode,direction:this.direction,beta,compactness:k,flyRadius:FLY_RADIUS,clock:this.clock,rates,cityAge:20+this.clock.city,runnerAge:20+this.clock.speed,eventInPast:true,canReverseTime:false,design:'wind-pulse-weaver-v2',superPose:s.mode==='flight'&&beta>0?(beta>=.999?'single-hand flight':'both hands forward'):'upright hover',hoverStop:this.stop,orbitAngle:this.angle,chestRadialDot:chestDirection.dot(this.super.position.clone().normalize()),superPosition:this.super.position.toArray(),runnerPosition:this.runner.position.toArray(),yearsPerDisplaySecond:STORY_YEARS_PER_SECOND});
 }
 cameraPose(kind){
  this.globe.updateMatrixWorld(true);const root=kind==='super'?this.super:kind==='memory'?this.memorial:this.runner,p=root.getWorldPosition(new THREE.Vector3()),n=p.clone().normalize(),forward=new THREE.Vector3(0,0,1).applyQuaternion(root.getWorldQuaternion(new THREE.Quaternion()));
  const side=new THREE.Vector3().crossVectors(n,new THREE.Vector3(0,0,1));if(side.lengthSq()<.01)side.set(1,0,0);side.normalize();
  // One orbit-based shoulder view throughout flight, hover and takeoff. The
  // actor's pose never chooses a new camera, and the larger side offset keeps
  // the viewing direction away from the world-up pole without changing drag axes.
  if(kind==='super'){const plane=new THREE.Vector3().crossVectors(this.orbitA,this.orbitB).normalize().applyQuaternion(this.globe.getWorldQuaternion(new THREE.Quaternion())),heading=new THREE.Vector3().crossVectors(plane,n).normalize().multiplyScalar(-this.direction);return {position:p.clone().addScaledVector(n,2.7).addScaledVector(heading,3.5).addScaledVector(plane,-7.5),target:p.clone().addScaledVector(n,.5).addScaledVector(heading,.7),up:up.clone()}}
  if(kind==='speedster'){const right=new THREE.Vector3(1,0,0).applyQuaternion(root.getWorldQuaternion(new THREE.Quaternion()));return {position:p.clone().addScaledVector(n,3.6).addScaledVector(right,6).addScaledVector(forward,3.2),target:p.clone().addScaledVector(n,1.1),up:n}}
  return {position:p.clone().addScaledVector(n,2.8).addScaledVector(side,2.4).addScaledVector(forward,5),target:p.clone().addScaledVector(n,1.2),up:kind==='super'?up.clone():n};
 }
 orbitCameraPose(aspect){
  this.globe.updateMatrixWorld(true);const q=this.globe.getWorldQuaternion(new THREE.Quaternion()),a=this.orbitA.clone().applyQuaternion(q),b=this.orbitB.clone().applyQuaternion(q),normal=new THREE.Vector3().crossVectors(a,b).normalize(),points=[];
  const side='orbit-front',screenDirection=this.direction<0?'counterclockwise':'clockwise',radius=18*FLY_RADIUS+2.4;
  for(let i=0;i<64;i++)points.push(a.clone().multiplyScalar(radius*Math.cos(i/64*Math.PI*2)).addScaledVector(b,radius*Math.sin(i/64*Math.PI*2)));
  return {...comparisonCamera(points,normal,up,aspect),up:up.clone(),side,screenDirection,orbitNormal:normal,flightRadius:18*FLY_RADIUS};
 }
}
