export const LAUNCH_DURATION=38;
export const VOYAGE_START=[24,3,19],VOYAGE_TURN=[39,15,-8];
export function voyagePose(progress){
 const p=Math.max(0,Math.min(1,progress)),returning=p>=.5,u=returning?2*(1-p):2*p;
 return {progress:p,returning,position:VOYAGE_START.map((a,i)=>a+(VOYAGE_TURN[i]-a)*u),direction:VOYAGE_START.map((a,i)=>(VOYAGE_TURN[i]-a)*(returning?-1:1))};
}
export const LANDING_X=-5.5,BASE_Y=.82,STAGE_OFFSET=4.6;
const mix=(a,b,t)=>a+(b-a)*t,clamp=t=>Math.max(0,Math.min(1,t)),smooth=t=>t*t*(3-2*t);
export function launchPose(seconds){
 const t=Math.max(0,Math.min(LAUNCH_DURATION,seconds));let phase,boost=[0,BASE_Y,0],upper=[0,BASE_Y+STAGE_OFFSET,0],angle=0,flame=false,upperFlame=false,legs=0,upperVisible=true;
 if(t<3)phase='發射台待命／倒數';
 else if(t<11){phase='點火升空';const u=(t-3)/8,h=22*u*u;boost=[3*u*u,BASE_Y+h,0];upper=[boost[0],boost[1]+STAGE_OFFSET,0];flame=true;angle=-.12*u}
 else if(t<15){phase='級間分離／翻轉';const u=(t-11)/4;boost=[mix(3,6,u),mix(BASE_Y+22,28,u),0];upper=[3+12*u,BASE_Y+22+STAGE_OFFSET+12*u,0];angle=Math.PI*smooth(u);upperFlame=true}
 else if(t<20){phase='第一節返航點火';const u=(t-15)/5;boost=[mix(6,-1,smooth(u)),mix(28,22,u),0];upper=[15+u*20,39+u*18,0];angle=Math.PI*(1-smooth(u));flame=true;upperFlame=true}
 else if(t<26){phase='再入點火／姿態修正';const u=(t-20)/6;boost=[mix(-1,-4,u),mix(22,9,u),0];flame=u<.5;upperVisible=false}
 else if(t<33){phase='著陸減速／展開支腳';const u=(t-26)/7;boost=[mix(-4,LANDING_X,smooth(u)),BASE_Y+(9-BASE_Y)*(1-u)**2,0];legs=smooth(clamp(u*1.7));flame=true;upperVisible=false}
 else {phase='垂直著陸完成';boost=[LANDING_X,BASE_Y,0];legs=1;upperVisible=false}
 return {t,phase,boost,upper,angle,flame,upperFlame,legs,upperVisible,landed:t>=33};
}
export const UFO_POINTS=[[29,9,7],[7,25,20],[-23,17,10],[-27,-5,-15],[5,-19,-28],[29,5,-16]];
export function ufoPose(seconds){const period=3.4,dwell=2.65,segment=Math.floor(Math.max(0,seconds)/period),i=segment%UFO_POINTS.length,j=(i+1)%UFO_POINTS.length,t=Math.max(0,seconds)%period,moving=t>=dwell,u=moving?smooth((t-dwell)/(period-dwell)):0;return {position:UFO_POINTS[i].map((x,k)=>mix(x,UFO_POINTS[j][k],u)),moving,station:i}}
