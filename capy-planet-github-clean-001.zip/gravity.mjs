// Schwarzschild exterior, fixed areal surface radius R. k=rs/R; rho=r/R.
import {lorentz,gravityRate} from './relativity.mjs?v=9530a88e453c';
export function clockRates(k,rho,beta,{gravity=true,reference='infinity'}={}){
 if(!Number.isFinite(rho)||rho<1)throw RangeError('Clock stays outside the surface');
 gravityRate(k);const effective=gravity?k:0,staticRate=gravityRate(effective/rho),moving=staticRate/lorentz(beta),referenceRate=reference==='surface'?gravityRate(effective):reference==='infinity'?1:NaN;
 if(!Number.isFinite(referenceRate))throw RangeError('Unknown clock reference');
 return {moving,reference:referenceRate,ratio:moving/referenceRate,gravity:staticRate,motion:1/lorentz(beta)};
}
export function embeddingHeight(k,rho,outer=3){gravityRate(k);if(rho<1||outer<rho)throw RangeError('Exterior slice only');return 2*(Math.sqrt(k*(rho-k))-Math.sqrt(k*(outer-k)))}
// Null Binet equation: u''+u=(3/2)k u^2, u=R/r, with impact b/R=B at infinity.
// Initial data u(0)=0,u'(0)=1/B define a parallel incoming ray from infinity.
// Points are Schwarzschild areal polar coordinates projected on a drawing plane.
export function traceNullRay(k,B,{step=.001,extent=3.2,maxAngle=12*Math.PI}={}){
 gravityRate(k);if(!Number.isFinite(B)||B<=0||step<=0||extent<=B)throw RangeError('Positive impact, step and visible extent required');
 let u=0,w=1/B,phi=0,points=[],maxResidual=0,closest=Infinity,status='tracking-limit',deflection=null,time=0,previous=null;
 const f=(a)=>-a+1.5*k*a*a;
 const append=(a,p)=>{if(a<=0||a<1/extent)return;const r=1/a,x=-r*Math.cos(p),y=r*Math.sin(p),density=1/(B*a*a*(1-k*a));if(previous)time+=(p-previous.phi)*(density+previous.density)/2;previous={phi:p,density};points.push({x,y,time});};
 for(let i=0;i<Math.ceil(maxAngle/step);i++){
  const h=Math.min(step,maxAngle-phi),a1=w,b1=f(u),a2=w+h*b1/2,b2=f(u+h*a1/2),a3=w+h*b2/2,b3=f(u+h*a2/2),a4=w+h*b3,b4=f(u+h*a3);
  const nextU=u+h*(a1+2*a2+2*a3+a4)/6,nextW=w+h*(b1+2*b2+2*b3+b4)/6,nextPhi=phi+h;
  maxResidual=Math.max(maxResidual,Math.abs(nextW*nextW+nextU*nextU-k*nextU**3-1/(B*B)));
  if(nextU>=1){const fraction=(1-u)/(nextU-u);phi+=h*fraction;append(1,phi);closest=1;status='surface-hit';break}
  if(nextU<=0&&phi>Math.PI/2){const end=phi+h*u/(u-nextU);status='escaped';deflection=end-Math.PI;break}
  u=nextU;w=nextW;phi=nextPhi;if(u>0)closest=Math.min(closest,1/u);append(u,phi);
 }
 return {k,impact:B,status,deflection,closest,maxResidual,points,duration:points.at(-1)?.time||0};
}
