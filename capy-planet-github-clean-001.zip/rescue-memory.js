import * as THREE from 'three';
import {rescueMemoryState} from './rescue-memory.mjs?v=63ea14151482';

// The recording has its own screen and camera; it never occupies the planet scene.
export class RescueMemory{
 constructor({cloneAsset,assetId,ufoAssetId,memorialAssetId}){
  this.panel=document.querySelector('#rescue-monitor');this.tab=document.querySelector('#rescue-tab');this.canvas=document.querySelector('#rescue-image');this.caption=document.querySelector('#rescue-caption');this.stamp=document.querySelector('#rescue-stamp');this.progress=document.querySelector('#rescue-progress');this.present=document.querySelector('#rescue-present');
  document.querySelector('#rescue-close').onclick=()=>this.show(false);this.tab.onclick=()=>this.show(true);
  this.scene=new THREE.Scene();this.scene.background=new THREE.Color(0x172c37);this.root=new THREE.Group();this.root.name='xiaoba-past-recording';this.scene.add(this.root);this.materials=[];this.frames=0;this.bounds=new THREE.Box3();
  const actor=(id,name,scale)=>{const root=cloneAsset(id,scale).root;root.name=name;root.traverse(n=>{if(n.isMesh){n.castShadow=false;n.receiveShadow=false;n.material=n.material.clone();n.material.transparent=true;this.materials.push({material:n.material,ufo:name==='ufo-in-recording',memorial:name==='present-day-memorial'})}});this.root.add(root);return root};
  this.xiaoba=actor(assetId,'xiaoba-in-recording',1.15);this.ufo=actor(ufoAssetId,'ufo-in-recording',.48);this.memorial=actor(memorialAssetId,'present-day-memorial',1.4);this.memorial.position.set(-1.1,.02,.2);this.memorial.rotation.y=.15;
  this.flash=new THREE.Mesh(new THREE.SphereGeometry(.23,12,8),new THREE.MeshBasicMaterial({color:0xffe2aa,transparent:true,depthWrite:false}));this.root.add(this.flash);this.materials.push({material:this.flash.material,alpha:.9});
  const floor=new THREE.Mesh(new THREE.PlaneGeometry(40,40),new THREE.MeshStandardMaterial({color:0x28444b,roughness:1}));floor.rotation.x=-Math.PI/2;floor.position.y=-.01;this.scene.add(floor);
  this.scene.add(new THREE.HemisphereLight(0xe5f2ff,0x677b61,2));const light=new THREE.DirectionalLight(0xffefd6,3);light.position.set(-3,7,5);this.scene.add(light);
  this.camera=new THREE.PerspectiveCamera(24,16/9,.1,80);this.camera.position.set(.3,2.3,9.3);this.camera.lookAt(-.8,1.05,0);
  // Screen-only actors must not enter the main scene's picking or light layers.
  this.scene.traverse(n=>n.layers.set(2));this.camera.layers.set(2);this.root.visible=false;
 }
 show(visible){visible=!!visible&&!!this.requested;this.panel.hidden=!visible;this.tab.hidden=visible||!this.requested;this.tab.setAttribute('aria-expanded',String(visible));document.body.classList.toggle('has-rescue-screen',visible);this.lastFrame=-Infinity;this.report()}
 report(){document.body.dataset.rescueScreen=JSON.stringify({active:!!this.requested,visible:!this.panel.hidden,tabVisible:!this.tab.hidden,frames:this.frames,width:this.canvas.width,height:this.canvas.height})}
 start(time=0){this.startedAt=time;this.requested=true;this.root.visible=true;this.show(true);this.apply(rescueMemoryState(0),0);this.render(0)}
 stop(){this.requested=false;this.root.visible=false;this.show(false)}
 update(time,enabled=true,presentYears=0){
  if(!this.requested||!enabled){if(this.requested)this.stop();return null}
  const elapsed=Math.max(0,time-this.startedAt),s=rescueMemoryState(elapsed);if(s.finished){this.stop();return s}this.root.visible=true;this.apply(s,elapsed);this.present.textContent='星球現在：+'+presentYears.toFixed(1)+' 年';this.render(elapsed);return s;
 }
 apply(s,elapsed){
  // The recorded UFO collision runs backwards; the live memorial never changes.
  this.xiaoba.rotation.set(0,.18,1.38*s.fall);this.xiaoba.position.set(-1.3-.25*s.fall,0,.2);this.xiaoba.traverse(n=>{if(n.name==='arm--1'||n.name==='arm-1')n.rotation.x=-.3*s.fall});this.bounds.setFromObject(this.xiaoba);this.xiaoba.position.y-=this.bounds.min.y;
  this.ufo.position.set(s.ufoX,s.ufoY,.8);this.ufo.rotation.set(.08,Math.sin(s.history*9)*.25,-.12+Math.sin(s.history*6)*.10);this.ufo.visible=s.ufoOpacity>.001;
  this.flash.position.set(-1.3,1.65,.95);this.flash.visible=s.impact;this.flash.scale.setScalar(1+Math.sin((s.history-.41)/.08*Math.PI)*.9);
  this.memorial.visible=s.memorialOpacity>0;for(const {material,alpha=1,ufo,memorial} of this.materials){material.opacity=alpha*(memorial?s.memorialOpacity:s.opacity*(ufo?s.ufoOpacity:1));material.depthWrite=material.opacity>.98}
  this.caption.textContent=s.caption;this.stamp.textContent=Math.min(elapsed,20).toFixed(1)+' / 20 s';this.progress.value=elapsed;document.querySelector('#rescue-mode').textContent=elapsed<17?'過去影像 · 倒放':'現在 · 紀念像仍在';
 }
 render(elapsed){
  if(this.panel.hidden||document.body.classList.contains('scene-ui-hidden')||elapsed-this.lastFrame<1/20)return;
  if(!this.renderer){this.renderer=new THREE.WebGLRenderer({canvas:this.canvas,antialias:true});this.renderer.setPixelRatio(1);this.renderer.setSize(960,540,false);this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.15}
  this.renderer.render(this.scene,this.camera);this.lastFrame=elapsed;this.frames++;this.report();
 }
}
