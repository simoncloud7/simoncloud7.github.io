import * as THREE from 'three';
import {foldedPoint,foldedTangent} from './interstellar.mjs?v=ff2ded0ce791';
import {setFlightPose} from './hero-style.js?v=ff2ded0ce791';
const SCALE=1.7,RING_SCALE=1.15,RADIUS=9.5,OUTER=RADIUS*RING_SCALE,EPS=1e-7;
export const ringUp=new THREE.Vector3(Math.sin(.5),Math.cos(.5),0);
const ease=x=>{x=THREE.MathUtils.clamp(x,0,1);return x*x*(3-2*x)},lerp=THREE.MathUtils.lerp;
function envelope(samples,remaining,span,key,baseRate){let value=0;for(const s of samples){const room=remaining>s.remaining?span-s.remaining:s.remaining,rate=Math.max(baseRate,s[key]/Math.max(EPS,.8*room));value=Math.max(value,s[key]-rate*Math.abs(remaining-s.remaining))}return value}
export function standingFrame(up,forward){const z=forward.clone().addScaledVector(up,-forward.dot(up)).normalize(),x=new THREE.Vector3().crossVectors(up,z);return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(x,up,z))}
export const setHeroPose=setFlightPose;
function heightProjection(mesh,layout){const e=mesh.matrixWorld.elements,u=layout.up;return [u.x*e[0]+u.y*e[1]+u.z*e[2],u.x*e[4]+u.y*e[5]+u.z*e[6],u.x*e[8]+u.y*e[9]+u.z*e[10],u.x*(e[12]-layout.contact.x)+u.y*(e[13]-layout.contact.y)+u.z*(e[14]-layout.contact.z)]}
function heightRange(model,layout){let low=Infinity,high=-Infinity;model.updateWorldMatrix(true,true);model.traverse(n=>{if(!n.isMesh||!n.visible)return;const a=n.geometry.attributes.position,[x,y,z,c]=heightProjection(n,layout);for(let i=0;i<a.count;i++){const h=x*a.getX(i)+y*a.getY(i)+z*a.getZ(i)+c;low=Math.min(low,h);high=Math.max(high,h)}});return {low,high}}
function vertices(model,onlyFeet=false){model.updateWorldMatrix(true,true);const meshes=[];model.traverse(n=>{if(!n.isMesh||!n.visible||(onlyFeet&&!/^leg-(?:-1|1)$/.test(n.name)))return;const a=n.geometry.attributes.position,points=[];for(let i=0;i<a.count;i++)points.push(new THREE.Vector3().fromBufferAttribute(a,i).applyMatrix4(n.matrixWorld));meshes.push({name:n.name,points,index:n.geometry.index?.array})});return meshes}
export function footDrop(model){return -Math.min(...vertices(model,true).flatMap(m=>m.points.map(p=>p.y)))}
export function ringLayout(config,drop){
 const end=new THREE.Vector3(...foldedPoint(config.distance/2,1.1,config.distance,config.fold)).multiplyScalar(SCALE),
  // The rendered grid's final transverse edge runs along Z, 0.65 below E.
  // Make that WHOLE edge a supporting tangent of the outer circumference.
  radial=new THREE.Vector3(-Math.cos(.5),Math.sin(.5),0),
  contact=end.clone().add(new THREE.Vector3(0,-.65,0)),center=contact.clone().addScaledVector(radial,-OUTER),
  mageRadial=radial.clone().applyAxisAngle(ringUp,-.36),mageContact=center.clone().addScaledVector(mageRadial,9.2*RING_SCALE),
  stanceOffset=contact.clone().sub(end).addScaledVector(ringUp,drop),stanceLift=stanceOffset.dot(ringUp);
 return {end,contact,center,radial,up:ringUp.clone(),forward:radial.clone().negate(),mageContact,stanceOffset,stanceLift,radius:RADIUS,orientation:new THREE.Quaternion()};
}
export function gridEdgeReport(config,layout){let minimumRadius=Infinity,maximumPlaneError=0,insideSamples=0;for(const w of [...Array.from({length:65},(_,i)=>-8+16*i/64),1.1]){const p=new THREE.Vector3(...foldedPoint(config.distance/2,w,config.distance,config.fold)).multiplyScalar(SCALE).add(new THREE.Vector3(0,-.65,0)),d=p.sub(layout.center),h=d.dot(layout.up),radius=d.addScaledVector(layout.up,-h).length()/RING_SCALE;minimumRadius=Math.min(minimumRadius,radius);maximumPlaneError=Math.max(maximumPlaneError,Math.abs(h));if(radius<RADIUS-1e-6)insideSamples++}return {minimumRadius,outerRadius:RADIUS,maximumPlaneError,insideSamples}}
// Intersect actual triangles with the annular plane. This checks the visible
// mesh, including limbs and cape, rather than a single carrier coordinate.
export function planeCuts(model,layout){
 const all=[],candidates=[];model.updateWorldMatrix(true,true);
 model.traverse(n=>{
  if(!n.isMesh||!n.visible)return;
  // A conservative local AABB test skips whole meshes; triangle intersections
  // below still use the authored vertices, so this does not relax clearance.
  const g=n.geometry;if(!g.boundingBox)g.computeBoundingBox();const b=g.boundingBox,p=heightProjection(n,layout);let low=p[3],high=p[3];
  for(let k=0;k<3;k++){const axis=['x','y','z'][k],a=p[k]*b.min[axis],z=p[k]*b.max[axis];low+=Math.min(a,z);high+=Math.max(a,z)}
  if(low>=-EPS||high<=EPS)return;
  const a=g.attributes.position,points=[];for(let i=0;i<a.count;i++)points.push(new THREE.Vector3().fromBufferAttribute(a,i).applyMatrix4(n.matrixWorld));candidates.push({points,index:g.index?.array});
 });
 for(const mesh of candidates){
  const p=mesh.points,h=p.map(v=>v.clone().sub(layout.contact).dot(layout.up));
  if(Math.min(...h)>=-EPS||Math.max(...h)<=EPS)continue;
  const ix=mesh.index,count=ix?ix.length:p.length;
  for(let j=0;j<count;j+=3){const ids=[0,1,2].map(k=>ix?ix[j+k]:j+k),hit=[];
   for(let k=0;k<3;k++){const a=ids[k],b=ids[(k+1)%3];if(Math.abs(h[a])<EPS)hit.push(p[a]);if(h[a]*h[b]<0)hit.push(p[a].clone().lerp(p[b],h[a]/(h[a]-h[b])))}
   if(hit.length>=2)all.push([hit[0],hit[1]]);
  }
 }
 return all;
}
export function ringIntersections(model,layout){
 let count=0;for(const [a,b] of planeCuts(model,layout)){const p=a.clone().sub(layout.center),q=b.clone().sub(layout.center),v=q.clone().sub(p),u=THREE.MathUtils.clamp(-p.dot(v)/(v.lengthSq()||1),0,1),low=p.clone().addScaledVector(v,u).length()/RING_SCALE,high=Math.max(p.length(),q.length())/RING_SCALE;
  if([[6.3,6.78],[6.88,7.70],[7.88,8.77],[8.88,9.5]].some(([r0,r1])=>high>r0+1e-5&&low<r1-1e-5))count++;
 }return count;
}
export function soleReport(model,layout){return vertices(model,true).map(m=>{const points=m.points.map(p=>({height:p.clone().sub(layout.contact).dot(layout.up),radius:p.clone().sub(layout.center).addScaledVector(layout.up,-p.clone().sub(layout.center).dot(layout.up)).length()/RING_SCALE})),height=Math.min(...points.map(p=>p.height)),sole=points.filter(p=>p.height<height+.02);return {name:m.name,height,radii:sole.map(p=>p.radius),supported:Math.abs(height)<1e-5&&sole.some(p=>p.radius>=8.88&&p.radius<=9.5)}})}
// Normal and outward offsets belong to the finite cartoon rig during contact.
// The propagated reference point stays on the unchanged E(s,w); these are not
// an extra physical flight leg or a replacement for a landing dynamics model.
export class HeroRingLanding{
 constructor(carrier,model){this.carrier=carrier;this.model=model;this.base=model.position.clone();setHeroPose(model,1);carrier.quaternion.identity();this.drop=footDrop(model);this.samples=[]}
 pose(config,travel,coast=false,settleProgress=0){
  const d=config.distance,s=-d/2+travel,t=new THREE.Vector3(...foldedTangent(s,d,config.fold)),normal=new THREE.Vector3(-t.y,t.x,0),chest=normal.clone().negate(),x=new THREE.Vector3().crossVectors(t,chest),span=this.span,p=1-(d-travel)/span,blend=coast?0:ease(p);
  this.carrier.position.set(...foldedPoint(s,1.1,d,config.fold)).multiplyScalar(SCALE);this.model.position.copy(this.base);
  this.carrier.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(x,t,chest));
  if(!coast&&p>=0)this.carrier.quaternion.copy(this.landingStart).slerp(standingFrame(this.layout.up,this.layout.forward),blend);
  const single=config.beta>=.999?1:ease(this.span+1-(d-travel));
  const armBlend=travel>=d?ease(settleProgress):0;
  setHeroPose(this.model,blend,{single,armBlend});this.offset(this.layout.stanceOffset.clone().multiplyScalar(blend));
  return {p,blend,span};
 }
 offset(v){this.model.position.add(v.clone().applyQuaternion(this.carrier.quaternion.clone().invert()))}
 lift(p,remaining){
  const {low,high}=heightRange(this.model,this.layout),rise=ease((.9-remaining)/.65),hover=.16*ease(remaining/.25),below=Math.min(0,-high-.08),above=Math.max(0,-low+hover);
  // Stay below the finite ring until close to its edge, then rise around the
  // outside of the rim. Raising early would send the rig through the annulus.
  const amount=lerp(below,above,rise);this.offset(this.layout.up.clone().multiplyScalar(amount));return amount;
 }
 requiredOutward(){let amount=0;for(const segment of planeCuts(this.model,this.layout))for(const v of segment)amount=Math.max(amount,OUTER+.035-v.clone().sub(this.layout.center).dot(this.layout.radial));return amount}
 configure(config){
  const key=[config.distance,config.fold,config.beta>=.999].join(':');if(key===this.key)return;
  this.key=key;this.config={...config};this.layout=ringLayout(config,this.drop);this.span=Math.min(3,config.distance*.12);this.samples=[];this.prepared=false;
  this.pose(config,config.distance-this.span,true);this.landingStart=this.carrier.quaternion.clone();
 }
 prepare(config){
  this.configure(config);if(this.prepared)return;
  // Begin before the extended flying mesh reaches the rim, including tight folds.
  for(let remaining=Math.min(8,config.distance);remaining>=0;remaining-=.125){this.pose(config,config.distance-remaining,true);if(planeCuts(this.model,this.layout).length){this.span=Math.max(this.span,remaining+.75);break}}
  this.pose(config,config.distance-this.span,true);this.landingStart=this.carrier.quaternion.clone();
  for(let i=0;i<=192;i++){const remaining=this.span*(1-i/192),{p}=this.pose(config,config.distance-remaining),lift=this.lift(p,remaining),outward=this.requiredOutward();this.samples.push({remaining,lift,outward:outward>0?outward+.08:0})}
  this.prepared=true;
 }
 apply(config,travel,{idle=false,idleForward=[1,0,0],settleProgress=0}={}){
  this.configure(config);
  // Idle and distant flight only need the reference frame. Build the finite-rig
  // landing envelope once it can matter, instead of doing 193 mesh scans per drag.
  const needsLanding=!idle&&config.distance-travel>EPS&&config.distance-travel<=Math.min(8,config.distance);
  if(needsLanding)this.prepare(config);
  const {p,blend}=this.pose(config,travel,false,settleProgress),remaining=config.distance-travel;let lift=0,outward=0;
  if(p>0&&remaining>EPS){const index=Math.min(192,p*192),i=Math.min(191,Math.floor(index));lift=lerp(this.samples[i].lift,this.samples[i+1].lift,index-i);this.offset(this.layout.up.clone().multiplyScalar(lift));outward=envelope(this.samples,remaining,this.span,'outward',2.1*SCALE);
   // Exact narrow-phase guard between cached samples, using the current pose.
   outward=Math.max(outward,this.requiredOutward());
   this.offset(this.layout.radial.clone().multiplyScalar(outward));
  }
  const stanceLift=idle?0:this.layout.stanceLift*blend;
  if(idle){this.carrier.quaternion.copy(standingFrame(new THREE.Vector3(0,1,0),new THREE.Vector3(...idleForward)));this.model.position.copy(this.base);setHeroPose(this.model,1);lift=outward=0}
  const poseVector=this.layout.stanceOffset.clone().multiplyScalar(idle?0:blend).addScaledVector(this.layout.up,lift).addScaledVector(this.layout.radial,outward);
  this.telemetry={blend,remaining,lift:lift+stanceLift,stanceLift,avoidanceLift:lift,outward,poseOffset:poseVector.length(),flightPose:idle||remaining<=EPS&&settleProgress>=1?'standing':config.beta>=.999||remaining<=this.span?'single-hand':remaining<this.span+1?'two-to-one':'two-hands',settleProgress,landingPrepared:this.prepared,carrier:this.carrier.position.toArray()};return this.telemetry;
 }
}
