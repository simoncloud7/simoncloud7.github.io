import * as THREE from 'three';

// A simplified service-bus RCS effect. Keep the authored hull and nadir optics
// untouched: only the active gas is drawn, with no added engine fairing.
export function createSatellitePropulsion(){
 const root=new THREE.Group();root.name='satellite-service-bus-exhaust';
 const pivot=new THREE.Group();root.add(pivot);
 const plumes=new THREE.Group();plumes.name='rcs-exhaust-only';plumes.visible=false;pivot.add(plumes);
 const outlets=[],ports=[],jets=[],jetLength=1.15;
 const material=new THREE.ShaderMaterial({transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,side:THREE.DoubleSide,toneMapped:false,vertexShader:'varying vec2 plumeUv;void main(){plumeUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec2 plumeUv;void main(){float t=clamp(plumeUv.y,0.,1.);float edge=(plumeUv.x-.5)/mix(.18,.42,t);float a=.5*exp(-3.*edge*edge)*smoothstep(0.,.04,t)*pow(1.-t,1.3);gl_FragColor=vec4(mix(vec3(.04,.4,1.),vec3(.015,.14,.65),t),a);\n#include <colorspace_fragment>\n}'});
 for(let i=0;i<2;i++){
  const outlet=new THREE.Group();outlet.name='rcs-upper-hull-outlet-'+i;plumes.add(outlet);outlets.push(outlet);ports.push(new THREE.Vector3());
  const jet=new THREE.Group();jet.name='rcs-plume-'+i;outlet.add(jet);jets.push(jet);
  for(let j=0;j<3;j++){const gas=new THREE.Mesh(new THREE.PlaneGeometry(.32,jetLength),material);gas.rotation.y=j*Math.PI/3;jet.add(gas)}
 }
 return {root,pivot,plumes,outlets,ports,jets,jetLength,update(direction,firing,time){
  const y=direction.clone().normalize(),horizontal=new THREE.Vector3(y.x,0,y.z);if(horizontal.lengthSq()<1e-8)horizontal.set(0,0,1);horizontal.normalize();
  const side=new THREE.Vector3(-horizontal.z,0,horizontal.x);
  pivot.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),y);const inverse=pivot.quaternion.clone().invert();plumes.visible=firing;
  for(let i=0;i<2;i++){
   // Intersect the original rounded pod at its upper shoulder, above the solar
   // wings and well away from the underside camera.
   const p=side.clone().multiplyScalar(i===0?-.48:.48);p.y=1.62;
   const a=horizontal.x**2/1.10**2+horizontal.z**2/.79**2,b=2*(horizontal.x*p.x/1.10**2+horizontal.z*p.z/.79**2),c=p.x**2/1.10**2+p.z**2/.79**2+((p.y-1.25)/.71)**2-1;
   p.addScaledVector(horizontal,(-b+Math.sqrt(b*b-4*a*c))/(2*a)).addScaledVector(y,.025);ports[i].copy(p);outlets[i].position.copy(p).applyQuaternion(inverse);
   const pulse=.98+.035*Math.sin(time*24);jets[i].scale.y=pulse;jets[i].position.y=jetLength/2*pulse;
  }
 }};
}
