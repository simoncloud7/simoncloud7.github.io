// Only preferences owned by this scene; asset storage and photos are untouched.
export const SCENE_SETTING_KEYS=['planet-science-settings-v1','planet-lab-collapsed','planet-floating-panels-v1','planet-scene-panels-v1','planet-scene-panels-v2','planet-tidal-style'];
export function resetSceneSettings(storage){for(const key of SCENE_SETTING_KEYS)storage.removeItem(key)}
