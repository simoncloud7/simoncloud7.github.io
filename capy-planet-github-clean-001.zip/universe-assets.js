import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {radialFrame} from './relativity.mjs?v=7cfdf36453a6';
import {installLake} from './lake-runtime.js?v=7cfdf36453a6';
import {loadCachedModel} from './model-cache.mjs?v=7cfdf36453a6';
export async function loadUniverseAssets(onProgress){
 const [layout,kit]=await Promise.all(['./planet-layout.json?v=7cfdf36453a6','./universe-assets.json?v=7cfdf36453a6'].map(async u=>{const r=await fetch(u);if(!r.ok)throw Error(u);return r.json()}));
 const configs=await Promise.all([layout.export_manifest,kit.manifest].map(async path=>({path,manifest:await(await fetch('./'+path)).json()}))),map=new Map(),loader=new GLTFLoader();let done=0;
 const entries=configs.flatMap(({path,manifest})=>manifest.assets.map(item=>({item,url:'./'+path.slice(0,path.lastIndexOf('/')+1)+item.path}))),queue=[...new Map(entries.map(entry=>[entry.item.id,entry])).values()],total=queue.length;
 await Promise.all(Array.from({length:4},async()=>{while(queue.length){const {item,url}=queue.shift(),gltf=await loadCachedModel(loader,url,item);map.set(item.id,{item,gltf});onProgress(++done,total)}}));
 const clone=(id,scale=1)=>{const entry=map.get(id);if(!entry)throw Error('Missing asset '+id);const root=entry.gltf.scene.clone(true);root.scale.setScalar(scale);root.traverse(n=>{if(n.isPointLight)n.intensity=0});return {root,gltf:entry.gltf}};
 return {layout,kit,clone,count:map.size};
}
export function buildHomePlanet({layout,clone}){
 const globe=new THREE.Group(),up=new THREE.Vector3(0,1,0),frameAt=(x,z)=>{const f=radialFrame(x,z);return {normal:new THREE.Vector3(...f.normal),q:new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3(...f.east),new THREE.Vector3(...f.normal),new THREE.Vector3(...f.south)))}};
 const ocean=new THREE.Mesh(new THREE.SphereGeometry(18,96,64),new THREE.MeshStandardMaterial({color:0x438f9e,roughness:.65}));globe.add(ocean);
 const patch=(outline,radius,color,scale=1,q=null)=>{
  const shape=new THREE.Shape();outline.forEach(([x,z],i)=>i?shape.lineTo(x*scale,-z*scale):shape.moveTo(x*scale,-z*scale));shape.closePath();const flat=new THREE.ShapeGeometry(shape),pos=flat.attributes.position,ix=flat.index.array,verts=[];
  const map=v=>{const n=frameAt(v.x,-v.y).normal.multiplyScalar(radius);if(q)n.applyQuaternion(q);return n.toArray()};
  for(let k=0;k<ix.length;k+=3){const a=new THREE.Vector2(pos.getX(ix[k]),pos.getY(ix[k])),b=new THREE.Vector2(pos.getX(ix[k+1]),pos.getY(ix[k+1])),c=new THREE.Vector2(pos.getX(ix[k+2]),pos.getY(ix[k+2])),steps=Math.max(1,Math.ceil(Math.max(a.distanceTo(b),a.distanceTo(c),b.distanceTo(c))/1.4)),p=(i,j)=>a.clone().addScaledVector(b.clone().sub(a),i/steps).addScaledVector(c.clone().sub(a),j/steps);for(let i=0;i<steps;i++)for(let j=0;j<steps-i;j++){verts.push(...map(p(i,j)),...map(p(i+1,j)),...map(p(i,j+1)));if(j<steps-i-1)verts.push(...map(p(i+1,j)),...map(p(i+1,j+1)),...map(p(i,j+1)))}}
  flat.dispose();const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));g.computeVertexNormals();globe.add(new THREE.Mesh(g,new THREE.MeshStandardMaterial({color,roughness:1,side:THREE.DoubleSide})));
 };
 patch(layout.terrain.outline,18.055,0xd4c59e,1.045);patch(layout.terrain.outline,18.19,0x9bb680);
 for(const [angle,axis] of [[2.5,new THREE.Vector3(0,0,1)],[2.35,new THREE.Vector3(1,0,0)]]){const q=new THREE.Quaternion().setFromAxisAngle(axis,angle);patch(layout.terrain.outline,18.055,0xd4c59e,.62,q);patch(layout.terrain.outline,18.19,0x829f74,.59,q)}
 installLake({globe,cloneAsset:clone,asset:layout.lake_asset,mountainAsset:layout.fable_assets['linguo-mountain'],frameAt});
 for(const p of layout.surface_placements){
  if(p.motion==='cloud')continue;
  const root=clone(p.asset_id,p.scale).root,f=frameAt(p.position[0],p.position[2]);root.position.copy(f.normal.multiplyScalar(18.2+p.position[1]-.24));root.quaternion.copy(f.q).multiply(new THREE.Quaternion().setFromAxisAngle(up,p.rotation_y));globe.add(root);
 }
 globe.scale.setScalar(.34);return globe;
}
export function makeLabel(text,color='#d5e7e0'){
 const canvas=document.createElement('canvas');canvas.width=768;canvas.height=144;const ctx=canvas.getContext('2d');ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='500 48px "Microsoft JhengHei",sans-serif';ctx.shadowBlur=10;ctx.shadowColor='#070d1c';ctx.fillStyle=color;ctx.fillText(text,384,72);const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:texture,transparent:true,depthWrite:false}));sprite.scale.set(12,2.25,1);return sprite;
}
