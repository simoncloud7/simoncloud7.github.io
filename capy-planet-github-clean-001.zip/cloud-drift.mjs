const TAU=Math.PI*2;
export function cloudTracks(count,seed){
 let state=seed>>>0;const random=()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296};
 return Array.from({length:count},(_,i)=>({phase:TAU*i/count+random()*.85,latitude:[.42,-.36,.05][i%3]+(random()-.5)*.16,latitudeWave:.12+random()*.12,latitudePhase:random()*TAU,speed:[.014,-.011,.018][i%3]*(.85+random()*.3),heightWave:.18+random()*.18,size:.84+random()*.22,yaw:random()*TAU}));
}
export function cloudPose(track,time,radius){
 const phase=track.phase+time*track.speed,latitude=track.latitude+track.latitudeWave*Math.sin(phase*.63+track.latitudePhase),longitude=phase+.045*Math.sin(time*.017+track.latitudePhase),r=radius+track.heightWave*Math.sin(time*.012+track.phase),c=Math.cos(latitude);
 return {x:r*c*Math.sin(longitude),y:r*Math.sin(latitude),z:r*c*Math.cos(longitude),phase:longitude,yaw:track.yaw+.12*Math.sin(time*.006+track.phase)};
}
// A small guard band starts the fade before a drifting cloud reaches the disk.
export function blocksSolarView(offset,radius,sun){
 const distance2=offset[0]**2+offset[1]**2+offset[2]**2;if(distance2<=radius*radius)return true;
 const along=offset[0]*sun[0]+offset[1]*sun[1]+offset[2]*sun[2];if(along<=0||along>=120)return false;
 const guardedRadius=radius+along*.055;return distance2-along*along<=guardedRadius*guardedRadius;
}
export function cloudViewOpacity(current,target,seconds){
 if(!(seconds>0))return current;const next=target+(current-target)*Math.exp(-seconds/(target<current?.4:.85));return Math.abs(next-target)<.0005?target:next;
}
