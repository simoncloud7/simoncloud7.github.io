import * as THREE from 'three';
import {fleetPose,seaDistance} from './marine.mjs?v=cf9ebfe6af50';

// Clearance uses the whole rendered vessel, including its sails and mast.
// All positions stay in the rotating globe's coordinates.
export class MarineTrafficSafety{
 constructor({globe,ship,height=()=>0}){
  Object.assign(this,{globe,ship,height});ship.root.updateWorldMatrix(true,true);
  const inverse=ship.root.matrixWorld.clone().invert(),box=new THREE.Box3();
  ship.root.traverse(n=>{if(n.isMesh){n.geometry.computeBoundingBox();box.union(n.geometry.boundingBox.clone().applyMatrix4(inverse.clone().multiply(n.matrixWorld)))}});
  box.min.multiply(ship.root.scale);box.max.multiply(ship.root.scale);
  this.centerHeight=(box.min.y+box.max.y)/2-.38;
  this.radius=Math.hypot(Math.max(Math.abs(box.min.x),Math.abs(box.max.x)),(box.max.y-box.min.y)/2,Math.max(Math.abs(box.min.z),Math.abs(box.max.z)))+.35;
  this.visitorClearance=Math.max(6.6,this.radius+2.4);
  this.lane=Array.from({length:160},(_,t)=>fleetPose(ship.route,0,t).normal);
 }
 lineClear(normal,segments){
  const center=new THREE.Vector3(...normal).multiplyScalar(18+this.height(normal)+this.centerHeight),nearest=new THREE.Vector3();
  return segments.every(([a,b])=>new THREE.Line3(a,b).closestPointToPoint(center,true,nearest).distanceTo(center)>this.radius+1.2);
 }
 beginRescue(path,time,navTime,row){
  const segments=path.slice(1).map((p,i)=>[path[i].clone(),p.clone()]);
  // The final cabin descends at the pier end; protect its fall and float area too.
  const landing=path[0].clone().lerp(path[1],Math.min(1,1.9/path[0].distanceTo(path[1])));
  segments.push([landing,landing.clone().setLength(18)]);
  let target=navTime;const available=[true,true],rowGap=Math.min(6.8,seaDistance(fleetPose(this.ship.route,0,navTime).normal,row));
  search:for(let advance=0;advance<=160;advance+=.5)for(const [i,sign] of [1,-1].entries()){
   if(!available[i])continue;const candidate=navTime+sign*advance,n=fleetPose(this.ship.route,0,candidate).normal;
   if(seaDistance(n,row)<rowGap-1e-6){available[i]=false;continue}
   if(this.lineClear(n,segments)&&seaDistance(n,row)>6.8){target=candidate;break search}
  }
  this.reservation={segments,time,start:navTime,target,clear:this.lineClear(fleetPose(this.ship.route,0,target).normal,segments)};
  return this.reservation;
 }
 reservedTime(){const r=this.reservation;if(!r)return null;const t=Math.max(0,Math.min(1,r.time()/3)),ease=t*t*(3-2*t);return r.start+(r.target-r.start)*ease}
 endRescue(){this.reservation=null}
 visitSiteClear(normal){
  // Exclude the entire lane, not just the ship's position at portal opening.
  // This prevents a later walking/falling part of a visit from meeting the ship.
  const n=normal.toArray?normal.toArray():normal;
  return this.lane.every(point=>seaDistance(n,point)>=this.visitorClearance+3.6);
 }
 visitorHold(before,next,visitors){return visitors.some(n=>seaDistance(next,n)<this.visitorClearance&&seaDistance(next,n)<seaDistance(before,n))}
}
