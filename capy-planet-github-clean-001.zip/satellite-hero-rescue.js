import * as THREE from 'three';
import {setFlightPose} from './hero-style.js?v=b83abeea2990';
import {HERO_APPROACH_SECONDS,HERO_DEPART_SECONDS,REBOOST_SECONDS} from './satellite-orbit-story.mjs?v=b83abeea2990';
const up=new THREE.Vector3(0,1,0),smooth=x=>{const t=THREE.MathUtils.clamp(x,0,1);return t*t*(3-2*t)};
function outsideArc(a,b,u){const an=a.clone().normalize(),bn=b.clone().normalize(),turn=new THREE.Quaternion().setFromUnitVectors(an,bn),q=new THREE.Quaternion().slerp(turn,u);return an.applyQuaternion(q).multiplyScalar(THREE.MathUtils.lerp(a.length(),b.length(),u)+5*Math.sin(Math.PI*u))}

// Borrow the existing hero; no duplicate character and no camera ownership here.
export class SatelliteHeroRescue{
 constructor({fable,orbiter,globe}){Object.assign(this,{fable,orbiter,globe});this.root=fable.super;this.active=false;this.press=1}
 begin(state){
  if(this.active)this.cancel();this.globe.updateMatrixWorld(true);this.snapshot={position:this.root.position.clone(),quaternion:this.root.quaternion.clone(),visible:this.root.visible};this.start=this.root.getWorldPosition(new THREE.Vector3());this.serial=state.rescueSerial;this.active=true;this.fable.rescueActive=true;this.fable.history=[];this.fable.trail.visible=false;this.fable.rescueMemory.stop();this.press=1;
 }
 cancel(){if(!this.active)return;this.root.position.copy(this.snapshot.position);this.root.quaternion.copy(this.snapshot.quaternion);this.root.visible=this.snapshot.visible&&!this.fable.performing;this.fable.rescueActive=false;this.fable.history=[];document.body.dataset.heroStoryPaused='';this.active=false;this.report('complete',0)}
 report(phase,time){document.body.dataset.satelliteHeroRescue=JSON.stringify({active:this.active,phase,time,serial:this.serial,usesOriginalHero:true,externalForce:true,thrustersUsed:false})}
 update(dt,state,heading,paused=false){
  if(!state.rescueActive){this.cancel();return}if(!this.active||this.serial!==state.rescueSerial)this.begin(state);if(paused){this.report('paused',state.rescueTime);return}
  this.root.visible=!this.fable.performing;this.globe.updateMatrixWorld(true);const p=this.orbiter.root.getWorldPosition(new THREE.Vector3()),normal=p.clone().normalize(),q=this.globe.getWorldQuaternion(new THREE.Quaternion()),contact=p.clone().addScaledVector(normal,1.25).addScaledVector(heading,-2.8);let position,forward=heading.clone();
  if(state.rescuePhase==='approach'){
   const u=smooth(state.rescueTime/HERO_APPROACH_SECONDS);position=outsideArc(this.start,contact,u);const ahead=outsideArc(this.start,contact,Math.min(1,u+.003)).sub(position);if(ahead.lengthSq()>1e-8)forward.copy(ahead).normalize().lerp(heading,smooth((u-.65)/.35)).normalize();
  }else if(state.rescuePhase==='depart'){
   const u=smooth((state.rescueTime-HERO_APPROACH_SECONDS-REBOOST_SECONDS)/HERO_DEPART_SECONDS),home=this.snapshot.position.clone().applyMatrix4(this.globe.matrixWorld);position=outsideArc(contact,home,u);const ahead=outsideArc(contact,home,Math.min(1,u+.003)).sub(position);if(ahead.lengthSq()>1e-8)forward.copy(ahead).normalize();
  }else{
   const target=state.transfer?.firing?1:0;this.press=THREE.MathUtils.lerp(this.press,target,1-Math.exp(-dt*9));position=contact.clone().addScaledVector(heading,-.9*(1-this.press));
  }
  const radial=position.clone().normalize(),x=new THREE.Vector3().crossVectors(forward,radial.clone().negate());if(x.lengthSq()<1e-8){const side=new THREE.Vector3().crossVectors(this.orbiter.bodyOrbit.a,this.orbiter.bodyOrbit.b).applyQuaternion(q);x.crossVectors(forward,side)}x.normalize();const chest=new THREE.Vector3().crossVectors(x,forward).normalize(),worldQ=new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(x,forward,chest));
  this.root.position.copy(this.globe.worldToLocal(position));this.root.quaternion.copy(q.invert().multiply(worldQ));setFlightPose(this.root,0,{single:state.rescuePhase==='depart'?1:0,armBlend:['approach','depart'].includes(state.rescuePhase)?0:.65*(1-this.press)});
  if(!['approach','depart'].includes(state.rescuePhase))for(const side of [-1,1]){const arm=this.root.getObjectByName('arm-'+side);if(arm)arm.scale.y+=.2*this.press}
  for(const {mesh,base} of this.fable.capeMeshes){const vertices=mesh.geometry.attributes.position;for(let i=0;i<vertices.count;i++){const tail=THREE.MathUtils.clamp((1.42-base[i*3+1])/1.02,0,1);vertices.setZ(i,base[i*3+2]+.045*tail*Math.sin(state.rescueTime*8+base[i*3]*5+tail*4))}vertices.needsUpdate=true;mesh.geometry.computeVertexNormals()}
  this.report(state.rescuePhase,state.rescueTime);
 }
}
