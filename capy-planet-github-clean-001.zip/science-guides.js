import * as THREE from 'three';
import {ClockMarker,clockCaptionOffsets} from './clock-marker.js?v=f28a8f8b7fad';
import {clockAngularRate,clockSceneRadius,clockDialPeriod} from './clock-motion.mjs?v=f28a8f8b7fad';

// Explanatory geometry only: the clock's sampling radius is not an orbit solution.
export class ScienceGuides{
 constructor({scene,radius,sun}){
  Object.assign(this,{radius,sun});this.mode=null;
  this.clockGroup=new THREE.Group();this.lightGroup=new THREE.Group();
  for(const group of [this.clockGroup,this.lightGroup]){group.userData.sensorOverlay=true;group.visible=false;scene.add(group)}
  this.radial=new THREE.Vector3(.82,.36,.45).normalize();this.east=new THREE.Vector3(this.radial.z,0,-this.radial.x).normalize();
  this.axisA=new THREE.Vector3(1,0,0);this.axisB=new THREE.Vector3(0,1,0);this.angle=Math.PI*.72;this.experiment='clocks';this.withGravity=false;
  this.groundClock=new ClockMarker(0xa4d9dd);this.movingClock=new ClockMarker(0xf3cd88);this.remoteClock=new ClockMarker(0xc8c3ed);
  for(const clock of [this.groundClock,this.movingClock,this.remoteClock])this.clockGroup.add(clock.group);
  this.radiusLine=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),new THREE.Vector3()]),new THREE.LineDashedMaterial({color:0xf3cd88,dashSize:.45,gapSize:.3,transparent:true,opacity:.6}));this.radiusLine.frustumCulled=false;this.clockGroup.add(this.radiusLine);
  this.ring=new THREE.LineLoop(new THREE.BufferGeometry(),new THREE.LineBasicMaterial({color:0xf3cd88,transparent:true,opacity:.35}));this.clockGroup.add(this.ring);
  const direction=sun.position.clone().normalize();
  this.star=new THREE.Mesh(new THREE.SphereGeometry(2,32,24),new THREE.MeshBasicMaterial({color:0xffd79c}));this.star.position.copy(direction).multiplyScalar(50);this.lightGroup.add(this.star);
  const side=new THREE.Vector3().crossVectors(direction,new THREE.Vector3(0,0,1)).normalize(),other=new THREE.Vector3().crossVectors(direction,side).normalize();
  for(const offset of [-10,0,10]){const start=direction.clone().multiplyScalar(46).addScaledVector(side,offset).addScaledVector(other,3);this.lightGroup.add(new THREE.ArrowHelper(direction.clone().negate(),start,25,0xf3cd88,1.2,.65))}
  this.setRadius(1.5);this.setClockEnabled(document.querySelector('#clock-view').getAttribute('aria-pressed')==='true');this.setLightingEnabled(document.querySelector('#lighting-view').getAttribute('aria-pressed')==='true');
 }
 configureClock(experiment,withGravity){if(this.experiment===experiment&&this.withGravity===withGravity)return;this.experiment=experiment;this.withGravity=withGravity;this.shapeKey='';this.setRadius(this.rho)}
 orientOrbit(camera,globeQuaternion){camera.updateMatrixWorld(true);const inverse=globeQuaternion.clone().invert(),front=camera.position.clone().normalize(),cameraUp=new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld,1);
  this.axisA.setFromMatrixColumn(camera.matrixWorld,0).normalize().applyQuaternion(inverse);this.axisB.copy(cameraUp).normalize().applyQuaternion(inverse);this.radial.copy(front).multiplyScalar(Math.cos(.6)).addScaledVector(cameraUp,Math.sin(.6)).normalize().applyQuaternion(inverse);this.east.copy(this.axisA);this.shapeKey='';this.setRadius(this.rho);
 }
 setRadius(rho){this.rho=rho;const displayRho=clockSceneRadius(this.experiment,this.withGravity,rho),key=this.experiment+':'+displayRho;if(key===this.shapeKey)return;this.shapeKey=key;
  const r=this.radius*displayRho;this.ring.geometry.dispose();this.ring.geometry=new THREE.BufferGeometry().setFromPoints(Array.from({length:192},(_,i)=>this.axisA.clone().multiplyScalar(r*Math.cos(i/192*Math.PI*2)).addScaledVector(this.axisB,r*Math.sin(i/192*Math.PI*2))));
  this.ring.visible=this.experiment==='clocks';this.radiusLine.visible=this.experiment==='gravity'||this.withGravity;
 }
 resetMotion(){this.angle=Math.PI*.72}
 advance(dt,rate){if(this.experiment!=='clocks')return;const rho=clockSceneRadius(this.experiment,rate.withGravity,this.rho);this.angle+=dt*clockAngularRate(rate.sampleBeta,rho,rate.withGravity?this.compactness:0)}
 setClockEnabled(enabled){this.clockEnabled=enabled;this.clockGroup.visible=enabled;const button=document.querySelector('#clock-view');button.setAttribute('aria-pressed',String(enabled));button.textContent=enabled?'停用時鐘位置與走時':'啟用時鐘位置與走時';if(!enabled&&this.mode==='clocks')this.show(null)}
 setLightingEnabled(enabled){this.lightingEnabled=enabled;this.lightGroup.visible=enabled;const button=document.querySelector('#lighting-view');button.setAttribute('aria-pressed',String(enabled));button.textContent=enabled?'停用光源方向標示':'啟用光源方向標示';if(!enabled&&this.mode==='lighting')this.show(null)}
 show(mode){this.mode=mode;this.clockGroup.visible=this.clockEnabled;this.lightGroup.visible=this.lightingEnabled;const guide=document.querySelector('#scene-guide');if(mode)document.querySelector(mode==='lighting'?'#scene-settings-guidance':'#clock-guidance').append(guide);guide.hidden=!mode}
 cameraPose(mode){if(mode==='lighting')return {position:new THREE.Vector3(64,32,105),target:this.star.position.clone().multiplyScalar(.23)};
  const extent=Math.max(24,this.radius*clockSceneRadius(this.experiment,this.withGravity,this.rho)+8),distance=extent*3.5;return {position:new THREE.Vector3(0,distance*.15,distance),target:new THREE.Vector3()};
 }
 update(camera,{rate,compactness,rho,referenceSeconds,sampleSeconds,timeScale,globeQuaternion}){
  camera.updateMatrixWorld(true);this.compactness=compactness;this.configureClock(rate.experiment,rate.withGravity);this.setRadius(rho);
  const displayRho=clockSceneRadius(this.experiment,rate.withGravity,rho),period=clockDialPeriod(timeScale),groundRate=rate.withGravity?Math.sqrt(1-compactness):1,groundSeconds=referenceSeconds*groundRate/rate.reference;
  const groundNormal=this.radial.clone().multiplyScalar(Math.cos(.27)).addScaledVector(this.east,-Math.sin(.27));
  const sampleNormal=this.experiment==='clocks'?this.axisA.clone().multiplyScalar(Math.cos(this.angle)).addScaledVector(this.axisB,Math.sin(this.angle)):this.radial.clone().multiplyScalar(Math.cos(.27)).addScaledVector(this.east,Math.sin(.27));
  const ground=groundNormal.multiplyScalar(this.radius).applyQuaternion(globeQuaternion),sample=sampleNormal.clone().multiplyScalar(this.radius*displayRho).applyQuaternion(globeQuaternion);
  const difference=sampleSeconds-referenceSeconds,amount=Math.abs(difference),delta=amount<1e-6?(amount*1e9).toFixed(2)+' ns':amount<.001?(amount*1e6).toFixed(2)+' μs':amount.toFixed(3)+' s';
  const ref=rate.withGravity&&rate.referenceChoice==='infinity'?'∞參考':'地表';
  const detail=amount<1e-12?'與'+ref+'同時起算':'比'+ref+(difference<0?'慢 ':'快 ')+delta;
  const tangent=this.axisA.clone().multiplyScalar(-Math.sin(this.angle)).addScaledVector(this.axisB,Math.cos(this.angle)).applyQuaternion(globeQuaternion),roles=this.actorSystem?.poseClocks({camera,ground,sample,groundNormal:ground.clone().normalize(),sampleNormal:sample.clone().normalize(),tangent,rate});
  const occluded=point=>{const segment=point.clone().sub(camera.position),t=Math.max(0,Math.min(1,-camera.position.dot(segment)/segment.lengthSq()));return camera.position.clone().addScaledVector(segment,t).length()<this.radius-.04},groundBehind=occluded(roles?.ground||ground),sampleBehind=occluded(roles?.sample||sample);
  this.groundClock.update(camera,roles?.ground||ground,{title:(roles?.groundTitle||'地表鐘 · 靜止')+(groundBehind?' · 背側':''),seconds:groundSeconds,period,detail:rate.withGravity?'同一顆星球的表面':'靜止參考'});
  this.movingClock.update(camera,roles?.sample||sample,{title:(roles?.sampleTitle||(this.experiment==='clocks'?'移動鐘 · '+rate.sampleBeta.toFixed(3)+' c':'高處鐘 · '+(6371*(rho-1)).toLocaleString('zh-TW',{maximumFractionDigits:0})+' km'))+(sampleBehind?' · 背側':''),seconds:sampleSeconds,period,detail});
  this.actorSystem?.setBackside(groundBehind,sampleBehind);
  // Both annotations stay above their dials; collisions only cause a small,
  // smoothly limited horizontal adjustment.
  for(const clock of [this.groundClock,this.movingClock])clock.label.position.y=clock.worldDialRadius?Math.max(8,clock.label.scale.y/2+1.1/clock.group.scale.x):8;
  this.actorSystem?.placeCaption(camera);
  const attribute=this.radiusLine.geometry.attributes.position,base=sampleNormal.clone().multiplyScalar(this.radius).applyQuaternion(globeQuaternion);attribute.setXYZ(0,base.x,base.y,base.z);attribute.setXYZ(1,sample.x,sample.y,sample.z);attribute.needsUpdate=true;this.radiusLine.computeLineDistances();this.ring.quaternion.copy(globeQuaternion);
  this.groundClock.group.visible=this.movingClock.group.visible=true;
  const clocks=[this.groundClock,this.movingClock],rects=clocks.map(clock=>{clock.group.updateWorldMatrix(true,true);const project=(x,y)=>{const p=clock.group.localToWorld(new THREE.Vector3(x,y,0)).project(camera);return {x:(p.x+1)*innerWidth/2,y:(1-p.y)*innerHeight/2}},left=project(-clock.label.scale.x/2,clock.label.position.y),right=project(clock.label.scale.x/2,clock.label.position.y),top=project(0,clock.label.position.y+clock.label.scale.y/2),bottom=project(0,clock.label.position.y-clock.label.scale.y/2);return {x:left.x,y:top.y,width:right.x-left.x,height:bottom.y-top.y}});
  this.clockLabelOffsets=clockCaptionOffsets(rects[0],rects[1],this.clockLabelOffsets,this.groundClock.group.visible&&this.movingClock.group.visible);for(const [i,clock] of clocks.entries())clock.label.position.x=this.clockLabelOffsets[i]*clock.label.scale.x/Math.max(1,rects[i].width);
  this.remoteClock.group.visible=rate.withGravity&&rate.referenceChoice==='infinity';
  if(this.remoteClock.group.visible){const extent=Math.max(24,this.radius*displayRho),position=camera.position.clone().multiplyScalar(.18).addScaledVector(new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld,0),-extent*.85).addScaledVector(new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld,1),extent*.7);this.remoteClock.update(camera,position,{title:'∞ 參考鐘',seconds:referenceSeconds,period,detail:'無限遠基準'});}
  document.body.dataset.planetClocks=JSON.stringify({enabled:this.clockEnabled,experiment:this.experiment,angle:this.angle,radius:displayRho,angularRate:this.experiment==='clocks'?clockAngularRate(rate.sampleBeta,displayRho,rate.withGravity?compactness:0):0,ground:ground.toArray(),sample:sample.toArray(),displayGround:(roles?.ground||ground).toArray(),displaySample:(roles?.sample||sample).toArray(),groundBehind,sampleBehind,groundSeconds,sampleSeconds,referenceSeconds,period,labelOffsetPixels:this.clockLabelOffsets,labelVerticalOffsets:[this.groundClock.label.position.y,this.movingClock.label.position.y],groundVisible:this.groundClock.group.visible,sampleVisible:this.movingClock.group.visible,localBeta:rate.sampleBeta,heldRadius:true});
 }

}
