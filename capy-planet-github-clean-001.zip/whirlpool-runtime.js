import * as THREE from 'three';
import {findVortexCenter,findOpenOceanVortex,vortexPathClear,vortexBasis,vortexBoatPose,ease,VORTEX_LIFETIME} from './whirlpool.mjs?v=fb41883b52d5';
import {routePosition,seaDistance,dot,pierDistance,inProtectedHarbor} from './marine.mjs?v=fb41883b52d5';
const $=s=>document.querySelector(s);
export class WhirlpoolSystem{
 constructor({globe,uniforms,isWater,tideHeight}){
  Object.assign(this,{globe,uniforms,isWater,tideHeight});this.nextAt=20;this.sequence=0;this.recentCenters=[];this.seed=Math.floor(Math.random()*0xffffffff);this.losses=0;this.respawns=0;this.escapes=0;this.active=null;this.pending=null;
  Object.assign(uniforms,{uVortexCenter:{value:new THREE.Vector3(1,0,0)},uVortexEast:{value:new THREE.Vector3(0,1,0)},uVortexSouth:{value:new THREE.Vector3(0,0,1)},uVortexDepth:{value:0}});
  this.group=new THREE.Group();this.group.visible=false;globe.add(this.group);
  const v=[],indices=[];for(let arm=0;arm<5;arm++)for(let i=0;i<=100;i++)for(const side of [-1,1]){const r=.25+i/100*3.45,a=arm*Math.PI*2/5+r*2.2+side*(.015+.012*r);v.push(r*Math.cos(a),0,r*Math.sin(a));if(side===1&&i<100){const n=arm*202+i*2;indices.push(n,n+1,n+2,n+1,n+3,n+2)}}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(v,3));g.setIndex(indices);this.foam=new THREE.Mesh(g,new THREE.MeshBasicMaterial({color:0xd2f0e8,side:THREE.DoubleSide,transparent:true,opacity:.8,depthWrite:false}));this.foam.frustumCulled=false;this.group.add(this.foam);
 }
 random(){this.seed=(Math.imul(this.seed,1664525)+1013904223)>>>0;return this.seed/4294967296}
 request(kind){this.pending=kind;this.previewing=true;this.searchAt=0}
 get performanceActive(){return !!this.previewing&&!!(this.pending||this.active)}
 depression(n){return this.active?this.uniforms.uVortexDepth.value*Math.exp(-Math.pow(seaDistance(n,this.active.center)/2.15,2)):0}
 get holdsShip(){return this.active?.kind==='ship'&&!this.active.completed}
 update(elapsed,context){
  let rowPose=null,shipPose=null,respawn=false,resumeAt=null;
  if(!this.active&&elapsed>=(this.searchAt||0)&&(this.pending||elapsed>=this.nextAt)){
   this.searchAt=elapsed+.5;
   const kind=this.pending||(this.sequence%3===1?'ambient':this.sequence%3===2?'ship':'row'),start=kind==='row'?context.rowNormal:context.main.normal,other=kind==='row'?context.main.normal:context.rowNormal;
   if(kind==='ambient'){
    const center=findOpenOceanVortex(this.isWater,this.recentCenters,this.random()*100);
    if(center){this.active={kind,center,at:elapsed,completed:false};this.sequence++;this.recentCenters.push(center);}
   }else if(!(kind==='ship'&&(context.main.docked||context.shipProtected))&&elapsed>=(kind==='row'?context.rowImmuneUntil:0)){
    const escape=routePosition(context.route,context.distance+9).normal;
    const center=findVortexCenter(start,this.isWater,other,c=>vortexPathClear(kind,c,start,escape,this.isWater),{phase:this.random()*100,recent:this.pending?[]:this.recentCenters});
    if(center){this.active={kind,center,start:[...start],at:elapsed,escape,resumeAt:context.navTime+9/(context.route.total/(160-9)),completed:false};this.pending=null;this.sequence++;this.recentCenters.push(center);}
   }
   if(this.recentCenters.length>5)this.recentCenters.shift();
  }
  if(!this.active&&!this.pending&&elapsed>this.nextAt+8){this.sequence++;this.nextAt=elapsed}
  const event=this.active;
  if(event){
   const age=elapsed-event.at,amount=ease(age/1.5)*(1-ease((age-19)/5)),b=vortexBasis(event.center,[0,1,0]);this.uniforms.uVortexCenter.value.fromArray(event.center);this.uniforms.uVortexEast.value.fromArray(b.east);this.uniforms.uVortexSouth.value.fromArray(b.south);this.uniforms.uVortexDepth.value=1.25*amount;
   this.group.visible=true;this.group.position.fromArray(event.center).multiplyScalar(18+this.tideHeight(event.center));this.group.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3(...b.east),new THREE.Vector3(...event.center),new THREE.Vector3(...b.south)));this.foam.rotation.y=-age*1.2;this.foam.material.opacity=.8*amount;
   const p=this.foam.geometry.attributes.position;for(let i=0;i<p.count;i++){const r=Math.hypot(p.getX(i),p.getZ(i));p.setY(i,-this.uniforms.uVortexDepth.value*Math.exp(-((r/2.15)**2))-r*r/36+.16)}p.needsUpdate=true;
   if(event.kind==='ambient'&&age>=1.5&&age<12){
    const escape=routePosition(context.route,context.distance+9).normal;
    const kind=elapsed>=context.rowImmuneUntil&&seaDistance(context.rowNormal,event.center)<3.6?'row':!context.shipProtected&&!context.main.docked&&seaDistance(context.main.normal,event.center)<3.6?'ship':null;
    const start=kind==='row'?context.rowNormal:context.main.normal;
    if(kind&&vortexPathClear(kind,event.center,start,escape,this.isWater))Object.assign(event,{kind,start:[...start],escape,captureAt:elapsed-1.5,resumeAt:context.navTime+9/(context.route.total/(160-9))});
   }
   if(event.kind!=='ambient'&&age>=1.5&&!event.completed){const pose=vortexBoatPose(event,event.captureAt===undefined?age:elapsed-event.captureAt);
    if(event.kind==='row'){rowPose=pose;if(pose.stage==='lost'&&!event.lossCounted){this.losses++;event.lossCounted=true}if(pose.respawn){respawn=true;this.respawns++;event.completed=true;rowPose=null}}
    else{shipPose=pose;if(pose.escaped){this.escapes++;event.completed=true;resumeAt=event.resumeAt;shipPose=null}}
   }
   if(age>=VORTEX_LIFETIME){this.active=null;if(!this.pending)this.previewing=false;this.group.visible=false;this.uniforms.uVortexDepth.value=0;this.nextAt=elapsed+24+this.random()*30}
  }else{this.uniforms.uVortexDepth.value=0;this.group.visible=false}
  const active=this.active,label=shipPose?.stage==='escaping'?'大船加力 · 駛離旋渦':rowPose?.stage==='sinking'?'小艇水平旋轉下沉':rowPose?.hidden?'小艇已捲入 · 碼頭準備重生':active?.completed?(active.kind==='row'?'小艇已回到碼頭 · 旋渦漸散':'大船已脫困 · 旋渦漸散'):active?.kind==='ambient'?'外海自然旋渦 · 船隻尚未接近':active?(active.kind==='row'?'旋渦捲入小艇 · 水面盤旋':'大船遭遇旋渦 · 盤旋脫困'):this.pending?(inProtectedHarbor(this.pending==='row'?context.rowNormal:context.main.normal)?'港區無旋渦 · 等候船隻出港':'等待船隻進入合適海域'):'海面平靜 · 旋渦會不時出現';
  $('#ocean-event').textContent=label;this.report={recentCenters:this.recentCenters,seed:this.seed,active:!!active,kind:active?.kind||null,center:active?.center||null,pierDistance:active?pierDistance(active.center):null,harborExcluded:true,age:active?elapsed-active.at:null,stage:rowPose?.stage||shipPose?.stage||null,losses:this.losses,respawns:this.respawns,escapes:this.escapes,pending:this.pending};
  return {rowPose,shipPose,respawn,resumeAt};
 }
}
