// Safari can report the settled viewport after orientationchange. Listen to
// the visual viewport as well as the layout viewport, then sample it again.
export function deviceViewport(env=globalThis){
 const v=env.visualViewport,useVisual=v&&Math.abs((v.scale||1)-1)<.02;
 const dimension=(visual,inner,client)=>Math.max(1,Math.round((useVisual&&visual>0?visual:inner>0?inner:client)||1));
 return {width:dimension(v?.width,env.innerWidth,env.document?.documentElement?.clientWidth),height:dimension(v?.height,env.innerHeight,env.document?.documentElement?.clientHeight),left:useVisual?Math.round(v.offsetLeft||0):0,top:useVisual?Math.round(v.offsetTop||0):0};
}
export function watchDeviceViewport(callback,env=globalThis){
 const events=[],timers=new Set();let pending=false;
 const queue=()=>{if(pending)return;pending=true;env.requestAnimationFrame(()=>{pending=false;callback()})};
 const settle=()=>{queue();for(const id of timers)env.clearTimeout(id);timers.clear();for(const delay of [120,450,1000]){const id=env.setTimeout(()=>{timers.delete(id);queue()},delay);timers.add(id)}};
 const listen=(target,name,fn)=>{target?.addEventListener(name,fn,{passive:true});events.push([target,name,fn])};
 listen(env,'resize',settle);listen(env,'orientationchange',settle);listen(env,'pageshow',settle);listen(env.visualViewport,'resize',settle);listen(env.visualViewport,'scroll',queue);listen(env.screen?.orientation,'change',settle);
 const observer=env.ResizeObserver&&env.document?.documentElement?new env.ResizeObserver(queue):null;observer?.observe(env.document.documentElement);
 return {queue,dispose(){observer?.disconnect();for(const [target,name,fn] of events)target?.removeEventListener(name,fn);for(const id of timers)env.clearTimeout(id)}};
}
