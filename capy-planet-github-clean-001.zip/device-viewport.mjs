// Use the browser-visible frame even while WebKit's document/CSS box is stale.
// At pinch zoom, release the override so the browser retains native zoom.
const recoveringFrames=new WeakSet();
export function visibleViewport(env=globalThis){
 const v=env.visualViewport,width=Number(v?.width),height=Number(v?.height),scale=Number(v?.scale??1);
 if(!v||!(width>0&&height>0&&Number.isFinite(width)&&Number.isFinite(height)&&Number.isFinite(scale))||Math.abs(scale-1)>.01)return null;
 return {width,height,left:Number(v.offsetLeft)||0,top:Number(v.offsetTop)||0};
}
export function attachBrowserViewport({root,env=globalThis,onSettled=()=>{}}){
 const names=['width','height','left','top'],listeners=[];let generation=0,frame=null,timer=null,deadline=null,disposed=false;
 const reset=()=>{for(const key of names)root.style.removeProperty('--browser-'+key)};
 const refresh=()=>{
  if(disposed||recoveringFrames.has(root))return;
  const view=visibleViewport(env);if(!view){reset();return}
  for(const key of names){const name='--browser-'+key,value=view[key]+'px';if(root.style.getPropertyValue(name)!==value)root.style.setProperty(name,value)}
 };
 const cancelRecovery=()=>{generation++;if(frame!==null)env.cancelAnimationFrame?.(frame);for(const id of [timer,deadline])if(id!==null)env.clearTimeout?.(id);frame=timer=deadline=null;recoveringFrames.delete(root)};
 const reflow=()=>{
  if(disposed)return;if(!visibleViewport(env)||!env.requestAnimationFrame||!env.setTimeout){refresh();return}
  cancelRecovery();const current=generation;recoveringFrames.add(root);reset();
  const finish=()=>{if(disposed||generation!==current)return;cancelRecovery();refresh();onSettled()};
  // The browser may withhold animation frames during rotation. Recovery must
  // still finish, resize and paint without waiting for the address bar to wake it.
  deadline=env.setTimeout(finish,450);
  // Let WebKit commit its own document size before sampling it again. The
  // scene render loop yields during this interval; no focus or fake resize.
  root.getBoundingClientRect?.();
  frame=env.requestAnimationFrame(()=>{if(disposed||generation!==current)return;root.getBoundingClientRect?.();frame=env.requestAnimationFrame(()=>{
   if(disposed||generation!==current)return;frame=null;timer=env.setTimeout(finish,200);
  })});
 };
 const listen=(target,type,handler=refresh)=>{target?.addEventListener?.(type,handler,{passive:true});listeners.push(()=>target?.removeEventListener?.(type,handler))};
 for(const type of ['resize','pageshow','focus'])listen(env,type);listen(env.visualViewport,'resize');listen(env.visualViewport,'scroll');
 listen(env,'orientationchange',reflow);listen(env.screen?.orientation,'change',reflow);
 for(const type of ['focusin','focusout','visibilitychange'])listen(env.document,type);
 refresh();return {refresh,reset,get settling(){return recoveringFrames.has(root)},destroy(){disposed=true;listeners.forEach(off=>off());cancelRecovery();reset()}};
}
// A viewport update must not depend solely on requestAnimationFrame: mobile
// Chrome can defer that callback while native browser chrome is transitioning.
export function viewportTask(callback,env=globalThis){
 let pending=false,frame=null,timer=null;
 const cancel=()=>{pending=false;if(frame!==null)env.cancelAnimationFrame?.(frame);if(timer!==null)env.clearTimeout?.(timer);frame=timer=null};
 const run=()=>{if(!pending)return;cancel();callback()};
 return {queue(){if(pending)return;pending=true;frame=env.requestAnimationFrame(run);timer=env.setTimeout(run,50)},dispose:cancel};
}
export function elementViewport(element){
 const rect=element?.getBoundingClientRect?.();if(!rect)return null;const width=Number(element.clientWidth)||rect.width,height=Number(element.clientHeight)||rect.height;
 if(!(width>0&&height>0&&Number.isFinite(width)&&Number.isFinite(height)))return null;
 return {width:Math.floor(width),height:Math.floor(height),left:Math.round(rect.left||0),top:Math.round(rect.top||0)};
}
export function deviceViewport(env=globalThis){
 if(recoveringFrames.has(env.document?.documentElement)){const native=elementViewport(env.document?.getElementById?.('cosmos'));if(native)return native}
 const visual=visibleViewport(env);if(visual)return Object.fromEntries(Object.entries(visual).map(([key,value])=>[key,Math.round(value)]));
 // Native CSS remains the fallback when visible bounds are unavailable or
 // the user is zooming. Never reuse a previously captured visible rectangle.
 const scene=elementViewport(env.document?.getElementById?.('cosmos'));if(scene)return scene;
 const dimension=(inner,client)=>Math.max(1,Math.round((inner>0?inner:client)||1));
 return {width:dimension(env.innerWidth,env.document?.documentElement?.clientWidth),height:dimension(env.innerHeight,env.document?.documentElement?.clientHeight),left:0,top:0};
}
export function watchDeviceViewport(callback,env=globalThis){
 const events=[],timers=new Set(),task=viewportTask(callback,env),queue=task.queue;
 const settle=()=>{queue();for(const id of timers)env.clearTimeout(id);timers.clear();for(const delay of [120,450,1000]){const id=env.setTimeout(()=>{timers.delete(id);queue()},delay);timers.add(id)}};
 const listen=(target,name,fn)=>{target?.addEventListener(name,fn,{passive:true});events.push([target,name,fn])};
 listen(env,'resize',settle);listen(env,'orientationchange',settle);listen(env,'pageshow',settle);listen(env.visualViewport,'resize',settle);listen(env.visualViewport,'scroll',queue);listen(env.screen?.orientation,'change',settle);
 const observer=env.ResizeObserver&&env.document?.documentElement?new env.ResizeObserver(queue):null;observer?.observe(env.document.documentElement);
 return {queue,dispose(){task.dispose();observer?.disconnect();for(const [target,name,fn] of events)target?.removeEventListener(name,fn);for(const id of timers)env.clearTimeout(id)}};
}
