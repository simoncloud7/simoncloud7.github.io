// Safari can report the settled viewport after orientationchange. Listen to
// the visual viewport as well as the layout viewport, then sample it again.
export function deviceViewport(env=globalThis){
 const v=env.visualViewport,useVisual=v&&Math.abs((v.scale||1)-1)<.02;
 return {width:Math.max(1,Math.round(useVisual?v.width:env.innerWidth)),height:Math.max(1,Math.round(useVisual?v.height:env.innerHeight)),left:useVisual?Math.round(v.offsetLeft||0):0,top:useVisual?Math.round(v.offsetTop||0):0};
}
export function watchDeviceViewport(callback,env=globalThis){
 const events=[],timers=[];let pending=false;
 const queue=()=>{if(pending)return;pending=true;env.requestAnimationFrame(()=>{pending=false;callback()})};
 const settle=()=>{queue();for(const delay of [120,450])timers.push(env.setTimeout(queue,delay))};
 const listen=(target,name,fn)=>{target?.addEventListener(name,fn,{passive:true});events.push([target,name,fn])};
 listen(env,'resize',settle);listen(env,'orientationchange',settle);listen(env,'pageshow',settle);listen(env.visualViewport,'resize',queue);listen(env.visualViewport,'scroll',queue);listen(env.screen?.orientation,'change',settle);
 return {queue,dispose(){for(const [target,name,fn] of events)target?.removeEventListener(name,fn);for(const id of timers)env.clearTimeout(id)}};
}
