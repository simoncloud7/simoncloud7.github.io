// Use the browser-visible frame even while WebKit's document/CSS box is stale.
// At pinch zoom, release the override so the browser retains native zoom.
export function visibleViewport(env=globalThis){
 const v=env.visualViewport,width=Number(v?.width),height=Number(v?.height),scale=Number(v?.scale??1);
 if(!v||!(width>0&&height>0&&Number.isFinite(width)&&Number.isFinite(height)&&Number.isFinite(scale))||Math.abs(scale-1)>.01)return null;
 return {width,height,left:Number(v.offsetLeft)||0,top:Number(v.offsetTop)||0};
}
export function attachBrowserViewport({root,env=globalThis}){
 const names=['width','height','left','top'],listeners=[];
 const reset=()=>{for(const key of names)root.style.removeProperty('--browser-'+key)};
 const refresh=()=>{
  const view=visibleViewport(env);if(!view){reset();return}
  for(const key of names){const name='--browser-'+key,value=view[key]+'px';if(root.style.getPropertyValue(name)!==value)root.style.setProperty(name,value)}
 };
 const listen=(target,type)=>{target?.addEventListener?.(type,refresh,{passive:true});listeners.push(()=>target?.removeEventListener?.(type,refresh))};
 for(const type of ['resize','pageshow'])listen(env,type);listen(env.visualViewport,'resize');listen(env.visualViewport,'scroll');
 for(const type of ['focusin','focusout','visibilitychange'])listen(env.document,type);
 refresh();return {refresh,reset,destroy(){listeners.forEach(off=>off());reset()}};
}
export function elementViewport(element){
 const rect=element?.getBoundingClientRect?.();if(!rect)return null;const width=Number(element.clientWidth)||rect.width,height=Number(element.clientHeight)||rect.height;
 if(!(width>0&&height>0&&Number.isFinite(width)&&Number.isFinite(height)))return null;
 return {width:Math.floor(width),height:Math.floor(height),left:Math.round(rect.left||0),top:Math.round(rect.top||0)};
}
export function deviceViewport(env=globalThis){
 const visual=visibleViewport(env);if(visual)return Object.fromEntries(Object.entries(visual).map(([key,value])=>[key,Math.round(value)]));
 // Native CSS remains the fallback when visible bounds are unavailable or
 // the user is zooming. Never reuse a previously captured visible rectangle.
 const scene=elementViewport(env.document?.getElementById?.('cosmos'));if(scene)return scene;
 const dimension=(inner,client)=>Math.max(1,Math.round((inner>0?inner:client)||1));
 return {width:dimension(env.innerWidth,env.document?.documentElement?.clientWidth),height:dimension(env.innerHeight,env.document?.documentElement?.clientHeight),left:0,top:0};
}
export function watchDeviceViewport(callback,env=globalThis){
 const events=[],timers=new Set();let pending=false;
 const queue=()=>{if(pending)return;pending=true;env.requestAnimationFrame(()=>{pending=false;callback()})};
 const settle=()=>{queue();for(const id of timers)env.clearTimeout(id);timers.clear();for(const delay of [120,450,1000]){const id=env.setTimeout(()=>{timers.delete(id);queue()},delay);timers.add(id)}};
 const listen=(target,name,fn)=>{target?.addEventListener(name,fn,{passive:true});events.push([target,name,fn])};
 listen(env,'resize',settle);listen(env,'orientationchange',settle);listen(env,'pageshow',settle);listen(env.visualViewport,'resize',settle);listen(env.visualViewport,'scroll',queue);listen(env.screen?.orientation,'change',settle);
 const observer=env.ResizeObserver&&env.document?.documentElement?new env.ResizeObserver(queue):null;observer?.observe(env.document.documentElement);
 return {queue,dispose(){observer?.disconnect();for(const [target,name,fn] of events)target?.removeEventListener(name,fn);for(const id of timers)env.clearTimeout(id)}};
}
