import {clockRates} from './gravity.mjs?v=63ea14151482';

// Gravity compares static clocks. Velocity is used only by the speed experiment.
export function clockExperiment({experiment='clocks',compactness,radius,beta,combineGravity=false,reference='surface'}){
 const withGravity=experiment==='gravity'||combineGravity;
 const sampleBeta=experiment==='gravity'?0:beta;
 const referenceChoice=withGravity?reference:'infinity';
 return {...clockRates(compactness,radius,sampleBeta,{gravity:withGravity,reference:referenceChoice}),withGravity,sampleBeta,referenceChoice,experiment};
}
