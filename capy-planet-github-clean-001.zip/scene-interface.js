// Keep page chrome separate from the WebGL scene and its camera state.
export class SceneInterface{
 constructor({canvas,render}){
  Object.assign(this,{canvas,render});this.hidden=false;this.capturing=false;
  this.toggle=document.querySelector('#scene-interface-toggle');this.restore=document.querySelector('#scene-ui-return');this.captureButton=document.querySelector('#scene-snapshot');this.status=document.querySelector('#scene-snapshot-status');
  this.toggle.onclick=()=>this.setHidden(true);this.restore.onclick=()=>this.setHidden(false);this.captureButton.onclick=()=>this.capture();
  const reveal=e=>{if(!this.hidden)return;if(e.clientX<=28)document.body.classList.add('ui-return-visible');else if(e.clientX>180)document.body.classList.remove('ui-return-visible')};
  document.addEventListener('pointermove',reveal,{passive:true});document.addEventListener('pointerdown',reveal,{passive:true});
  document.addEventListener('keydown',e=>{
   if(e.key==='Escape'&&this.hidden){e.preventDefault();this.setHidden(false);return}
   if(e.repeat||e.isComposing||e.ctrlKey||e.metaKey||e.altKey||e.target.closest?.('input,select,textarea,[contenteditable="true"]')||document.querySelector('dialog[open]'))return;
   if(e.key.toLowerCase()==='h'){e.preventDefault();this.setHidden(!this.hidden)}
   else if(e.key.toLowerCase()==='p'){e.preventDefault();this.capture()}
  });
 }
 setHidden(hidden){
  if(this.hidden===hidden)return;this.hidden=hidden;
  if(hidden){this.previousFocus=document.activeElement;this.previousFocus?.blur?.()}
  document.body.classList.toggle('scene-ui-hidden',hidden);document.body.classList.remove('ui-return-visible');document.body.dataset.interfaceHidden=String(hidden);this.restore.hidden=!hidden;this.toggle.setAttribute('aria-pressed',String(hidden));
  if(!hidden){const target=this.previousFocus?.getClientRects().length?this.previousFocus:document.querySelector('#nav-display-toggle');target?.focus({preventScroll:true})}
 }
 async capture(){
  if(this.capturing)return;if(document.body.dataset.ready!=='true'){this.status.textContent='場景載入完成後即可拍攝。';return}this.capturing=true;this.captureButton.disabled=true;this.status.textContent='正在拍攝 3D 場景…';
  try{
   // The preserved WebGL drawing buffer contains no HTML menus, captions,
   // monitor or controls. Render the same camera without changing simulation.
   this.render();const blob=await new Promise(resolve=>this.canvas.toBlob(resolve,'image/png'));if(!blob)throw Error('無法建立圖片');
   const stamp=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Taipei',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).format(new Date()).replace(/[-:]/g,'').replace(' ','-'),filename='卡皮星-'+stamp+'.png',url=URL.createObjectURL(blob),link=document.createElement('a');
   link.href=url;link.download=filename;link.hidden=true;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);
   document.body.dataset.sceneSnapshot=JSON.stringify({filename,width:this.canvas.width,height:this.canvas.height,bytes:blob.size,sceneOnly:true});this.status.textContent='已下載 '+this.canvas.width+' × '+this.canvas.height+' PNG · 不含網頁介面';
  }catch(error){this.status.textContent='拍攝未完成：'+error.message;console.error(error)}
  finally{this.capturing=false;this.captureButton.disabled=false}
 }
}
