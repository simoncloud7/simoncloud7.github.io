// Artistic mountain weather on the scene's display clock; independent of the mass lab.
export const WEATHER_PERIOD=126;
const clamp=x=>Math.max(0,Math.min(1,x));
const smooth=x=>{x=clamp(x);return x*x*(3-2*x)};
export function mountainWeatherState(seconds){
 if(!Number.isFinite(seconds)||seconds<0)throw RangeError('Nonnegative weather time required');
 const phase=seconds%WEATHER_PERIOD;
 const snowfall=smooth((phase-18)/4)*(1-smooth((phase-44)/6));
 const accumulation=smooth((phase-18)/30)*(1-smooth((phase-72)/38));
 const stage=phase<18||phase>=110?'clear':phase<50?'snowing':phase<72?'settled':'melting';
 return {phase,stage,snowfall,accumulation,snowline:4.2-3.5*accumulation};
}
