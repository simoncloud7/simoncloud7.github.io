import {embeddingHeight} from './gravity.mjs?v=625f85475e99';
export function slicePoint(point,compactness,scale=18){const rho=Math.hypot(point.x,point.y);return [point.x*scale,-22+scale*embeddingHeight(compactness,Math.max(1,Math.min(3,rho)),3)+.12,point.y*scale]}
