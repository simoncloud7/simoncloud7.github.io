import {embeddingHeight} from './gravity.mjs?v=898c7c496a3a';
export function slicePoint(point,compactness,scale=18){const rho=Math.hypot(point.x,point.y);return [point.x*scale,-22+scale*embeddingHeight(compactness,Math.max(1,Math.min(3,rho)),3)+.12,point.y*scale]}
