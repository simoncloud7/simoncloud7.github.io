// A static, unit-lapse path comparison. Units: light-years / Julian years, c=1.
// The folded sheet is an isometric drawing of flat space, not a binary GR metric.
export const DEFAULT_JOURNEY={distance:40,access:2,throat:4,beta:.8,fold:210,yearsPerSecond:2,gateOpen:true};
export function validateJourney(c){
 for(const key of ['distance','access','throat','beta','fold','yearsPerSecond'])if(!Number.isFinite(c[key]))throw RangeError('Finite '+key+' required');
 if(c.distance<=0||c.access<0||c.throat<=0||c.beta<0||c.beta>=1||c.fold<0||c.fold>300||c.yearsPerSecond<=0||2*c.access>=c.distance)throw RangeError('Invalid journey configuration');
 return c;
}
export function journeyPlan(config){
 const c=validateJourney(config),factor=Math.sqrt(1-c.beta*c.beta),route=length=>({length,arrival:c.beta?length/c.beta:Infinity,proper:c.beta?length/c.beta*factor:Infinity});
 return {normal:route(c.distance),wormhole:route(2*c.access+c.throat),factor,gamma:1/factor};
}
function traveler(route,beta,factor,time,available=true){
 const distance=available?Math.min(route.length,beta*time):0,arrived=available&&beta>0&&time>=route.arrival,movingTime=available&&beta>0?Math.min(time,route.arrival):0;
 return {distance,progress:distance/route.length,arrived,arrival:available?route.arrival:Infinity,journeyProper:movingTime*factor,clock:movingTime*factor+(time-movingTime)};
}
export function journeyState(config,time){
 if(!Number.isFinite(time)||time<0)throw RangeError('Nonnegative finite time required');
 const plan=journeyPlan(config),normal=traveler(plan.normal,config.beta,plan.factor,time),wormhole=traveler(plan.wormhole,config.beta,plan.factor,time,config.gateOpen);
 const d=wormhole.distance;
 wormhole.stage=!config.gateOpen?'closed':wormhole.arrived?'arrived':d<config.access?'approach':d<config.access+config.throat?'throat':'exit';
 wormhole.tunnelProgress=Math.max(0,Math.min(1,(d-config.access)/config.throat));
 return {time,plan,normal,wormhole};
}
// |dE/ds|=1 and dE/ds dot dE/dw=0: folding changes no intrinsic lengths.
export function foldedPoint(s,width,distance,foldDegrees){
 const k=foldDegrees*Math.PI/180/distance;
 return Math.abs(k)<1e-10?[s,0,width]:[Math.sin(k*s)/k,(1-Math.cos(k*s))/k,width];
}
export function foldedTangent(s,distance,foldDegrees){const a=foldDegrees*Math.PI/180*s/distance;return [Math.cos(a),Math.sin(a),0]}
// Equatorial spatial embedding of an ultrastatic Ellis / Morris-Thorne type throat:
// ds²=-dt²+dl²+(b²+l²)dΩ². Along a radial path dτ=dt sqrt(1-β²).
export function throatPoint(l,b=1){if(!(b>0))throw RangeError('Positive throat radius required');return [b*Math.asinh(l/b),Math.hypot(b,l),0]}
