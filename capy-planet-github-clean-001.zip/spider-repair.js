import * as THREE from 'three';
import {SpiderRig,SpiderSilk} from './spider-rig.js?v=379aa11c64e4';
import {ExperimentStage} from './experiment-stage.js?v=379aa11c64e4';
import {visibleExperimentPoints} from './experiment-captions.js?v=379aa11c64e4';
import {SpiderGround,spiderFrame} from './spider-ground.js?v=379aa11c64e4';
import {SpiderCityLeap,SPIDER_LEAP_DURATION} from './spider-city-leap.js?v=379aa11c64e4';
const clamp=x=>THREE.MathUtils.clamp(x,0,1),ease=x=>{x=clamp(x);return x*x*(3-2*x)};
export const SPIDER_REPAIR_DURATION=36;
export function repairBeat(t){
 const climb=ease((t-6.5)/6.5)*(1-ease((t-22)/7));
 return {climb,web:ease((t-3.8)/2.7)*(1-ease((t-29)/3.5)),fixed:ease((t-14)/7),deploy:.72+.28*ease((t-2)/3),working:t>=6.5&&t<29,phase:t<1.8?'招牌鬆脫 · 八足工匠就位':t<3.2?'轉身面向招牌 · 腳尖待命':t<3.8?'轉身完成 · 站穩確認':t<6.5?'八隻腳尖噴絲 · 固定招牌':t<13?'沿蛛絲攀升 · 吊起工具箱':t<22?'鎖緊固定座 · 修復招牌':t<29?'收好工具 · 沿牆返回':t<33?'收回蛛絲 · 維修完成':'卡皮蜘豬 · 任務完成'};
}
export class SpiderRepair{
 constructor({globe,cloneAsset,assets,frameAt,stage,surfaces=[],anchorSites=[],onComplete=()=>{}}){
  Object.assign(this,{globe,onComplete});this.active=false;this.time=0;this.idleTime=0;this.auto=true;this.duration=SPIDER_REPAIR_DURATION;
  this.root=new THREE.Group();this.root.name='capy-spider-city-worksite';globe.add(this.root);const frame=frameAt(-13,2);this.root.quaternion.copy(frame.q);this.root.position.copy(frame.normal).multiplyScalar(18.24);this.root.translateZ(2.4);
  const make=key=>cloneAsset(assets[key].id,.85).root;this.actor=make('capy-spider');this.sign=make('spider-sign');this.case=make('spider-tool-case');this.root.add(this.actor,this.sign,this.case);this.rig=new SpiderRig(this.actor);this.silk=new SpiderSilk(this.root);
  this.ground=new SpiderGround({globe,surfaces,frameAt});this.root.updateWorldMatrix(true,true);const onGround=(x,z)=>this.ground.at(globe.worldToLocal(this.root.localToWorld(new THREE.Vector3(x,0,z))).normalize());this.home=onGround(.18,.35);this.caseGround=onGround(.18,-.12);this.front=new THREE.Vector3(0,0,1).applyQuaternion(this.root.quaternion);this.homeQ=spiderFrame(this.home.normal,this.front).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),.3));this.leap=new SpiderCityLeap({globe,actor:this.actor,rig:this.rig,silk:this.silk,ground:this.ground,frameAt,paths:stage.config.paths,home:this.home,homeQuaternion:this.homeQ,anchorSites});this.autoCount=0;
  const steel=new THREE.MeshStandardMaterial({color:0x405e66,roughness:.65,metalness:.3});for(const x of [-1.14,1.14]){const post=new THREE.Mesh(new THREE.CylinderGeometry(.055,.07,3.35,12),steel);post.position.set(x,1.63,-.85);post.castShadow=true;this.root.add(post)}const crossbar=new THREE.Mesh(new THREE.BoxGeometry(2.55,.1,.1),steel);crossbar.position.set(0,3.2,-.85);this.root.add(crossbar);
  this.audience=new ExperimentStage({...stage,reservedBounds:[-15,2,-10.5,5.1],clearPeople:true,dataKey:'spiderRepairStage'});this.pose(SPIDER_REPAIR_DURATION,false);
 }
 get performanceActive(){return this.active||this.audience.releasing}
 begin(manual=true,mode='repair'){if(this.active)this.stop(false);this.audience.finishRelease();this.audience.begin();this.active=true;this.manual=manual;this.mode=mode;this.duration=mode==='leap'?SPIDER_LEAP_DURATION:SPIDER_REPAIR_DURATION;this.time=0;this.idleTime=0;if(mode==='leap')this.leap.prepare();this.failureHandled=false;if(mode!=='leap')this.leap.failed=false;this.pose(0,true)}
 stop(notify=true){const was=this.active;this.active=false;this.leap.failed=false;this.audience.stop();this.silk.group.visible=false;this.pose(SPIDER_REPAIR_DURATION,false);if(was&&notify)this.onComplete()}
 seek(t){this.time=THREE.MathUtils.clamp(t,0,this.duration);this.pose(this.time,true)}
 pose(t,performing){
  if(performing&&this.mode==='leap'){this.beat=this.leap.pose(t);this.targets=this.leap.targets;this.facingWall=false;this.clearance=this.leap.clearance;return}
  const beat=repairBeat(t),a=this.actor;this.sign.position.set(0,3,-.68);this.sign.rotation.z=(1-beat.fixed)*(-.20+.035*Math.sin(t*3));
  const turn=performing?Math.PI*ease((t-1.8)/1.4)*(1-ease((t-32.5)/2)):.3;
  const body=a.getObjectByName('twin-body-pivot');body.position.y=.65;body.rotation.set(beat.working?-.10:0,0,0);
  for(const side of [-1,1]){const arm=a.getObjectByName('arm-'+side),leg=a.getObjectByName('leg-'+side);arm.rotation.set(beat.working?-.95+.23*Math.sin(t*7+side):t<3&&side===1?-1.8+.25*Math.sin(t*6):-.12,0,beat.working?side*.15:0);leg.rotation.x=beat.working?side*.22*Math.sin(t*5):0}
  const q=spiderFrame(this.home.normal,this.front).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),turn));this.clearance=this.ground.place(a,this.home,q,beat.climb*1.82);const caseQ=spiderFrame(this.caseGround.normal,this.front).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),.2));this.ground.place(this.case,this.caseGround,caseQ,beat.climb*1.7,false);
  this.root.updateWorldMatrix(true,true);const targets=[];
  for(let i=0;i<8;i++){const side=-this.rig.legs[i].side,row=i%4;const p=row===0?new THREE.Vector3(side*.92,3.25,-.52):row===1?new THREE.Vector3(side*1.14,2.65,-.85):row===2?new THREE.Vector3(this.case.position.x+side*.22,this.case.position.y+.35,-.12):new THREE.Vector3(side*1.14,.12,-.85);targets.push(this.root.localToWorld(p))}
  this.facingWall=Math.abs(turn-Math.PI)<.001;this.rig.pose(t,{working:beat.working,deploy:performing?beat.deploy:1,targets:performing&&this.facingWall?targets:[]});this.silk.group.visible=performing;this.silk.update(this.rig.emitters(),targets,performing&&this.facingWall?beat.web:0,t);this.beat=beat;this.targets=targets;
 }
 update(dt,camera,satellite,allowAuto=true){
  if(this.active){this.time=Math.min(this.duration,this.time+dt);this.pose(this.time,true);const subjects=this.mode==='leap'?[this.actor]:[this.actor,this.sign,this.case];this.audience.update(dt,{camera,satellite,subjects,targets:subjects.map(root=>root.getWorldPosition(new THREE.Vector3()))});if(this.mode==='leap'&&this.leap.failed&&!this.failureHandled){this.failureHandled=true;this.active=false;this.audience.stop();this.idleTime=-30;this.onComplete()}else if(this.time>=this.duration){this.stop();this.idleTime=-30}}
  else{this.audience.update(dt);this.idleTime+=dt;if(this.auto&&allowAuto&&this.idleTime>55)this.begin(false,'repair')}
  const state={active:this.active,mode:this.mode||'repair',manual:!!this.manual,time:this.mode==='leap'&&this.leap.beat?this.leap.beat.displayTime:this.time,totalTime:this.time,failed:!!this.leap.failed,lap:this.mode==='leap'?this.leap.beat?.lap:null,duration:this.duration,phase:this.beat.phase,facingWall:this.facingWall,footClearance:this.clearance,airborne:this.mode==='leap'&&this.active&&this.leap.height>.05,hop:this.mode==='leap'?this.leap.beat?.hop:null,anchor:this.mode==='leap'?this.leap.anchorName:null,legs:this.rig.legs.length,emitters:this.rig.emitters().map(p=>p.toArray()),targets:this.targets.map(p=>p.toArray()),strands:this.silk.strands.filter(s=>s.group.visible&&this.silk.group.visible).length};document.body.dataset.spiderRepair=JSON.stringify(state);const stop=document.querySelector('#spider-repair-stop');if(stop)stop.disabled=!this.active;
 }
 cameraPose(aspect=1.8){
  const target=this.root.localToWorld(new THREE.Vector3(0,2.1,-.05)),up=new THREE.Vector3(0,1,0).transformDirection(this.root.matrixWorld),direction=new THREE.Vector3(5.5,3,9).transformDirection(this.root.matrixWorld),distance=aspect<1?13:9;
  const homePose={target,position:target.clone().addScaledVector(direction,distance),up};return this.mode==='leap'&&(this.active||this.leap.failed)?this.leap.cameraPose(aspect,homePose):homePose;
 }
 broadcastPose(){if(!this.active)return null;this.root.updateWorldMatrix(true,true);if(this.mode==='leap'){const up=this.leap.surface.normal.clone().transformDirection(this.globe.matrixWorld),target=this.actor.getWorldPosition(new THREE.Vector3()).addScaledVector(up,.85),front=new THREE.Vector3(0,0,1).transformDirection(this.actor.matrixWorld);return {label:'卡皮蜘豬 · 城市蛛絲飛躍',group:this.actor,groups:[this.actor,this.silk.group],anchor:target.clone().addScaledVector(up,10).addScaledVector(front,8),target,up,bounds:visibleExperimentPoints(this.actor)}}const target=this.actor.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0,.8,0).transformDirection(this.root.matrixWorld));return {label:'卡皮蜘豬 · 城市高處維修',group:this.root,groups:[this.root],anchor:this.root.localToWorld(new THREE.Vector3(-5,5,6)),target,up:new THREE.Vector3(0,1,0).transformDirection(this.root.matrixWorld),bounds:[this.actor,this.sign,this.case].flatMap(root=>visibleExperimentPoints(root))}}
}
