const clamp=x=>Math.max(0,Math.min(1,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x)},mix=(a,b,t)=>a.map((v,i)=>v+(b[i]-v)*ease(t));
export const EVA_PERIOD=144;
export function spacewalkPose(time,index){
 const age=((time%EVA_PERIOD)+EVA_PERIOD)%EVA_PERIOD-(index?13:2),duration=index?57:68,hatch=[0,.15,.75],work=index?[2.6,1.3,.4]:[-1.1,.45,.05];
 if(age<0||age>duration)return {visible:false,stage:'艙內待命',age};
 let position,stage,clip;
 if(age<7){position=mix(hatch,work,age/7);stage='出艙';clip='eva-float'}
 else if(age<duration-14){const t=age-7;position=work.map((v,i)=>v+(index?[.45*Math.sin(t*.2),.22*Math.sin(t*.3),.45*Math.cos(t*.2)]:[.07*Math.sin(t*.6),.06*Math.sin(t*.8),0])[i]);stage=index?'繫繩漂浮巡查':'檢修船身';clip=index?'eva-wave':'eva-repair'}
 else{position=mix(work,hatch,(age-duration+14)/14);stage='返回艙內';clip='eva-float'}
 return {visible:true,stage,age,position,clip,phase:time%2};
}
export const VISIT_PERIOD=128,VISIT_DURATION=32;
export function visitFallNormal(level){const r=Math.hypot(18+level,2.9);return [0,(18+level)/r,2.9/r]}
export function visitPose(age,rescue,level,sea=0){
 const visible=age>=0&&age<29,normal=[0,0,1];let position=[0,level,.8],gateCenter=[0,level+.94,0],gateNormal=normal,open=0,stage='遠方旅行',clipping=false,yaw=0,fall=false;
 if(age<0||age>=VISIT_DURATION)return {visible:false,open:0,stage};
 if(age<5){position=[0,level,-1+2*ease(age/5)];open=ease(age/.8)*(1-ease((age-4)/1.3));stage='跨門現身';clipping=true}
 else if(age<21){const u=(age-5)/16;position=[.65*Math.sin(u*Math.PI*2),level+(rescue?.12*Math.sin(age*1.6):0),1+1.9*u];yaw=Math.atan2(.65*Math.PI*2*Math.cos(u*Math.PI*2),1.9);stage=rescue?'海上晃蕩': '附近散步'}
 else if(rescue){const p=[0,level,2.9],up=visitFallNormal(level),t=age-21;position=p.map((v,i)=>v-up[i]*.325*t*t);gateCenter=up.map((v,i)=>v*(18+sea+.18)-(i===1?18:0));gateNormal=up;open=ease((t-.6)/.7)*(1-ease((t-7.4)/2));stage=t<1.1?'失去平衡':t<7.4?'落水前開門脫身':'收起海上救援門';clipping=true;fall=true}
 else{position=[0,level,2.9+2.6*ease((age-21)/8)];gateCenter=[0,level+.94,4.2];gateNormal=[0,0,-1];open=ease((age-21)/1.1)*(1-ease((age-28)/3));stage='開門離開';clipping=true}
 return {visible,position,gateCenter,gateNormal,open,stage,clipping,yaw,fall};
}
