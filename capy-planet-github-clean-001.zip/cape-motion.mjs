const clamp=v=>Math.max(0,Math.min(1,v)),smooth=v=>{const t=clamp(v);return t*t*(3-2*t)},mix=(a,b,t)=>a.map((v,i)=>v+(b[i]-v)*t),curve=(a,b,c,t)=>a.map((v,i)=>(1-t)**2*v+2*(1-t)*t*b[i]+t*t*c[i]);
export function capeMotion(progress,rest=[0,.95,-.35]){
 const side=[1.14,rest[1],-.76],lowSide=[1.14,-.30,.04],lowFloor=[0,-.30,.04],floor=[0,-.04,.04],folded=[.52,1,1],flatFold=[.65,1.4,1],spread=[2.4,2.5,1],worn={stage:'披巾歸位',carpet:0,fold:0,hands:0,overhead:0,center:rest,rotation:0,twist:0,scale:[1,1,1]};
 if(progress<=.04||progress>=.97)return worn;
 // Keep the textile behind the back, outside the right shoulder, or below the
 // soles. It never takes the old diagonal shortcut through the chest/head.
 if(progress<.095){const t=smooth((progress-.04)/.055);return {...worn,stage:'披巾繞到身側',center:curve(rest,[.70,rest[1],-.90],side,t),scale:mix([1,1,1],folded,t),hands:t,fold:.35*t}}
 if(progress<.145){const t=smooth((progress-.095)/.05);return {...worn,stage:'身側降下展毯',center:mix(side,lowSide,t),rotation:Math.PI/2*t,scale:mix(folded,flatFold,t),hands:1,fold:.35*(1-t),carpet:t}}
 if(progress<.185){const t=smooth((progress-.145)/.04);return {...worn,stage:'展毯移到腳下',center:mix(lowSide,lowFloor,t),rotation:Math.PI/2,scale:mix(flatFold,spread,t),hands:1-t,carpet:1}}
 if(progress<.20){const t=smooth((progress-.185)/.015);return {...worn,stage:'魔毯托起巡航',center:mix(lowFloor,floor,t),rotation:Math.PI/2,scale:spread,carpet:1}}
 if(progress<=.78)return {...worn,stage:'柔軟魔毯巡航',carpet:1,center:floor,rotation:Math.PI/2,scale:spread};
 if(progress<.81){const t=smooth((progress-.78)/.03);return {...worn,stage:'魔毯降下收回',center:mix(floor,lowFloor,t),rotation:Math.PI/2,scale:spread,carpet:1,hands:t}}
 if(progress<.865){const t=smooth((progress-.81)/.055);return {...worn,stage:'魔毯移到身側',center:mix(lowFloor,lowSide,t),rotation:Math.PI/2,scale:mix(spread,flatFold,t),carpet:1,hands:1}}
 if(progress<.925){const t=smooth((progress-.865)/.06);return {...worn,stage:'身側提起披巾',center:mix(lowSide,side,t),rotation:Math.PI/2*(1-t),scale:mix(flatFold,folded,t),carpet:1-t,hands:1,fold:.35*t}}
 const t=smooth((progress-.925)/.045);
 return {...worn,stage:'繞到肩後披回',center:curve(side,[.70,rest[1],-.90],rest,t),scale:mix(folded,[1,1,1],t),hands:1-t,fold:.35*(1-t)};
}
export const capeFlight=progress=>capeMotion(progress).carpet;
export function weaverHands(motion,step=0,time=0){
 const blend=(a,b,t)=>a.map((v,i)=>v+(b[i]-v)*t),control=motion.carpet,side=clamp((motion.center?.[0]||0)/1.14),lowered=clamp((.95-(motion.center?.[1]??.95))/1.25),depth=clamp(((motion.center?.[2]??-.35)+.76)/.80),sway=.055*Math.sin(time*1.6);
 // Gate effects do not interrupt contralateral walking. Cruise uses relaxed
 // open paws with a small balancing sway, rather than holding imaginary reins.
 const left=blend([step*.38,0,-.06],[-.32+sway,0,-.22],control),right=blend([-step*.38,0,.06],[-.32-sway,0,.22],control);
 return {left,right,follow:motion.hands,targets:{left:[-.32+.10*side,1.10-.30*lowered,.34+.04*depth],right:[.45+.32*side,1.18-.50*lowered,-.10+.42*depth]}};
}
export function clothRipple(u,v,time,carpet,fold=0){
 const edge=clamp(Math.max(Math.abs(u)*.85,Math.abs(v))),support=Math.exp(-(Math.abs(u/.42)**6+Math.abs(v/.22)**6)),free=(1-support)*(.25+.75*edge);
 const height=carpet*free*(.19*Math.sin(time*3.1-v*4.4)+.085*Math.sin(time*5.4-v*8.2+u*2)+.05*u*u*Math.cos(time*2.2+v*3));
 return {x:carpet*.025*edge*u*Math.sin(time*4.2+v*5),y:carpet*.025*edge*Math.sin(time*3.9+u*4),z:-height+fold*.28*Math.sin(u*Math.PI/2)**2,height};
}

// The shoulder hem stays sewn in place. Only the free end curls up behind
// the head; the curve leaves the back before rising, rather than crossing it.
export function suspendedCapePoint(x,y,z,lift,time){
 const t=clamp((1.42-y)/.98),a=100*Math.PI/180,b=Math.PI/2,length=1.078,free=t*t,cy=1.42-length/b*(Math.sin(a+b*t)-Math.sin(a)),cz=-.235+length/b*(Math.cos(a+b*t)-Math.cos(a)),wave=.035*free*Math.sin(time*3.2-t*5+x*2);
 return [x+lift*free*(.58+.045*Math.sin(time*2.4-t*4)),y+lift*(cy-y+wave),z+lift*(cz-(-.235-.22*t)+.04*free*Math.sin(time*3.7-t*4+x*3))];
}
export function weaverLift(time,duration=16){
 const t=Math.max(0,Math.min(duration,time)),tail=smooth(t/2)*(1-smooth((t-duration+3)/3)),body=smooth((t-1.1)/1.8)*(1-smooth((t-duration+5)/2));
 return {tail,body,height:body*(.55+.025*Math.sin(t*2)),pitch:.025*body,roll:.022*body*Math.sin(t*1.6),stage:t<1.1?'披風尾端先揚起':t<2.9?'披風提起身體':t<duration-5?'披風吊掛懸飛':t<duration-3?'雙腳自然落地':'披風尾端垂落'};
}
