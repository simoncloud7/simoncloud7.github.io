import * as THREE from 'three';
import {mountainWeatherState,WEATHER_PERIOD} from './mountain-weather.mjs?v=625f85475e99';
const $=s=>document.querySelector(s),BASE=18.205,SCALE=.95;
export class MountainWeatherSystem{
 constructor({globe,mountain,onObserve}){
  this.time=0;this.lastAccumulation=-1;this.surfaces=[];this.heightGrid=new Map();this.meshVertices=0;
  mountain.traverse(mesh=>{
   if(!mesh.isMesh)return;
   const g=mesh.geometry,p=g.attributes.position,old=g.attributes.color;
   const base=new Float32Array(p.count*3),colors=new Float32Array(p.count*3),heights=new Float32Array(p.count),noise=new Float32Array(p.count);
   for(let i=0;i<p.count;i++){
    const x=p.getX(i),y=p.getY(i),z=p.getZ(i),r=Math.hypot(x,y,z),mx=Math.atan2(x,y)*18,mz=Math.asin(z/r)*18,h=(r-BASE)/SCALE;
    heights[i]=h;noise[i]=.10*Math.sin(mx*3.1+mz*.6)+.06*Math.sin(mz*4.3-mx*.7);
    for(let c=0;c<3;c++)base[i*3+c]=old?(c===0?old.getX(i):c===1?old.getY(i):old.getZ(i)):.3;
    const key=Math.round(mx/.3)+':'+Math.round(mz/.3);this.heightGrid.set(key,Math.max(this.heightGrid.get(key)||0,r-BASE));
   }
   colors.set(base);g.setAttribute('color',new THREE.BufferAttribute(colors,3));mesh.material=mesh.material.clone();mesh.material.vertexColors=true;
   this.surfaces.push({g,base,heights,noise});this.meshVertices+=p.count;
  });
  this.group=new THREE.Group();this.group.quaternion.copy(mountain.quaternion);globe.add(this.group);
  let seed=265827;const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296};
  this.count=1600;this.flakes=[];const positions=new Float32Array(this.count*3),sizes=new Float32Array(this.count);
  for(let i=0;i<this.count;i++){
   const a=random()*Math.PI*2,r=Math.sqrt(random())*7.2,x=Math.cos(a)*r,z=Math.sin(a)*r,lon=x/18,lat=z/18;
   let ground=0;for(let dx=-1;dx<=1;dx++)for(let dz=-1;dz<=1;dz++)ground=Math.max(ground,this.heightGrid.get((Math.round(x/.3)+dx)+':'+(Math.round(z/.3)+dz))||0);
   this.flakes.push({normal:[Math.sin(lon)*Math.cos(lat),Math.cos(lon)*Math.cos(lat),Math.sin(lat)],east:[Math.cos(lon),-Math.sin(lon),0],ground:ground+.10,top:8.8+random()*1.4,speed:1.3+random()*.9,phase:random()});sizes[i]=.11+random()*.10;
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));geometry.setAttribute('flakeSize',new THREE.BufferAttribute(sizes,1));
  const material=new THREE.ShaderMaterial({transparent:true,depthWrite:false,toneMapped:false,uniforms:{opacity:{value:0}},vertexShader:'attribute float flakeSize;void main(){vec4 p=modelViewMatrix*vec4(position,1.0);gl_PointSize=clamp(flakeSize*260.0/max(1.0,-p.z),1.2,6.0);gl_Position=projectionMatrix*p;}',fragmentShader:'uniform float opacity;void main(){float r=length(gl_PointCoord-vec2(.5));if(r>.5)discard;float a=(1.0-smoothstep(.18,.5,r))*opacity;gl_FragColor=vec4(.91,.96,1.0,a);#include <colorspace_fragment>\n}'.replace(';#include',';\n#include')});
  this.points=new THREE.Points(geometry,material);this.points.frustumCulled=false;this.group.add(this.points);
  $('#mountain-snow-start').onclick=()=>{this.time=18;this.previewEnd=110;this.apply();onObserve()};
  $('#mountain-snow-settled').onclick=()=>{this.time=52;this.previewEnd=110;this.apply();onObserve()};
  $('#mountain-weather-time').max=String(WEATHER_PERIOD-.1);
  $('#mountain-weather-time').oninput=e=>{this.time=Number(e.target.value);this.apply()};
  this.apply();
 }
 setFocus(kind){$('#mountain-weather').hidden=kind!=='mountain'}
 get performanceActive(){return this.previewEnd!==undefined&&this.time<this.previewEnd}
 update(dt){this.time+=dt;this.apply()}
 apply(){
  const state=mountainWeatherState(this.time);
  if(Math.abs(state.accumulation-this.lastAccumulation)>.001||state.accumulation===0&&this.lastAccumulation!==0){
   for(const {g,base,heights,noise} of this.surfaces){const c=g.attributes.color;for(let i=0;i<heights.length;i++){
    let w=Math.max(0,Math.min(1,(heights[i]-state.snowline-noise[i])/.32));w=w*w*(3-2*w)*Math.min(1,state.accumulation*5);
    c.setXYZ(i,base[i*3]*(1-w)+.86*w,base[i*3+1]*(1-w)+.914*w,base[i*3+2]*(1-w)+.93*w);
   }c.needsUpdate=true}this.lastAccumulation=state.accumulation;
  }
  const active=Math.floor(this.count*state.snowfall);this.points.visible=active>0;this.points.geometry.setDrawRange(0,active);this.points.material.uniforms.opacity.value=.80*Math.min(1,state.snowfall*3);
  if(active){const p=this.points.geometry.attributes.position;for(let i=0;i<active;i++){
   const f=this.flakes[i],fall=(f.phase+this.time*f.speed/(f.top-f.ground))%1,h=f.top-(f.top-f.ground)*fall,radial=BASE+h,wind=.15*Math.sin(this.time*.8+f.phase*12),n=f.normal,e=f.east;
   p.setXYZ(i,n[0]*radial+e[0]*wind,n[1]*radial+e[1]*wind,n[2]*radial);
  }p.needsUpdate=true}
  const labels={clear:'晴空 · 等待下一場雪',snowing:'飄雪中 · 雪線逐漸下降',settled:'雪停了 · 山上留下白雪',melting:'陽光回來 · 積雪慢慢融化'};
  $('#mountain-weather-state').textContent=labels[state.stage];$('#mountain-snow-progress').textContent=Math.round(state.accumulation*100)+'%';
  if(document.activeElement!==$('#mountain-weather-time'))$('#mountain-weather-time').value=String(state.phase);
  document.body.dataset.mountainWeather=JSON.stringify({...state,time:this.time,activeFlakes:active,meshVertices:this.meshVertices,model:'artistic scene weather',fallDirection:'local radial inward',clock:'display seconds'});
 }
}
