import * as THREE from 'three';
import {FrameOrbitControls as OrbitControls} from './frame-orbit-controls.js?v=ff2ded0ce791';
import {DEFAULT_JOURNEY,journeyPlan,journeyState,foldedPoint,foldedTangent} from './interstellar.mjs?v=ff2ded0ce791';
import {portalLayout,throatSection} from './portal-transit.mjs?v=ff2ded0ce791';
import {PortalMage} from './portal-mage.js?v=ff2ded0ce791';
import {HeroRingLanding,standingFrame,soleReport,footDrop,ringIntersections,gridEdgeReport} from './hero-ring-landing.js?v=ff2ded0ce791';
import {loadUniverseAssets,buildHomePlanet,makeLabel} from './universe-assets.js?v=ff2ded0ce791';
import {isHeroCloth} from './hero-style.js?v=ff2ded0ce791';
import {attachBrowserViewport,watchDeviceViewport} from './device-viewport.mjs?v=ff2ded0ce791';
import {installViewportReport} from './viewport-report.js?v=ff2ded0ce791';
import {SceneRenderLoop,renderPixelRatio} from './render-performance.mjs?v=ff2ded0ce791';
let renderLoop,lastUiRender=-Infinity;
const $=s=>document.querySelector(s),S=1.7,LANE=1.1,config={...DEFAULT_JOURNEY},scene=new THREE.Scene(),host=$('#universe');
const browserFrame=attachBrowserViewport({root:document.documentElement,onSettled:()=>{resize();renderFrame()}});let viewportSize='',throatSize='',nextViewportCheck=0;
const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;renderer.localClippingEnabled=true;host.append(renderer.domElement);
const camera=new THREE.PerspectiveCamera(43,1,.1,1200),controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.minDistance=5;controls.maxDistance=320;camera.position.set(66,48,106);controls.target.set(0,12,0);
scene.add(new THREE.HemisphereLight(0xe4f0f4,0x434265,2));const sun=new THREE.DirectionalLight(0xffe4bd,3.7);sun.position.set(-35,55,45);scene.add(sun);const fill=new THREE.DirectionalLight(0x8daceb,.65);fill.position.set(35,0,-35);scene.add(fill);
const world=new THREE.Group(),grid=new THREE.Group(),routes=new THREE.Group(),wormholeRoutes=new THREE.Group();scene.add(world,grid,routes,wormholeRoutes);
let previewUntil=null,previewLabel='';
let ready=false,running=false,time=0,wallTime=0,cameraMode='overview',lastPreview=-10,lastReport=-10,gateAmount=1;
let portalMage,portalPlacement;
let superLanding,mageDrop=1.55,throatLength=null,layoutPending=false,landedSince=null;
let assets,homeMount,home,auroraMount,aurora,auroraSurface,superCarrier,mageCarrier,superModel,mageModel,f8,planetLabels=[],stationLabels=[],gates=[],state=journeyState(config,0),tunnelMage;
const throatScene=new THREE.Scene();throatScene.background=new THREE.Color(0x0a1220);throatScene.add(new THREE.HemisphereLight(0xe3f2f2,0x38335d,2.8));const throatLight=new THREE.DirectionalLight(0xffd99b,3);throatLight.position.set(2,7,10);throatScene.add(throatLight);
const throatHost=$('#throat-view'),throatRenderer=new THREE.WebGLRenderer({antialias:true});throatRenderer.setPixelRatio(Math.min(devicePixelRatio,1.3));throatRenderer.localClippingEnabled=true;throatRenderer.outputColorSpace=THREE.SRGBColorSpace;throatRenderer.toneMapping=THREE.ACESFilmicToneMapping;throatHost.append(throatRenderer.domElement);const throatCamera=new THREE.PerspectiveCamera(42,1,.05,300),insideCamera=new THREE.PerspectiveCamera(43,1,.05,300),throatGeometry=new THREE.Group();throatScene.add(throatGeometry);let throatVisible=false;
new IntersectionObserver(entries=>{throatVisible=entries[0].isIntersecting}).observe(throatHost);
function resize(){browserFrame.refresh();if(browserFrame.settling)return;const r=host.getBoundingClientRect();if(r.width<1||r.height<1)return;const key=r.width+'x'+r.height,changed=key!==viewportSize;if(changed){viewportSize=key;renderer.setSize(r.width,r.height,false);camera.aspect=r.width/r.height;camera.updateProjectionMatrix();insideCamera.aspect=camera.aspect;insideCamera.updateProjectionMatrix()}const t=throatHost.getBoundingClientRect(),throatKey=t.width+'x'+t.height;if(t.width>0&&t.height>0&&throatKey!==throatSize){throatSize=throatKey;throatRenderer.setSize(t.width,t.height,false);throatCamera.aspect=t.width/t.height;throatCamera.updateProjectionMatrix()}if(changed&&renderLoop)applyUniverseQuality(renderLoop.profile);if(changed&&ready&&cameraMode==='overview')setCamera('overview')}
new ResizeObserver(resize).observe(host);new ResizeObserver(resize).observe(throatHost);watchDeviceViewport(resize);resize();
function cosmicBackground(){
 const canvas=document.createElement('canvas');canvas.width=2048;canvas.height=1024;const ctx=canvas.getContext('2d');ctx.fillStyle='#070e1a';ctx.fillRect(0,0,2048,1024);
 for(const [x,y,r,c] of [[450,500,680,'rgba(53,52,107,.6)'],[1250,580,620,'rgba(26,79,101,.5)'],[1900,400,450,'rgba(95,47,76,.35)']]){const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,c);g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.fillRect(0,0,2048,1024)}
 const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;scene.add(new THREE.Mesh(new THREE.SphereGeometry(500,32,24),new THREE.MeshBasicMaterial({map:tex,side:THREE.BackSide,depthWrite:false,toneMapped:false})));
 let seed=4903;const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296},v=[],colors=[];
 for(let i=0;i<6500;i++){const a=random()*Math.PI*2,u=random()*2-1,r=200+random()*190,k=Math.sqrt(1-u*u);v.push(r*k*Math.cos(a),r*u,r*k*Math.sin(a));const c=new THREE.Color().setHSL(.52+random()*.18,.2+random()*.3,.55+random()*.4);colors.push(c.r,c.g,c.b)}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(v,3));g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));scene.add(new THREE.Points(g,new THREE.PointsMaterial({size:.18,vertexColors:true,transparent:true,opacity:.85,depthWrite:false})));
}
cosmicBackground();
const position=(s,w=0)=>new THREE.Vector3(...foldedPoint(s,w,config.distance,config.fold)).multiplyScalar(S),tangent=s=>new THREE.Vector3(...foldedTangent(s,config.distance,config.fold)),normal=s=>{const t=tangent(s);return new THREE.Vector3(-t.y,t.x,0)};
function line(points,color,opacity=1,width=1){return new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),new THREE.LineBasicMaterial({color,transparent:true,opacity,linewidth:width}))}
function aperturePoint(a,rx=1.35,ry=1.66){const c=Math.cos(a),s=Math.sin(a);return new THREE.Vector3(rx*Math.sign(c)*Math.abs(c)**.72,ry*Math.sign(s)*Math.abs(s)**.72,0)}
function clearGeometry(group){for(const n of [...group.children]){n.traverse(o=>{o.geometry?.dispose();if(o.material){for(const m of Array.isArray(o.material)?o.material:[o.material])m.dispose()}});group.remove(n)}}
function atmosphere(parent,radius,color){
 parent.add(new THREE.Mesh(new THREE.SphereGeometry(radius,64,40),new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.BackSide,blending:THREE.AdditiveBlending,uniforms:{tint:{value:new THREE.Color(color)}},vertexShader:'varying vec3 n;varying vec3 v;void main(){vec4 p=modelViewMatrix*vec4(position,1.);n=normalize(normalMatrix*normal);v=normalize(-p.xyz);gl_Position=projectionMatrix*p;}',fragmentShader:'uniform vec3 tint;varying vec3 n;varying vec3 v;void main(){float f=pow(1.-abs(dot(normalize(n),normalize(v))),2.7);gl_FragColor=vec4(tint,f*.65);}'})));
}
function setupGate(peer){
 const group=new THREE.Group(),frame=assets.clone(assets.kit.assets['wormhole-gate'].id).root;frame.position.y=-1.85;group.add(frame);
 frame.traverse(n=>{if(n.isMesh){n.material=n.material.clone();n.material.emissive=new THREE.Color(0x539888);n.material.emissiveIntensity=.28}});
 const target=new THREE.WebGLRenderTarget(384,384);target.texture.colorSpace=THREE.SRGBColorSpace;const outline=Array.from({length:128},(_,i)=>aperturePoint(i/128*Math.PI*2,1.30,1.61)),shape=new THREE.Shape(outline.map(p=>new THREE.Vector2(p.x,p.y)));shape.closePath();const windowGeometry=new THREE.ShapeGeometry(shape),uv=windowGeometry.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,(uv.getX(i)+1.30)/2.60,(uv.getY(i)+1.61)/3.22);const windowMesh=new THREE.Mesh(windowGeometry,new THREE.MeshBasicMaterial({map:target.texture,side:THREE.DoubleSide,toneMapped:false}));group.add(windowMesh);
 const halo=new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(Array.from({length:128},(_,i)=>aperturePoint(i/128*Math.PI*2,1.40,1.71))),new THREE.LineBasicMaterial({color:0xc7c2f2,transparent:true,opacity:.75,toneMapped:false}));group.add(halo);
 const glow=new THREE.Mesh(new THREE.PlaneGeometry(3.5,4.2),new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,blending:THREE.AdditiveBlending,toneMapped:false,uniforms:{time:{value:0}},vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec2 vUv;uniform float time;void main(){vec2 q=abs((vUv-.5)*vec2(3.5/1.40,4.2/1.71));float r=pow(pow(q.x,2.778)+pow(q.y,2.778),1./2.778);float edge=exp(-pow((r-1.)*30.,2.));gl_FragColor=vec4(.53,.86,.77,edge*(.23+.05*sin(time*2.)));}'}));group.add(glow);
 const sparkPositions=new Float32Array(64*3),sparks=new THREE.Points(new THREE.BufferGeometry(),new THREE.PointsMaterial({color:0xc7c2f2,toneMapped:false,size:.045,transparent:true,opacity:.65,depthWrite:false}));sparks.geometry.setAttribute('position',new THREE.BufferAttribute(sparkPositions,3));group.add(sparks);world.add(group);
 return {group,frame,halo,glow,sparks,target,peer,previewCamera:new THREE.PerspectiveCamera(50,1,.1,1000)};
}
function carrier(id,scale){const group=new THREE.Group(),model=assets.clone(id,scale).root;model.position.y=-1.1*scale;group.add(model);world.add(group);return {group,model}}
function rebuildLayout(){
 if(!ready)return;clearGeometry(grid);clearGeometry(routes);clearGeometry(wormholeRoutes);const d=config.distance;
 for(let i=0;i<=12;i++){const w=-8+i*16/12;grid.add(line(Array.from({length:129},(_,j)=>position(-d/2+d*j/128,w).add(new THREE.Vector3(0,-.65,0))),0x66849e,.16))}
 for(let i=0;i<=36;i++){const s=-d/2+d*i/36;grid.add(line([position(s,-8).add(new THREE.Vector3(0,-.65,0)),position(s,8).add(new THREE.Vector3(0,-.65,0))],0x66849e,.16))}
 const mainPoints=Array.from({length:257},(_,j)=>position(-d/2+d*j/256,LANE));routes.add(line(mainPoints,0x94d8ed,.9));
 superLanding.apply(config,state.normal.distance,{idle:time===0,idleForward:portalPlacement?.forward});const landing=superLanding.layout;
 portalPlacement=portalLayout(config,S,-LANE,landing.mageContact.clone().addScaledVector(landing.up,mageDrop).toArray());wormholeRoutes.add(line([portalPlacement.source,portalPlacement.entry].map(p=>new THREE.Vector3(...p)),0xffc879,1),line([portalPlacement.exit,portalPlacement.destination].map(p=>new THREE.Vector3(...p)),0xffc879,1));
 homeMount.position.copy(position(-d/2)).addScaledVector(normal(-d/2),-10).add(new THREE.Vector3(0,0,2));homeMount.rotation.z=-.12;auroraMount.rotation.z=0;
 auroraMount.position.copy(landing.center);
 for(const [i,mount] of [homeMount,auroraMount].entries()){planetLabels[i].position.copy(mount.position).add(new THREE.Vector3(0,9,0))}
 stationLabels[0].position.copy(position(-d/2)).add(new THREE.Vector3(0,3.2,0));stationLabels[1].position.copy(position(d/2)).add(new THREE.Vector3(0,3.2,0));
 gates.forEach((gate,i)=>{const up=new THREE.Vector3(0,1,0),front=new THREE.Vector3(...portalPlacement[i?'exitFacing':'entryFacing']),right=new THREE.Vector3().crossVectors(up,front);gate.group.position.fromArray(portalPlacement[i?'exit':'entry']);gate.group.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(right,up,front))});
 const bridgeA=[homeMount.position.clone().add(new THREE.Vector3(0,0,-6)),position(-d/2)];routes.add(line(bridgeA,0x6e9caa,.35));
 if(throatLength!==config.throat){rebuildThroat();throatLength=config.throat}
}
function rebuildThroat(){
 clearGeometry(throatGeometry);const v=[],indices=[],rings=72,sectors=64,L=config.throat;
 for(let j=0;j<=rings;j++){const l=-L/2+L*j/rings,p=throatSection(l);for(let i=0;i<=sectors;i++){const a=i/sectors*Math.PI*2;v.push(p.center[0]*2.4,p.radius*Math.cos(a)*2.4,p.radius*Math.sin(a)*2.4);if(j<rings&&i<sectors){const k=j*(sectors+1)+i;indices.push(k,k+1,k+sectors+1,k+1,k+sectors+2,k+sectors+1)}}}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(v,3));g.setIndex(indices);g.computeVertexNormals();throatGeometry.add(new THREE.Mesh(g,new THREE.MeshBasicMaterial({color:0x7a97ae,transparent:true,opacity:.08,side:THREE.DoubleSide,depthWrite:false})));
 for(let j=0;j<=16;j++){const l=-L/2+L*j/16,p=throatSection(l);throatGeometry.add(line(Array.from({length:97},(_,i)=>new THREE.Vector3(p.center[0]*2.4,p.radius*Math.cos(i/96*Math.PI*2)*2.4,p.radius*Math.sin(i/96*Math.PI*2)*2.4)),j===8?0xffd291:0x608ca1,j===8?.8:.3))}
 for(let i=0;i<12;i++){const a=i/12*Math.PI*2;throatGeometry.add(line(Array.from({length:97},(_,j)=>{const p=throatSection(-L/2+L*j/96);return new THREE.Vector3(p.center[0]*2.4,p.radius*Math.cos(a)*2.4,p.radius*Math.sin(a)*2.4)}),0x83bed0,.25))}
 throatGeometry.add(line([new THREE.Vector3(-L/2*2.4,0,0),new THREE.Vector3(L/2*2.4,0,0)],0xffd18a,.45));
 const extent=Math.max(7,Math.hypot(1,L/2)*2.4);throatCamera.position.set(L*1.1,extent*.65,extent*2.7);throatCamera.lookAt(0,0,0);insideCamera.position.copy(throatCamera.position);insideCamera.lookAt(0,0,0);
}
function renderPortalPreviews(){
 const oldTarget=renderer.getRenderTarget();gates.forEach(g=>g.group.visible=false);
 try{for(const gate of gates){const peer=gate.peer==='aurora'?auroraMount:homeMount;gate.previewCamera.position.copy(peer.position).add(new THREE.Vector3(11,8,17));gate.previewCamera.lookAt(peer.position);renderer.setRenderTarget(gate.target);renderer.render(scene,gate.previewCamera)}}finally{renderer.setRenderTarget(oldTarget);gates.forEach(g=>g.group.visible=gateAmount>.01)}
}
function animateCapes(root,t){root.traverse(n=>{if(isHeroCloth(n.name))n.rotation.x=.035*Math.sin(t*3)})}
function settleOnRing(){if(state.wormhole.arrived){const r=portalMage.roles.exit,l=superLanding.layout;r.carrier.quaternion.copy(standingFrame(l.up,l.forward));r.carrier.position.copy(l.mageContact).addScaledVector(l.up,mageDrop);const report=soleReport(r.model,l);r.carrier.position.addScaledVector(l.up,-Math.min(...report.map(f=>f.height)))}}
function landingReport(){const l=superLanding.layout;return {...superLanding.telemetry,gridError:superCarrier.position.distanceTo(position(-config.distance/2+state.normal.distance,LANE)),intersections:time>0?ringIntersections(superModel,l):0,feet:state.normal.arrived?soleReport(superModel,l):null,mageFeet:state.wormhole.arrived?soleReport(portalMage.roles.exit.model,l):null,contact:l.contact.toArray(),ringCenter:auroraMount.position.toArray(),ringNormal:l.up.toArray(),ringQuaternion:auroraMount.quaternion.toArray(),homePosition:homeMount.position.toArray(),ringRadius:l.radius,gridEdge:gridEdgeReport(config,l),hasDeck:false}}
function updateActors(){
 wormholeRoutes.visible=config.gateOpen;throatGeometry.visible=config.gateOpen;
 if(!ready)return;if(state.normal.arrived){landedSince??=wallTime}else landedSince=null;
 const settleProgress=state.normal.arrived?THREE.MathUtils.clamp((wallTime-landedSince-.25)/.55,0,1):0;
 animateCapes(superModel,wallTime);superLanding.apply(config,state.normal.distance,{idle:time===0,idleForward:portalPlacement.forward,settleProgress});
 portalMage.update({config,state,layout:portalPlacement,gates,wallTime});mageCarrier=portalMage.active.carrier;mageModel=portalMage.active.model;settleOnRing();
 document.body.dataset.landingAudit=JSON.stringify({...superLanding.telemetry,fold:config.fold,progress:state.normal.progress,gridError:superCarrier.position.distanceTo(position(-config.distance/2+state.normal.distance,LANE)),ringQuaternion:auroraMount.quaternion.toArray(),homePosition:homeMount.position.toArray()});
 gates.forEach((g,i)=>{g.group.visible=gateAmount>.01;g.group.scale.setScalar(1.35*gateAmount);g.glow.material.uniforms.time.value=wallTime;g.halo.material.opacity=.65+.15*Math.sin(wallTime*2+i);const p=g.sparks.geometry.attributes.position;for(let j=0;j<p.count;j++){const a=j/p.count*Math.PI*2+wallTime*.12,v=aperturePoint(a,1.44,1.75);p.setXYZ(j,v.x,v.y,.04+.06*Math.sin(wallTime*2+j))}p.needsUpdate=true});
 f8.position.set(Math.cos(wallTime*.2)*9,Math.sin(wallTime*.2)*5,3);f8.lookAt(0,0,0);
}
function setCamera(kind){
 controls.clearMotion();
 if(!ready)return;if(!['mage','gate','landing'].includes(kind))camera.up.set(0,1,0);cameraMode=kind;document.querySelectorAll('[data-camera]').forEach(b=>b.classList.toggle('active',b.dataset.camera===kind));
 if(kind==='overview'){
  const h=position(-config.distance/2).y*.5+6;controls.target.set(0,h,0);const offset=new THREE.Vector3(config.distance*.35,config.distance*.55+12,config.distance*1.25+8).sub(controls.target),points=[];
  for(let j=0;j<=64;j++)for(const w of [-8,8])points.push(position(-config.distance/2+config.distance*j/64,w).add(new THREE.Vector3(0,-.65,0)));
   for(const mount of [homeMount,auroraMount])for(const x of [-12,12])for(const y of [-11,11])for(const z of [-12,12])points.push(mount.position.clone().add(new THREE.Vector3(x,y,z)));
  for(let pass=0;pass<5;pass++){camera.position.copy(controls.target).add(offset);camera.lookAt(controls.target);camera.updateMatrixWorld();const fit=Math.max(...points.map(p=>{const v=p.clone().project(camera);return Math.max(Math.abs(v.x),Math.abs(v.y))}))/.91;if(fit<=1)break;offset.multiplyScalar(Math.max(1.01,fit))}
 }
 if(['mage','gate','landing'].includes(kind))updateCamera();else controls.update();
}
document.querySelectorAll('[data-camera]').forEach(b=>b.onclick=()=>setCamera(b.dataset.camera));const releaseCamera=()=>{cameraMode='free';controls.enabled=true;controls.clearMotion();document.querySelectorAll('[data-camera]').forEach(b=>b.classList.remove('active'))};renderer.domElement.addEventListener('pointerdown',releaseCamera,{capture:true});renderer.domElement.addEventListener('wheel',releaseCamera,{capture:true,passive:true});
function updateCamera(){
 if(!ready)return;if(!['mage','gate','landing','free'].includes(cameraMode))camera.up.set(0,1,0);for(const label of [...planetLabels,...stationLabels])label.visible=!['super','mage','gate','landing'].includes(cameraMode);controls.enabled=!['mage','gate','landing'].includes(cameraMode);let p,target;
 if(cameraMode==='mage'&&state.wormhole.stage==='throat'){const target=tunnelMage.position.clone().add(new THREE.Vector3(0,.1,0));const f=portalMage.cameraFrame;insideCamera.up.copy(f.up);insideCamera.position.copy(target).addScaledVector(f.up,1.2).addScaledVector(f.right,2.2).addScaledVector(f.forward,3.9);insideCamera.lookAt(target)}
 if(cameraMode==='home'||cameraMode==='aurora'){const mount=cameraMode==='home'?homeMount:auroraMount;target=mount.position;p=target.clone().add(cameraMode==='aurora'?new THREE.Vector3(-12,22,19):new THREE.Vector3(13,9,19))}
 else if(cameraMode==='super'){target=superCarrier.position;p=target.clone().add(new THREE.Vector3(5,4,8))}
 else if(cameraMode==='mage'){const f=portalMage.cameraFrame,side=portalMage.body.exitOffset>=0?1:-1;target=f.position.clone().addScaledVector(f.up,.25);camera.up.copy(f.up);p=target.clone().addScaledVector(f.up,2.2).addScaledVector(f.right,4).addScaledVector(f.forward,side*7)}
 else if(cameraMode==='gate'){const useExit=state.wormhole.tunnelProgress>.5,gate=gates[useExit?1:0],q=gate.group.quaternion,up=new THREE.Vector3(0,1,0).applyQuaternion(q),right=new THREE.Vector3(1,0,0).applyQuaternion(q),forward=new THREE.Vector3(0,0,1).applyQuaternion(q);target=gate.group.position;camera.up.copy(up);p=target.clone().addScaledVector(up,2).addScaledVector(right,5).addScaledVector(forward,-8)}
 else if(cameraMode==='landing'){const l=superLanding.layout,side=new THREE.Vector3().crossVectors(l.up,l.radial);target=superCarrier.position;p=target.clone().addScaledVector(l.up,4).addScaledVector(l.radial,7).addScaledVector(side,7);camera.up.copy(l.up)}
 if(p&&['mage','gate','landing'].includes(cameraMode)){camera.position.copy(p);controls.target.copy(target);camera.lookAt(target)}else{if(p){camera.position.lerp(p,.12);controls.target.lerp(target,.12)}controls.update()}document.body.dataset.journeyCamera=JSON.stringify({mode:cameraMode,position:camera.position.toArray(),up:camera.up.toArray(),target:controls.target.toArray(),gateIndex:state.wormhole.tunnelProgress>.5?1:0});
}
const format=(v,d=2)=>Number.isFinite(v)?v.toFixed(d):'—',years=v=>format(v)+' <em>年</em>';
function renderUI(){
 const p=state.plan;$('#coordinate-time').innerHTML=years(time);$('#gamma-label').textContent='γ '+p.gamma.toFixed(3);$('#normal-arrival').innerHTML=years(p.normal.arrival);$('#normal-proper').innerHTML=years(p.normal.proper);$('#wormhole-arrival').innerHTML=config.gateOpen?years(p.wormhole.arrival):'—';$('#wormhole-proper').innerHTML=config.gateOpen?years(p.wormhole.proper):'—';
 for(const key of ['normal','wormhole']){$('#'+key+'-progress').value=state[key].progress;$('#'+key+'-clock').textContent=format(state[key].clock)+' 年'}
 $('#normal-status').textContent=state.normal.arrived?'已抵達 · 星環上停留':time===0?'待命':'正常航路中';const stageNames={closed:'雙門已關閉',approach:time===0?'待命':'接近入口',throat:portalMage?.telemetry?.travelMode||'蟲洞內部',exit:'已穿出 · 前往星環',arrived:'已抵達 · 星環上停留'};$('#wormhole-status').textContent=portalMage?.body?.crossingEntry?'跨入門面':portalMage?.body?.crossingExit?'跨出門面':stageNames[state.wormhole.stage];$('#throat-status').textContent=state.wormhole.stage==='throat'?(portalMage?.telemetry?.carpetBlend>.95?'魔毯巡航':'披風變換')+' · '+(state.wormhole.tunnelProgress*100).toFixed(0)+'%':state.wormhole.tunnelProgress===1?'已穿出':'等待進入';
 const waiting=Math.max(0,time-p.wormhole.arrival);
 $('#comparison-result').textContent=!config.beta?'速度為 0，兩位旅者都無法出發。':!config.gateOpen?'雙門已收起，奇異巴拉留在出發站等候。':state.normal.arrived?'同一時刻重逢：超拉經過 '+format(state.normal.clock)+' 年；奇異巴拉經過 '+format(state.wormhole.clock)+' 年（旅程 '+format(p.wormhole.proper)+' ＋等候 '+format(waiting)+'）。':state.wormhole.arrived?'奇異巴拉已抵達，等候 '+format(waiting)+' 年；身上時鐘繼續前進。':'蟲洞總路程 '+format(p.wormhole.length,1)+' 光年，預計早 '+format(p.normal.arrival-p.wormhole.arrival)+' 年抵達。';
 const finished=state.normal.arrived;$('#journey-play').disabled=!ready||!config.beta||finished;$('#journey-play').textContent=finished?'比較完成':running?'暫停比較':time>0?'繼續比較':'同時出發';$('#journey-reset').disabled=!ready;$('#super-landing-preview').disabled=!ready||!config.beta;$('#portal-entry-preview').disabled=!ready||!config.beta;$('#portal-exit-preview').disabled=!ready||!config.beta;$('#carpet-story-preview').disabled=!ready||!config.beta;$('#journey-seek').disabled=!ready||!config.beta;$('#journey-seek').value=config.beta?String(time/p.normal.arrival):'0';
 $('#beta-label').textContent=config.beta.toFixed(3)+' c';$('#distance-label').textContent=config.distance+' 光年';$('#throat-label').textContent=config.throat+' 光年';$('#wormhole-length').textContent=String(p.wormhole.length);$('#fold-label').textContent=config.fold+'°';$('#intrinsic-distance').textContent=String(config.distance);$('#gate-toggle').textContent=config.gateOpen?'奇異巴拉收起雙門':'奇異巴拉開啟雙門';$('#gate-toggle').setAttribute('aria-pressed',String(config.gateOpen));
 $('#scene-status').textContent=cameraMode==='mage'&&state.wormhole.stage==='throat'?'正在通道內跟隨奇異巴拉；可切換雙星全景。':state.wormhole.stage==='throat'?'奇異巴拉在通道內；選「跟隨奇異巴拉」可看內部。':'拖曳環繞，滾輪縮放；角色比例為展示尺度。';
}
function reset(){previewUntil=null;previewLabel='';time=0;running=false;state=journeyState(config,time);if(ready)updateActors();renderUI()}
for(const [id,key] of [['journey-beta','beta'],['journey-distance','distance'],['journey-throat','throat']])$('#'+id).oninput=e=>{config[key]=Number(e.target.value);rebuildLayout();reset();if(key==='distance')setCamera('overview')};
$('#space-fold').oninput=e=>{config.fold=Number(e.target.value);$('#fold-label').textContent=config.fold+'°';layoutPending=true};$('#space-grid').onchange=e=>grid.visible=e.target.checked;$('#playback-rate').onchange=e=>config.yearsPerSecond=Number(e.target.value);
$('#journey-play').onclick=()=>{running=!running;renderUI()};$('#journey-reset').onclick=reset;$('#gate-toggle').onclick=()=>{config.gateOpen=!config.gateOpen;reset()};$('#journey-seek').oninput=e=>{previewUntil=null;previewLabel='';running=false;time=journeyPlan(config).normal.arrival*Number(e.target.value);state=journeyState(config,time);updateActors();updateCamera();renderUI()};
function previewPassage(exit){config.gateOpen=true;const centre=(config.access+(exit?config.throat:0))/Math.max(.001,config.beta);if(!config.beta)return;time=Math.max(0,centre-1.3);previewUntil=centre+1.3;previewLabel=exit?'跨出慢動作':'跨入慢動作';config.yearsPerSecond=.5;$('#playback-rate').value='.5';state=journeyState(config,time);running=true;updateActors();setCamera('gate');renderUI()}
$('#portal-entry-preview').onclick=()=>previewPassage(false);$('#portal-exit-preview').onclick=()=>previewPassage(true);
$('#super-landing-preview').onclick=()=>{if(!config.beta)return;superLanding.prepare(config);time=(config.distance-superLanding.span-1)/config.beta;previewUntil=journeyPlan(config).normal.arrival;previewLabel='星環前緣著陸';config.yearsPerSecond=.5;$('#playback-rate').value='.5';state=journeyState(config,time);running=true;updateActors();setCamera('landing');renderUI()};
$('#carpet-story-preview').onclick=()=>{if(!config.beta)return;config.gateOpen=true;time=Math.max(0,config.access/config.beta-1.0);previewUntil=(config.access+config.throat)/config.beta+1.0;previewLabel='披風魔毯故事 · 加長巡航';config.yearsPerSecond=.25;$('#playback-rate').value='.25';state=journeyState(config,time);running=true;updateActors();setCamera('mage');renderUI()};
$('#journey-highlights').addEventListener('click',e=>{if(e.target.closest('button'))$('#journey-highlights').open=false});
document.addEventListener('pointerdown',e=>{if(!e.target.closest('#journey-highlights'))$('#journey-highlights').open=false});
document.addEventListener('keydown',e=>{if(e.key==='Escape')$('#journey-highlights').open=false});
async function boot(){
 try{
  assets=await loadUniverseAssets((done,total)=>$('#loading').textContent='正在載入兩個世界 · '+done+' / '+total);
  homeMount=new THREE.Group();home=buildHomePlanet(assets);homeMount.add(home);atmosphere(homeMount,6.45,0x49a2bd);world.add(homeMount);
   auroraMount=new THREE.Group();aurora=assets.clone(assets.kit.assets['aurora-planet'].id,1.15).root;auroraSurface=new THREE.Group();const surfaces=[];aurora.traverse(n=>{if(n.isMesh&&/^aurora-garden-(ocean|continuous-mountains)/.test(n.name))surfaces.push(n);if(n.isMesh&&n.name==='aurora-garden-ocean'){n.material=n.material.clone();n.material.roughness=.4;n.material.metalness=.03}});aurora.add(auroraSurface);for(const mesh of surfaces)auroraSurface.add(mesh);auroraMount.add(aurora);atmosphere(auroraMount,7.3,0x78c9df);world.add(auroraMount);
  f8=assets.clone(assets.layout.space_assets.f8.id,.32).root;homeMount.add(f8);
  ({group:superCarrier,model:superModel}=carrier(assets.layout.fable_assets['capy-super'].id,1.2));
  superLanding=new HeroRingLanding(superCarrier,superModel);
  portalMage=new PortalMage({clone:assets.clone,id:assets.kit.assets['capy-mage'].id,world,throatScene,appearance:assets.kit.appearance?.['capy-mage']});mageCarrier=portalMage.roles.entry.carrier;mageModel=portalMage.roles.entry.model;tunnelMage=portalMage.roles.inside.carrier;
  mageDrop=footDrop(portalMage.roles.exit.model);
   gates=[setupGate('aurora'),setupGate('home')];planetLabels=[makeLabel('卡皮星 / A'),makeLabel('曙光星 / B','#d1e6da')];stationLabels=[makeLabel('A · 共同出發站','#a5dbea'),makeLabel('B · 星環外緣','#f4cd93')];world.add(...planetLabels,...stationLabels);
  ready=true;document.body.dataset.ready='true';rebuildLayout();setCamera('overview');reset();$('#loading').hidden=true;
 }catch(e){document.body.dataset.ready='failed';$('#loading').textContent='場景載入未完成：'+e.message;console.error(e)}
}
function renderFrame(){if(ready&&cameraMode==='mage'&&state.wormhole.stage==='throat')renderer.render(throatScene,insideCamera);else renderer.render(scene,camera);if(ready&&throatVisible)throatRenderer.render(throatScene,throatCamera)}
function applyUniverseQuality(profile){const box=host.getBoundingClientRect();renderer.setPixelRatio(renderPixelRatio(profile,box.width,box.height,devicePixelRatio));throatRenderer.setPixelRatio(Math.min(devicePixelRatio,profile.pixelRatio,1.3))}
renderLoop=new SceneRenderLoop({onQuality:applyUniverseQuality,onFrame:(dt,viewportNow)=>{
 if(browserFrame.settling)return;if(viewportNow>=nextViewportCheck){nextViewportCheck=viewportNow+100;resize()}
 wallTime+=dt;gateAmount=THREE.MathUtils.damp(gateAmount,config.gateOpen?1:0,4,dt);
 if(ready&&layoutPending){const started=performance.now();layoutPending=false;rebuildLayout();if(cameraMode==='overview')setCamera('overview');document.body.dataset.foldPerformance=JSON.stringify({fold:config.fold,layoutMs:performance.now()-started,landingPrepared:superLanding.prepared})}
 if(ready){if(running&&config.beta){time=Math.min(journeyPlan(config).normal.arrival,time+dt*config.yearsPerSecond);state=journeyState(config,time);if(previewUntil!==null&&time>=previewUntil){time=previewUntil;state=journeyState(config,time);running=false;previewUntil=null;previewLabel=''}if(state.normal.arrived)running=false}updateActors();home.rotation.y+=dt*.035;auroraSurface.rotation.y+=dt*.045;updateCamera();if(viewportNow-lastUiRender>=100){renderUI();lastUiRender=viewportNow}if(wallTime-lastPreview>.35&&gateAmount>.01){scene.updateMatrixWorld(true);renderPortalPreviews();lastPreview=wallTime}
  if(wallTime-lastReport>.12){document.body.dataset.journey=JSON.stringify({config,time,running,state,cameraMode,superPosition:superCarrier.position.toArray(),magePosition:mageCarrier.position.toArray(),mageVisible:portalMage.roles.entry.carrier.visible||portalMage.roles.exit.carrier.visible,tunnelMageVisible:tunnelMage.visible,portalPassage:portalMage.telemetry,superAppearance:'original asset materials',gateOpen:config.gateOpen,gateAmount,assets:assets.count,portalPeers:gates.map(g=>g.peer),arrivalRing:landingReport(),portalLayout:portalPlacement,superIdleFacing:new THREE.Vector3(0,0,1).applyQuaternion(superCarrier.quaternion).toArray(),gateFrames:gates.map(g=>({position:g.group.position.toArray(),up:new THREE.Vector3(0,1,0).applyQuaternion(g.group.quaternion).toArray(),front:new THREE.Vector3(0,0,1).applyQuaternion(g.group.quaternion).toArray()})),preview:previewLabel,model:'static unit-lapse paths; flat exterior, ultrastatic radial throat; no binary gravity, no mouth time offset',foldingChangesIntrinsicLength:false});lastReport=wallTime}}
 renderFrame();return {calls:renderer.info.render.calls,triangles:renderer.info.render.triangles,pixelRatio:renderer.getPixelRatio()};
}});
renderLoop.installControl($('aside[aria-label="遠航比較與設定"]'));
installViewportReport();renderUI();boot();
