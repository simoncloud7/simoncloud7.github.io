import * as THREE from 'three';
import {spiderFrame} from './spider-ground.js?v=41d10fd0dc43';
const clamp=x=>THREE.MathUtils.clamp(x,0,1),smooth=x=>{x=clamp(x);return x*x*(3-2*x)};
const INTRO=2,CIRCUIT=36,BASE_HEIGHT=1.4;
export const SPIDER_SUSPEND_AT=14,SPIDER_SUSPEND_DURATION=6;
export const SPIDER_LEAP_DURATION=INTRO+CIRCUIT+SPIDER_SUSPEND_DURATION;
export function cityLeapBeat(time){
 const suspend=time>=SPIDER_SUSPEND_AT&&time<SPIDER_SUSPEND_AT+SPIDER_SUSPEND_DURATION,suspendTime=suspend?time-SPIDER_SUSPEND_AT:null,routeTime=time<SPIDER_SUSPEND_AT?time:suspend?SPIDER_SUSPEND_AT:time-SPIDER_SUSPEND_DURATION,elapsed=THREE.MathUtils.clamp(routeTime-INTRO,0,CIRCUIT),hop=Math.min(5,Math.floor(elapsed/6)),local=elapsed-hop*6,u=local/6,started=time>=INTRO;
 const turning=suspend?(suspendTime<1.35||suspendTime>=4.4):time<.65,tether=suspend?suspendTime>=1.6&&suspendTime<4.4:started?u<.55:time>=.7,extension=suspend?smooth((suspendTime-1.6)/.4)*(1-smooth((suspendTime-4)/.4)):started?(elapsed<6?1:smooth(u/.09)):smooth((time-.7)/.4);
 return {hop,local,u,routeU:smooth(u),suspend,suspendTime,turning,lap:1,displayTime:Math.min(time,SPIDER_LEAP_DURATION),air:time>1.1&&time<SPIDER_LEAP_DURATION,tether,extension,phase:suspend?(suspendTime<1.35?'收絲轉身 · 對準前方屋頂':suspendTime<1.6?'轉身完成 · 瞄準兩側':suspendTime<2?'左右腳尖射絲 · 收緊定位':suspendTime<4?'雙絲定住 · 空中懸停':suspendTime<4.4?'收回蛛絲 · 準備再飛':'轉向航路 · 再次飛躍'):time<.7?'轉身對準城市屋頂':time<1.1?'腳尖射絲 · 準備離地':time<INTRO?'收緊蛛絲 · 拉升起步':u<.55?'接絲擺盪 · 持續前進':'放絲飛跳 · 空中換下一個錨點'};
}
function roofVertex(root,globe){
 const radial=root.position.clone().normalize(),inverse=globe.matrixWorld.clone().invert(),point=new THREE.Vector3();let best=null,score=-Infinity;root.updateWorldMatrix(true,true);
 root.traverse(n=>{if(!n.isMesh)return;const matrix=inverse.clone().multiply(n.matrixWorld),p=n.geometry.attributes.position;for(let i=0;i<p.count;i++){point.fromBufferAttribute(p,i).applyMatrix4(matrix);const height=point.dot(radial);if(height>score){best=point.clone();score=height}}});return best;
}
export class SpiderCityLeap{
 constructor({globe,actor,rig,silk,ground,frameAt,paths,home,homeQuaternion,anchorSites=[]}){Object.assign(this,{globe,actor,rig,silk,ground,frameAt,home,homeQuaternion,anchorSites});this.street=new THREE.CatmullRomCurve3(paths[0].map(([x,z])=>new THREE.Vector3(x,0,z)));this.ready=false}
 prepare(){
  this.failed=false;this.dropAt=null;this.recoverAt=null;this.failedAt=null;this.attachment=null;this.lastPoseTime=null;this.lastAttitude=null;this.castAt=0;this.threadSide=null;this.time=0;this.globe.updateWorldMatrix(true,true);
  const n=this.home.radial,homeXZ=new THREE.Vector3(Math.atan2(n.x,n.y)*18,0,Math.asin(n.z)*18),out=[.25,.5,.73].map(u=>this.street.getPointAt(u)),back=[.5,.25].map(u=>{const p=this.street.getPointAt(u);p.z-=2;return p});this.route=new THREE.CatmullRomCurve3([homeXZ,...out,...back],true,'catmullrom',.3);
  this.roofs=this.anchorSites.map(({root,name})=>({root,point:roofVertex(root,this.globe),name})).filter(p=>p.point&&p.point.length()>18.8);this.legs=[];
  const waypoint=i=>{if(i===0||i===6)return this.home;const p=this.route.getPointAt(i/6);return this.ground.atXZ(p.x,p.z)};
  for(let i=0;i<6;i++){const a=waypoint(i),b=waypoint(i+1),p=this.route.getPointAt((i+.2)/6),aheadNormal=this.frameAt(p.x,p.z).normal,direction=aheadNormal.clone().multiplyScalar(18.2).sub(a.point).normalize(),middle=a.point.clone().lerp(b.point,.45),ahead=this.roofs.filter(r=>r.point.clone().sub(a.point).dot(direction)>.3),overhead=this.roofs.filter(r=>r.point.clone().sub(middle.clone().normalize().multiplyScalar(18.2)).dot(middle.clone().normalize())>BASE_HEIGHT+1.1),forwardHigh=overhead.filter(r=>ahead.includes(r)),choices=forwardHigh.length?forwardHigh:overhead.length?overhead:ahead.length?ahead:this.roofs,roof=[...choices].sort((x,y)=>x.point.distanceTo(middle)-y.point.distanceTo(middle))[0],anchor=roof?.point.clone()||this.home.point.clone().addScaledVector(this.home.normal,3.2);
   this.legs.push({a,b,index:i,anchor,name:roof?.name||'招牌固定座',height:THREE.MathUtils.clamp(anchor.clone().sub(middle.clone().normalize().multiplyScalar(18.2)).dot(middle.clone().normalize())-BASE_HEIGHT-1,.25,1.4)});
  }this.suspension=this.planSuspension();this.ready=true;
 }
 pointAt(leg,u){
  const p=this.route.getPointAt((leg.index+u)/6),normal=this.frameAt(p.x,p.z).normal,radius=THREE.MathUtils.lerp(leg.a.radius,leg.b.radius,u);return {point:normal.clone().multiplyScalar(radius),normal,radial:normal,radius};
 }
 headingAt(leg,u,surface){
  const progress=(leg.index+u)/6,a=this.route.getPointAt((progress-.0005+1)%1),b=this.route.getPointAt((progress+.0005)%1);
  return this.frameAt(b.x,b.z).normal.sub(this.frameAt(a.x,a.z).normal).projectOnPlane(surface.normal).normalize();
 }
 planSuspension(){
  const surface=this.pointAt(this.legs[2],0),up=surface.normal;let best=null;
  for(let i=0;i<this.roofs.length;i++)for(let j=i+1;j<this.roofs.length;j++){
   const a=this.roofs[i],b=this.roofs[j],da=a.point.clone().sub(surface.point).projectOnPlane(up),db=b.point.clone().sub(surface.point).projectOnPlane(up),forward=da.clone().normalize().add(db.clone().normalize()).normalize(),right=new THREE.Vector3().crossVectors(up,forward),xa=da.dot(right),xb=db.dot(right);
   if(xa*xb>=0||Math.min(Math.abs(xa),Math.abs(xb))<1.3||Math.min(da.dot(forward),db.dot(forward))<1.4)continue;
   const score=da.length()+db.length();if(best&&best.score<=score)continue;
   const roofHeight=Math.min(a.point.clone().sub(surface.point).dot(up),b.point.clone().sub(surface.point).dot(up));
   best={score,roofs:xa<0?[a,b]:[b,a],q:spiderFrame(up,forward),height:THREE.MathUtils.clamp(roofHeight-1.5,.55,1.1)};
  }return best;
 }
 roofAttachments(origins){
  // Classify in the actor's current frame, including turns and globe rotation.
  // A roof must also be outside that side's nozzle, so silk never crosses the body.
  const inverse=this.actor.matrixWorld.clone().invert(),localOrigins=origins.map(p=>p.clone().applyMatrix4(inverse)),roofs=this.roofs.map(roof=>({roof,world:this.globe.localToWorld(roof.point.clone())}));
  return [-1,1].map(side=>{const index=side<0?2:6,origin=localOrigins[index],choices=roofs.map(r=>({...r,local:r.world.clone().applyMatrix4(inverse)})).filter(r=>r.local.x*side>Math.max(.45,origin.x*side+.15)&&r.local.z>origin.z+.18);
   const held=this.attachment?.side===side?choices.find(r=>r.roof===this.attachment.roof):null;
   return held||choices.sort((a,b)=>a.local.distanceTo(origin)-b.local.distanceTo(origin))[0];
  });
 }
 toggleThread(){
  if(this.failed)return;if(this.dropAt!==null){this.recoverAt=this.time;this.recoverHeight=this.height;this.dropAt=null}else{this.dropAt=this.time;this.dropHeight=this.height;this.recoverAt=null}
 }
 pose(time){
  if(!this.ready)this.prepare();this.time=time;const effective=this.failed?this.failedAt:time,beat=cityLeapBeat(effective),leg=this.legs[beat.hop];let surface=effective<INTRO?this.home:this.pointAt(leg,beat.routeU),height=effective<INTRO?BASE_HEIGHT*smooth((effective-1.1)/.9):BASE_HEIGHT+4*leg.height*beat.routeU*(1-beat.routeU);
  const heading=this.headingAt(leg,beat.routeU,surface);let tether=beat.tether,extension=beat.extension,q=spiderFrame(surface.normal,heading);
  if(effective<INTRO)q=this.homeQuaternion.clone().slerp(q,smooth(effective/.65));
  if(beat.suspend&&this.suspension){const s=beat.suspendTime,hold=this.suspension,turn=s<4.4?smooth((s-.25)/1.1):1-smooth((s-4.4)/1.25);q.slerp(hold.q,turn);height=THREE.MathUtils.lerp(BASE_HEIGHT,hold.height,smooth(s/1.35)*(1-smooth((s-4.4)/1.6)))}
  if(this.dropAt!==null){const dt=time-this.dropAt;height=Math.max(0,this.dropHeight-2.8*dt*dt);tether=false;extension=0;if(height===0){this.failed=true;this.failedAt=effective}}
  if(this.recoverAt!==null){const dt=time-this.recoverAt;height=THREE.MathUtils.lerp(this.recoverHeight,height,smooth(dt/.9));tether=true;extension=smooth(dt/.2);if(dt>.9)this.recoverAt=null}
  const finish=this.dropAt===null?smooth((effective-(SPIDER_LEAP_DURATION-1.4))/1.4):0;height*=1-finish;if(finish===1)surface=this.home;
  if(this.failed){surface=this.ground.at(surface.radial);height=0;tether=false;extension=0;beat.air=false;beat.phase='落地了 · 挑戰失敗'}else if(this.dropAt!==null)beat.phase='失去連線 · 落地前重新射絲！';
  if(effective>=INTRO&&!this.failed&&!beat.suspend)q.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(.25*Math.sin(Math.PI*beat.routeU),0,.10*Math.sin(2*Math.PI*beat.routeU)*(beat.hop%2?1:-1))));
  q.slerp(this.homeQuaternion,finish);const desired=q.clone(),dt=this.lastPoseTime===null?null:time-this.lastPoseTime;
  // The route doubles back tightly. Turn the body at a bounded rate instead of
  // snapping to its new tangent, and keep the nozzles off until it catches up.
  if(this.lastAttitude&&dt!==null&&dt>=0&&dt<=.25)q.copy(this.lastAttitude).rotateTowards(desired,2.5*dt);
  if(q.angleTo(desired)>.025){beat.turning=true;if(!beat.suspend)beat.phase='收絲轉身 · 對準下一個屋頂'}this.lastPoseTime=time;this.lastAttitude=q.clone();
  const body=this.actor.getObjectByName('twin-body-pivot'),holdBody=beat.suspend?smooth(beat.suspendTime/.25)*(1-smooth((beat.suspendTime-5.65)/.35)):0;body.position.set(0,this.failed?.56:.65,0);body.rotation.set(this.failed?.18:height>.05?-.10*(1-finish)*(1-holdBody):0,0,0);
  for(const side of [-1,1]){this.actor.getObjectByName('arm-'+side).rotation.set(height>.05?THREE.MathUtils.lerp(-.85,-.12,finish):-.12,0,side*(height>.05?.16*(1-finish):0));this.actor.getObjectByName('leg-'+side).rotation.set(height>.05?(-.45-.15*Math.sin(beat.u*Math.PI))*(1-finish):this.failed?.16:0,0,0)}
  this.clearance=this.ground.place(this.actor,surface,q,height);this.surface=surface;this.height=height;this.beat=beat;this.anchorName=leg.name;
  if(beat.turning)tether=false;
  if(!tether||this.attachment?.hop!==beat.hop||time<this.castAt)this.attachment=null;
  const origins=this.rig.legs.map(leg=>leg.tip.getWorldPosition(new THREE.Vector3())),attachments=this.roofAttachments(origins),preferred=beat.hop%2,choice=attachments[preferred]||attachments[1-preferred],side=choice?(attachments.indexOf(choice)===0?-1:1):null,index=side<0?2:6,targets=origins.map((p,i)=>attachments[i<4?0:1]?.world.clone()||p.clone()),active=Array(8).fill(false);
  if(beat.suspend){
   this.attachment=null;
   if(tether&&this.suspension)for(const [s,i] of [[-1,3],[1,7]]){const roof=this.suspension.roofs[s<0?0:1],target=this.globe.localToWorld(roof.point.clone()),goal=this.actor.worldToLocal(target.clone()),origin=this.actor.worldToLocal(origins[i].clone());if(this.roofs.includes(roof)&&goal.x*s>Math.max(.45,origin.x*s+.15)&&goal.z>origin.z+.18){targets[i]=target;active[i]=true}}
  }else if(tether&&choice){if(this.attachment?.roof!==choice.roof||this.attachment.side!==side){this.castAt=time;this.attachment={roof:choice.roof,side,hop:beat.hop}}active[index]=true;extension=Math.min(extension,smooth((time-this.castAt)/.18))}else this.attachment=null;
  this.threadSide=beat.suspend&&active[3]&&active[7]?'both':this.attachment?(side<0?'left':'right'):null;this.anchorName=this.threadSide==='both'?this.suspension.roofs.map(r=>r.name).join(' / '):this.attachment?.roof.name||leg.name;this.rig.pose(time,{working:height>.05,deploy:1,targets:tether?targets.map((p,i)=>active[i]?p:null):[]});this.silk.group.visible=!this.failed;this.silk.update(this.rig.emitters(),targets,tether?extension:0,time,{active,taut:true});this.targets=targets;return beat;
 }
 cameraPose(aspect,homePose){
  const up=this.surface.normal.clone().transformDirection(this.globe.matrixWorld),target=this.actor.getWorldPosition(new THREE.Vector3()).addScaledVector(up,.85),direction=new THREE.Vector3(4.5,3.5,8).transformDirection(this.globe.matrixWorld),follow={target,position:target.clone().addScaledVector(direction,aspect<1?12:9),up},blend=smooth(this.time/INTRO);return {target:homePose.target.clone().lerp(follow.target,blend),position:homePose.position.clone().lerp(follow.position,blend),up:homePose.up.clone().lerp(follow.up,blend).normalize()};
 }
}
