import * as THREE from 'three';
import {spiderFrame} from './spider-ground.js?v=c38a92d35e93';
const clamp=x=>THREE.MathUtils.clamp(x,0,1),smooth=x=>{x=clamp(x);return x*x*(3-2*x)};
export const SPIDER_LEAP_DURATION=38;
const INTRO=2,CIRCUIT=36,BASE_HEIGHT=1.4;
export function cityLeapBeat(time){
 const elapsed=THREE.MathUtils.clamp(time-INTRO,0,CIRCUIT),hop=Math.min(5,Math.floor(elapsed/6)),local=elapsed-hop*6,u=local/6,started=time>=INTRO;
 return {hop,local,u,lap:1,displayTime:Math.min(time,SPIDER_LEAP_DURATION),air:time>1.1&&time<SPIDER_LEAP_DURATION,tether:started?u<.55:time>=.7,extension:started?(elapsed<6?1:smooth(u/.09)):smooth((time-.7)/.4),phase:time<.7?'對準城市屋頂':time<1.1?'腳尖射絲 · 準備離地':time<INTRO?'收緊蛛絲 · 拉升起步':u<.55?'接絲擺盪 · 持續前進':'放絲飛跳 · 空中換下一個錨點'};
}
function roofVertex(root,globe){
 const radial=root.position.clone().normalize(),inverse=globe.matrixWorld.clone().invert(),point=new THREE.Vector3();let best=null,score=-Infinity;root.updateWorldMatrix(true,true);
 root.traverse(n=>{if(!n.isMesh)return;const matrix=inverse.clone().multiply(n.matrixWorld),p=n.geometry.attributes.position;for(let i=0;i<p.count;i++){point.fromBufferAttribute(p,i).applyMatrix4(matrix);const height=point.dot(radial);if(height>score){best=point.clone();score=height}}});return best;
}
export class SpiderCityLeap{
 constructor({globe,actor,rig,silk,ground,frameAt,paths,home,homeQuaternion,anchorSites=[]}){Object.assign(this,{globe,actor,rig,silk,ground,frameAt,home,homeQuaternion,anchorSites});this.street=new THREE.CatmullRomCurve3(paths[0].map(([x,z])=>new THREE.Vector3(x,0,z)));this.ready=false}
 prepare(){
  this.failed=false;this.dropAt=null;this.recoverAt=null;this.failedAt=null;this.time=0;this.globe.updateWorldMatrix(true,true);
  const n=this.home.radial,homeXZ=new THREE.Vector3(Math.atan2(n.x,n.y)*18,0,Math.asin(n.z)*18),out=[.25,.5,.73].map(u=>this.street.getPointAt(u)),back=[.5,.25].map(u=>{const p=this.street.getPointAt(u);p.z-=2;return p});this.route=new THREE.CatmullRomCurve3([homeXZ,...out,...back],true,'catmullrom',.3);
  this.roofs=this.anchorSites.map(({root,name})=>({root,point:roofVertex(root,this.globe),name})).filter(p=>p.point&&p.point.length()>18.8);this.legs=[];
  const waypoint=i=>{if(i===0||i===6)return this.home;const p=this.route.getPointAt(i/6);return this.ground.atXZ(p.x,p.z)};
  for(let i=0;i<6;i++){const a=waypoint(i),b=waypoint(i+1),p=this.route.getPointAt((i+.2)/6),aheadNormal=this.frameAt(p.x,p.z).normal,direction=aheadNormal.clone().multiplyScalar(18.2).sub(a.point).normalize(),middle=a.point.clone().lerp(b.point,.45),ahead=this.roofs.filter(r=>r.point.clone().sub(a.point).dot(direction)>.3),overhead=this.roofs.filter(r=>r.point.clone().sub(middle.clone().normalize().multiplyScalar(18.2)).dot(middle.clone().normalize())>BASE_HEIGHT+1.1),forwardHigh=overhead.filter(r=>ahead.includes(r)),choices=forwardHigh.length?forwardHigh:overhead.length?overhead:ahead.length?ahead:this.roofs,roof=[...choices].sort((x,y)=>x.point.distanceTo(middle)-y.point.distanceTo(middle))[0],anchor=roof?.point.clone()||this.home.point.clone().addScaledVector(this.home.normal,3.2);
   this.legs.push({a,b,index:i,anchor,name:roof?.name||'招牌固定座',height:THREE.MathUtils.clamp(anchor.clone().sub(middle.clone().normalize().multiplyScalar(18.2)).dot(middle.clone().normalize())-BASE_HEIGHT-1,.25,1.4)});
  }this.ready=true;
 }
 pointAt(leg,u){
  const p=this.route.getPointAt((leg.index+u)/6),normal=this.frameAt(p.x,p.z).normal,radius=THREE.MathUtils.lerp(leg.a.radius,leg.b.radius,u);return {point:normal.clone().multiplyScalar(radius),normal,radial:normal,radius};
 }
 toggleThread(){
  if(this.failed)return;if(this.dropAt!==null){this.recoverAt=this.time;this.recoverHeight=this.height;this.dropAt=null}else{this.dropAt=this.time;this.dropHeight=this.height;this.recoverAt=null}
 }
 pose(time){
  if(!this.ready)this.prepare();this.time=time;const effective=this.failed?this.failedAt:time,beat=cityLeapBeat(effective),leg=this.legs[beat.hop];let surface=effective<INTRO?this.home:this.pointAt(leg,beat.u),height=effective<INTRO?BASE_HEIGHT*smooth((effective-1.1)/.9):BASE_HEIGHT+4*leg.height*beat.u*(1-beat.u);
  const p=this.route.getPointAt(((beat.hop+beat.u)/6+.001)%1),heading=this.frameAt(p.x,p.z).normal.multiplyScalar(surface.radius).sub(surface.point).projectOnPlane(surface.normal).normalize(),towardAnchor=leg.anchor.clone().sub(surface.point).projectOnPlane(surface.normal).normalize();let tether=beat.tether,extension=beat.extension;
  if(this.dropAt!==null){const dt=time-this.dropAt;height=Math.max(0,this.dropHeight-2.8*dt*dt);tether=false;extension=0;if(height===0){this.failed=true;this.failedAt=effective}}
  if(this.recoverAt!==null){const dt=time-this.recoverAt;height=THREE.MathUtils.lerp(this.recoverHeight,height,smooth(dt/.9));tether=true;extension=smooth(dt/.2);if(dt>.9)this.recoverAt=null}
  const finish=this.dropAt===null?smooth((effective-(SPIDER_LEAP_DURATION-1.4))/1.4):0;height*=1-finish;if(finish===1)surface=this.home;
  if(this.failed){surface=this.ground.at(surface.radial);height=0;tether=false;extension=0;beat.air=false;beat.phase='落地了 · 挑戰失敗'}else if(this.dropAt!==null)beat.phase='失去連線 · 落地前重新射絲！';
  let q=spiderFrame(surface.normal,heading);if(effective<INTRO)q=this.homeQuaternion.clone().slerp(spiderFrame(surface.normal,towardAnchor),smooth(effective/INTRO));else if(effective<INTRO+.8)q=spiderFrame(surface.normal,towardAnchor).slerp(q,smooth((effective-INTRO)/.8));if(effective>=INTRO&&!this.failed)q.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(.25*Math.sin(Math.PI*beat.u),0,.10*Math.sin(2*Math.PI*beat.u)*(beat.hop%2?1:-1))));
  q.slerp(this.homeQuaternion,finish);const body=this.actor.getObjectByName('twin-body-pivot');body.position.set(0,this.failed?.56:.65,0);body.rotation.set(this.failed?.18:height>.05?-.10*(1-finish):0,0,0);
  for(const side of [-1,1]){this.actor.getObjectByName('arm-'+side).rotation.set(height>.05?THREE.MathUtils.lerp(-.85,-.12,finish):-.12,0,side*(height>.05?.16*(1-finish):0));this.actor.getObjectByName('leg-'+side).rotation.set(height>.05?(-.45-.15*Math.sin(beat.u*Math.PI))*(1-finish):this.failed?.16:0,0,0)}
  this.clearance=this.ground.place(this.actor,surface,q,height);this.surface=surface;this.height=height;this.beat=beat;this.anchorName=leg.name;
  let attachment=leg;if(this.recoverAt!==null&&beat.u>.55)attachment=this.legs[(beat.hop+1)%6];const target=this.globe.localToWorld(attachment.anchor.clone()),targets=Array.from({length:8},()=>target.clone()),active=Array.from({length:8},(_,i)=>i===(beat.hop%2?6:2));this.rig.pose(time,{working:height>.05,deploy:1,targets:tether?targets.map((p,i)=>active[i]?p:null):[]});this.silk.group.visible=!this.failed;this.silk.update(this.rig.emitters(),targets,tether?extension:0,time,{active,taut:true});this.targets=targets;return beat;
 }
 cameraPose(aspect,homePose){
  const up=this.surface.normal.clone().transformDirection(this.globe.matrixWorld),target=this.actor.getWorldPosition(new THREE.Vector3()).addScaledVector(up,.85),direction=new THREE.Vector3(4.5,3.5,8).transformDirection(this.globe.matrixWorld),follow={target,position:target.clone().addScaledVector(direction,aspect<1?12:9),up},blend=smooth(this.time/INTRO);return {target:homePose.target.clone().lerp(follow.target,blend),position:homePose.position.clone().lerp(follow.position,blend),up:homePose.up.clone().lerp(follow.up,blend).normalize()};
 }
}
