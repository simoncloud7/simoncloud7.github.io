export function sampleHeroMotion(clip,time){
 const frames=clip.frames,t=Math.max(0,Math.min(clip.duration,time));let a=frames[0],b=frames.at(-1);
 for(let i=1;i<frames.length;i++)if(t<=frames[i].t){a=frames[i-1];b=frames[i];break}
 const u=Math.max(0,Math.min(1,(t-a.t)/(b.t-a.t||1))),s=u*u*(3-2*u),out={};
 for(const key of ['body','single','arms','height','z'])out[key]=a[key]+(b[key]-a[key])*s;
 return out;
}
// A moving demonstration stage: accelerate, cruise, then stop; no clock physics.
export function burstTravel(t){const i=u=>u*u*u-.5*u*u*u*u;t=Math.max(0,Math.min(16,t));return t<2?10*i(t/2):t<14?5+5*(t-2):65+5*(t-14-2*i((t-14)/2))}
