import {Vector3} from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
const worldUp=new Vector3(0,1,0);

// The bundled OrbitControls caches camera.up once in its constructor. Surface
// and flight views change that axis, so keep its cached basis in sync. Keep
// this adapter beside the scene source rather than modifying the vendor copy.
export class FrameOrbitControls extends OrbitControls{
 update(dt=null){
  if(this._quat){this._quat.setFromUnitVectors(this.object.up,worldUp);this._quatInverse.copy(this._quat).invert()}
  return super.update(dt);
 }
 clearMotion(){this._sphericalDelta.set(0,0,0);this._panOffset.set(0,0,0);this._scale=1}

}
