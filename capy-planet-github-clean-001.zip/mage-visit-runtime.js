import * as THREE from 'three';
import {visitPose,visitFallNormal,VISIT_PERIOD,VISIT_DURATION} from './spacewalk.mjs?v=898c7c496a3a';
import {isHeroCloth,setGaitPose} from './hero-style.js?v=898c7c496a3a';
import {weaverLift} from './cape-motion.mjs?v=898c7c496a3a';
import {poseSuspendedWeaver,updateSuspendedCape} from './weaver-flight.js?v=898c7c496a3a';
export class MageVisitSystem{
 constructor({scene,globe,surfaces,ocean,marine,cloneAsset,assets,camera}){
  Object.assign(this,{scene,globe,surfaces,ocean,marine,camera});this.time=-16;this.siteCycle=null;this.forcedRescue=null;
  this.root=new THREE.Group();globe.add(this.root);this.actor=cloneAsset(assets['capy-mage'].id,.6).root;this.root.add(this.actor);this.plane=new THREE.Plane();this.cloth=[];
  this.actor.traverse(n=>{if(n.isMesh){n.material=n.material.clone();n.material.clipShadows=true;if(isHeroCloth(n.name)){n.geometry=n.geometry.clone();n.geometry.computeBoundingBox();this.cloth.push({mesh:n,base:n.geometry.attributes.position.array.slice(),center:n.geometry.boundingBox.getCenter(new THREE.Vector3()),size:n.geometry.boundingBox.getSize(new THREE.Vector3())})}}});
  this.gate=new THREE.Group();const frame=cloneAsset(assets['wormhole-gate'].id,1).root;frame.position.sub(new THREE.Box3().setFromObject(frame).getCenter(new THREE.Vector3()));this.gate.add(frame);this.root.add(this.gate);
  const disc=new THREE.Mesh(new THREE.CircleGeometry(1.24,64),new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,uniforms:{time:{value:0}},vertexShader:'varying vec2 v;void main(){v=uv-.5;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec2 v;uniform float time;void main(){float r=length(v);float a=atan(v.y,v.x);float s=.5+.5*sin(r*65.-time*3.+a*4.);gl_FragColor=vec4(mix(vec3(.10,.35,.36),vec3(.7,.66,.9),s),.30*smoothstep(.5,.36,r));}'}));disc.scale.y=1.25;this.gate.add(disc);this.disc=disc;this.root.visible=false;
 }
 preview(rescue=false){this.time=rescue===true?19:rescue==='cruise'?8:0;this.previewEnd=VISIT_DURATION;this.siteCycle=null;this.forcedWater=!!rescue;this.forcedRescue=rescue===true;this.chooseSite(0)}
 get performanceActive(){return this.previewEnd!==undefined&&this.time<this.previewEnd}
 seek(age){this.ensure();this.time=Math.floor(Math.max(0,this.time)/VISIT_PERIOD)*VISIT_PERIOD+Math.max(0,Math.min(31.9,age));this.update(0)}
 ensure(){if(this.time<0||this.time%VISIT_PERIOD>=VISIT_DURATION)this.preview(false)}
 chooseSite(cycle){
  this.rescue=cycle===0&&this.forcedRescue!==null?this.forcedRescue:cycle%3===1;this.scene.updateMatrixWorld(true);let chosen;
  for(let attempt=0;attempt<24;attempt++){
   const u=((cycle*17+attempt*7)*.61803398875+.31)%1,z=2*u-1,a=(cycle*2.4+attempt*2.39996+.7),n=new THREE.Vector3(Math.cos(a)*Math.sqrt(1-z*z),Math.sin(a)*Math.sqrt(1-z*z),z),world=n.clone().applyQuaternion(this.globe.quaternion),ray=new THREE.Raycaster(world.clone().multiplyScalar(80),world.clone().negate(),0,160),hit=ray.intersectObjects(this.surfaces,false)[0];
   if(!hit)continue;const water=hit.object===this.ocean;if((this.rescue||cycle===0&&this.forcedWater)&&!water)continue;
   this.root.position.copy(n.clone().multiplyScalar(18));this.root.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),n);this.scene.updateMatrixWorld(true);const heights=[];
   for(let j=0;j<=12;j++){const p=new THREE.Vector3(.7*Math.sin(j/12*Math.PI*2),0,j/12*4.3),direction=this.root.localToWorld(p).normalize(),r=new THREE.Raycaster(direction.clone().multiplyScalar(80),direction.clone().negate(),0,160),h=r.intersectObjects(this.surfaces,false)[0];if(h)heights.push(this.root.worldToLocal(h.point.clone()).y)}
   if(!heights.length||Math.max(...heights)-Math.min(...heights)>1.6)continue;
   chosen={n,water,level:Math.max(...heights)+.22+(water?this.rescue?1.0:this.marine.amplitude+.25:0)};break;
  }
  if(!chosen){chosen={n:new THREE.Vector3(0,-1,0),water:true,level:1.25};this.root.position.set(0,-18,0);this.root.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),chosen.n)}
  this.water=chosen.water;this.level=chosen.level;this.normal=chosen.n;this.siteCycle=cycle;
 }
 update(dt){
  this.time+=dt;const age=((this.time%VISIT_PERIOD)+VISIT_PERIOD)%VISIT_PERIOD,cycle=Math.floor(this.time/VISIT_PERIOD);this.root.visible=this.time>=0&&age<VISIT_DURATION;
  if(!this.root.visible){document.body.dataset.mageVisit=JSON.stringify({visible:false,stage:'遠方旅行',nextVisit:this.time<0?-this.time:VISIT_PERIOD-age});return}
  if(this.siteCycle!==cycle)this.chooseSite(cycle);
  const seaNormal=new THREE.Vector3(...visitFallNormal(this.level)).applyQuaternion(this.root.quaternion),sea=this.marine.height(seaNormal),p=visitPose(age,this.rescue,this.level,sea);this.actor.visible=p.visible;this.actor.position.fromArray(p.position||[0,0,0]);this.actor.rotation.set(p.fall?.25*Math.sin(age*3):0,p.yaw||0,p.fall?.25*Math.sin(age*7):0);
  const suspension=this.water&&!p.fall?weaverLift(age-3,this.rescue?18:25):null,flightHeight=suspension?.height||0;this.actor.position.y+=flightHeight;if(suspension){this.actor.rotation.x=suspension.pitch;this.actor.rotation.z=suspension.roll}
  this.gate.position.fromArray(p.gateCenter||[0,0,0]);if(this.water&&!this.rescue&&age>=21)this.gate.position.y+=flightHeight;this.gate.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1),new THREE.Vector3(...(p.gateNormal||[0,0,1])));this.gate.scale.setScalar(.55*p.open);this.gate.visible=p.open>.001;this.disc.material.uniforms.time.value=this.time;
  this.scene.updateMatrixWorld(true);const normal=new THREE.Vector3(...(p.gateNormal||[0,0,1])).transformDirection(this.root.matrixWorld),point=this.root.localToWorld(new THREE.Vector3(...(p.gateCenter||[0,0,0])));this.plane.setFromNormalAndCoplanarPoint(normal,point);this.actor.traverse(n=>{if(n.isMesh)n.material.clippingPlanes=p.clipping?[this.plane]:[]});
  if(suspension)poseSuspendedWeaver(this.actor,this.time,suspension.body);else setGaitPose(this.actor,p.fall?0:this.time*4,false);updateSuspendedCape(this.cloth,this.time,suspension?.tail||0);
  document.body.dataset.mageVisit=JSON.stringify({visible:p.visible,stage:suspension&&suspension.body>.05?'披風吊掛巡遊':p.stage,age,water:this.water,rescue:this.rescue,carpet:false,suspension,flightHeight,capeAttached:true,clothStage:suspension?.stage||'披風自然垂落',localPosition:this.actor.position.toArray(),gateNormal:p.gateNormal,gateCenter:this.gate.position.toArray(),gateOpen:p.open,clipping:p.clipping,normal:this.normal.toArray(),level:this.level});
 }
 cameraPose(){const p=this.actor.position.clone();p.y=Math.max(p.y,this.level-.1);const target=this.root.localToWorld(p.clone().add(new THREE.Vector3(0,.8,0))),position=this.root.localToWorld(p.clone().add(new THREE.Vector3(4,3.5,6)));return {target,position,up:new THREE.Vector3(0,1,0).transformDirection(this.root.matrixWorld)}}
}
