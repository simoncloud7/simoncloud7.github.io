import * as THREE from 'three';
import {visitPose,visitFallNormal,VISIT_PERIOD,VISIT_DURATION} from './spacewalk.mjs?v=00deb652dc05';
import {isHeroCloth,setGaitPose,setFlightPose} from './hero-style.js?v=00deb652dc05';
import {weaverLift} from './cape-motion.mjs?v=00deb652dc05';
import {poseSuspendedWeaver,updateSuspendedCape} from './weaver-flight.js?v=00deb652dc05';
export class MageVisitSystem{
 constructor({scene,globe,surfaces,groundSurfaces=null,waterSurfaces=null,ocean,marine,cloneAsset,assets,camera}){
  Object.assign(this,{scene,globe,surfaces,groundSurfaces,ocean,marine,camera});this.waterSurfaces=new Set(waterSurfaces||[ocean]);this.groundCache=new Map();this.ray=new THREE.Raycaster();this.time=-16;this.siteCycle=null;this.forcedRescue=null;
  this.root=new THREE.Group();globe.add(this.root);this.actor=cloneAsset(assets['capy-mage'].id,.6).root;this.root.add(this.actor);this.plane=new THREE.Plane();this.cloth=[];
  this.actor.traverse(n=>{if(n.isMesh){n.material=n.material.clone();n.material.clipShadows=true;if(isHeroCloth(n.name)){n.geometry=n.geometry.clone();n.geometry.computeBoundingBox();this.cloth.push({mesh:n,base:n.geometry.attributes.position.array.slice(),center:n.geometry.boundingBox.getCenter(new THREE.Vector3()),size:n.geometry.boundingBox.getSize(new THREE.Vector3())})}}});
  this.feet=[];this.actor.traverse(n=>{if(n.isMesh&&/^leg-(-?1)$/.test(n.name))this.feet.push(n)});
  this.gate=new THREE.Group();const frame=cloneAsset(assets['wormhole-gate'].id,1).root;frame.position.sub(new THREE.Box3().setFromObject(frame).getCenter(new THREE.Vector3()));this.gate.add(frame);this.root.add(this.gate);
  const disc=new THREE.Mesh(new THREE.CircleGeometry(1.24,64),new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,uniforms:{time:{value:0}},vertexShader:'varying vec2 v;void main(){v=uv-.5;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec2 v;uniform float time;void main(){float r=length(v);float a=atan(v.y,v.x);float s=.5+.5*sin(r*65.-time*3.+a*4.);gl_FragColor=vec4(mix(vec3(.10,.35,.36),vec3(.7,.66,.9),s),.30*smoothstep(.5,.36,r));}'}));disc.scale.y=1.25;this.gate.add(disc);this.disc=disc;this.root.visible=false;
 }
 preview(rescue=false){this.time=rescue===true?19:rescue==='cruise'?8:0;this.previewEnd=VISIT_DURATION;this.siteCycle=null;this.forcedWater=!!rescue;this.forcedRescue=rescue===true;this.chooseSite(0)}
 get performanceActive(){return this.previewEnd!==undefined&&this.time<this.previewEnd}
 seek(age){this.ensure();this.time=Math.floor(Math.max(0,this.time)/VISIT_PERIOD)*VISIT_PERIOD+Math.max(0,Math.min(31.9,age));this.update(0)}
 ensure(){if(this.time<0||this.time%VISIT_PERIOD>=VISIT_DURATION)this.preview(false)}
 castGround(normal,targets=this.groundSurfaces||this.surfaces){
  for(const target of targets)target.updateWorldMatrix(true,false);const origin=this.globe.localToWorld(normal.clone().multiplyScalar(80)),center=this.globe.getWorldPosition(new THREE.Vector3());this.ray.set(origin,center.sub(origin).normalize());this.ray.far=160;return this.ray.intersectObjects(targets,false)[0]||null;
 }
 groundAt(normal){
  normal=normal.clone().normalize();const key=normal.toArray().map(v=>v.toFixed(5)).join(':');if(this.groundCache.has(key))return this.groundCache.get(key);
  const hit=this.castGround(normal);if(!hit)return null;const inverse=this.globe.matrixWorld.clone().invert(),worldNormal=hit.face.normal.clone().applyMatrix3(new THREE.Matrix3().getNormalMatrix(hit.object.matrixWorld)).normalize(),outward=normal.clone().transformDirection(this.globe.matrixWorld);if(worldNormal.dot(outward)<0)worldNormal.negate();
  const sample={point:this.globe.worldToLocal(hit.point.clone()),normal:worldNormal.applyMatrix3(new THREE.Matrix3().getNormalMatrix(inverse)).normalize(),water:this.waterSurfaces.has(hit.object)};this.groundCache.set(key,sample);return sample;
 }
 groundAtLocal(x,z){return this.groundAt(this.globe.worldToLocal(this.root.localToWorld(new THREE.Vector3(x,0,z))).normalize())}
 footMinimum(mesh,point,normal){
  const positions=mesh.geometry.attributes.position,p=new THREE.Vector3();let gap=Infinity,lowest=new THREE.Vector3();for(let i=0;i<positions.count;i++){p.fromBufferAttribute(positions,i).applyMatrix4(mesh.matrixWorld);const d=p.clone().sub(point).dot(normal);if(d<gap){gap=d;lowest.copy(p)}}return {gap,point:lowest};
 }
 groundWalker(p){
  const surface=this.groundAtLocal(p.position[0],p.position[2]);if(!surface||surface.water||!this.feet.length)return;
  const point=this.globe.localToWorld(surface.point.clone()),normal=surface.normal.clone().transformDirection(this.globe.matrixWorld),forward=new THREE.Vector3(Math.sin(p.yaw||0),0,Math.cos(p.yaw||0)).transformDirection(this.root.matrixWorld).projectOnPlane(normal).normalize(),right=new THREE.Vector3().crossVectors(normal,forward).normalize(),worldQ=new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(right,normal,forward)),parentQ=this.root.getWorldQuaternion(new THREE.Quaternion());
  this.actor.position.copy(this.root.worldToLocal(point.clone()));this.actor.quaternion.copy(parentQ.invert().multiply(worldQ));this.actor.updateWorldMatrix(true,true);const supports=[];let lift=-Infinity;
  for(const foot of this.feet){const lowest=this.footMinimum(foot,point,normal).point,sample=this.groundAt(this.globe.worldToLocal(lowest.clone()).normalize())||surface,supportPoint=this.globe.localToWorld(sample.point.clone()),supportNormal=sample.normal.clone().transformDirection(this.globe.matrixWorld),gap=this.footMinimum(foot,supportPoint,supportNormal).gap;lift=Math.max(lift,-gap/Math.max(.2,normal.dot(supportNormal)));supports.push({foot,point:supportPoint,normal:supportNormal})}
  this.actor.position.addScaledVector(normal.clone().transformDirection(this.root.matrixWorld.clone().invert()),lift);this.actor.updateWorldMatrix(true,true);this.footSupports=supports;this.footClearances=supports.map(s=>this.footMinimum(s.foot,s.point,s.normal).gap);this.footClearance=Math.min(...this.footClearances);
 }
 chooseSite(cycle){
  this.rescue=cycle===0&&this.forcedRescue!==null?this.forcedRescue:cycle%3===1;this.siteUnavailable=false;this.scene.updateMatrixWorld(true);let chosen;
  for(let attempt=0;attempt<64;attempt++){
   const u=((cycle*17+attempt*7)*.61803398875+.31)%1,z=2*u-1,a=(cycle*2.4+attempt*2.39996+.7),n=new THREE.Vector3(Math.cos(a)*Math.sqrt(1-z*z),Math.sin(a)*Math.sqrt(1-z*z),z),hit=this.castGround(n);
   if(!hit||this.marine.visitSiteClear?.(n)===false)continue;const water=this.waterSurfaces.has(hit.object);if(this.rescue&&!water||cycle===0&&this.forcedWater!==undefined&&water!==this.forcedWater)continue;
   const obstruction=this.castGround(n,this.surfaces);if(obstruction&&obstruction.distance+.15<hit.distance)continue;
   this.root.position.copy(n.clone().multiplyScalar(18));this.root.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),n);this.scene.updateMatrixWorld(true);this.groundCache.clear();const heights=[],centerHeight=this.root.worldToLocal(hit.point.clone()).y;let blocked=false;
   for(let j=0;j<=18;j++){const sample=this.groundAtLocal(.7*Math.sin(j/18*Math.PI*2),j/18*5.6);if(!sample||!water&&sample.water||this.marine.visitSiteClear?.(sample.point.clone().normalize())===false){blocked=true;break}const local=this.root.worldToLocal(this.globe.localToWorld(sample.point.clone()));heights.push(local.y);if(!water){const direction=sample.point.clone().normalize(),obstacle=this.castGround(direction,this.surfaces),ground=this.castGround(direction);if(obstacle&&ground&&obstacle.distance+.15<ground.distance){blocked=true;break}}}
   if(blocked||!heights.length||Math.max(...heights)-Math.min(...heights)>1.6)continue;
   chosen={n,water,level:water?Math.max(...heights)+.22+(this.rescue?1.0:this.marine.amplitude+.25):centerHeight};break;
  }
  if(!chosen){this.siteUnavailable=true;this.siteCycle=cycle;this.root.visible=false;return false}
  this.water=chosen.water;this.level=chosen.level;this.normal=chosen.n;this.siteCycle=cycle;
 }
 update(dt){
  this.time+=dt;const age=((this.time%VISIT_PERIOD)+VISIT_PERIOD)%VISIT_PERIOD,cycle=Math.floor(this.time/VISIT_PERIOD);this.root.visible=this.time>=0&&age<VISIT_DURATION;
  if(!this.root.visible){document.body.dataset.mageVisit=JSON.stringify({visible:false,stage:'遠方旅行',nextVisit:this.time<0?-this.time:VISIT_PERIOD-age});return}
  if(this.siteCycle!==cycle)this.chooseSite(cycle);
  if(this.siteUnavailable){this.root.visible=false;document.body.dataset.mageVisit=JSON.stringify({visible:false,stage:'遠方旅行',nextVisit:VISIT_PERIOD-age});return}
  const seaNormal=new THREE.Vector3(...visitFallNormal(this.level)).applyQuaternion(this.root.quaternion),sea=this.marine.height(seaNormal),p=visitPose(age,this.rescue,this.level,sea);this.actor.visible=p.visible;this.actor.position.fromArray(p.position||[0,0,0]);this.actor.rotation.set(p.fall?.25*Math.sin(age*3):0,p.yaw||0,p.fall?.25*Math.sin(age*7):0);
  const suspension=this.water&&!p.fall?weaverLift(age-3,this.rescue?18:25):null,flightHeight=suspension?.height||0;this.actor.position.y+=flightHeight;if(suspension){this.actor.rotation.x=suspension.pitch;this.actor.rotation.z=suspension.roll}
  if(suspension)poseSuspendedWeaver(this.actor,this.time,suspension.body);else{if(!this.water)setFlightPose(this.actor,1);setGaitPose(this.actor,p.fall?0:this.time*4,false)}updateSuspendedCape(this.cloth,this.time,suspension?.tail||0);this.footClearance=null;this.footClearances=null;
  if(!this.water)this.groundWalker(p);
  this.gate.position.fromArray(p.gateCenter||[0,0,0]);if(this.water&&!this.rescue&&age>=21)this.gate.position.y+=flightHeight;this.gate.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1),new THREE.Vector3(...(p.gateNormal||[0,0,1])));this.gate.scale.setScalar(.55*p.open);this.gate.visible=p.open>.001;this.disc.material.uniforms.time.value=this.time;
  if(!this.water&&p.gateCenter){const ground=this.groundAtLocal(p.gateCenter[0],p.gateCenter[2]);if(ground)this.gate.position.copy(this.root.worldToLocal(this.globe.localToWorld(ground.point.clone()))).add(new THREE.Vector3(0,p.gateCenter[1]-this.level,0))}
  this.scene.updateMatrixWorld(true);const normal=new THREE.Vector3(...(p.gateNormal||[0,0,1])).transformDirection(this.root.matrixWorld),point=this.gate.getWorldPosition(new THREE.Vector3());this.plane.setFromNormalAndCoplanarPoint(normal,point);this.actor.traverse(n=>{if(n.isMesh)n.material.clippingPlanes=p.clipping?[this.plane]:[]});
  document.body.dataset.mageVisit=JSON.stringify({visible:p.visible,stage:suspension&&suspension.body>.05?'披風吊掛巡遊':p.stage,age,water:this.water,rescue:this.rescue,carpet:false,suspension,flightHeight,footClearance:this.footClearance,footClearances:this.footClearances,capeAttached:true,clothStage:suspension?.stage||'披風自然垂落',localPosition:this.actor.position.toArray(),gateNormal:p.gateNormal,gateCenter:this.gate.position.toArray(),gateOpen:p.open,clipping:p.clipping,normal:this.normal.toArray(),level:this.level});
 }
 cameraPose(){const p=this.actor.position.clone();if(this.water)p.y=Math.max(p.y,this.level-.1);const target=this.root.localToWorld(p.clone().add(new THREE.Vector3(0,.8,0))),position=this.root.localToWorld(p.clone().add(new THREE.Vector3(4,3.5,6)));return {target,position,up:new THREE.Vector3(0,1,0).transformDirection(this.root.matrixWorld)}}
}
