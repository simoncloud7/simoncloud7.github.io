// Dimensionless Newtonian Hohmann geometry, played on a separate display clock.
// Inward decay is an accelerated story, not an atmosphere or GR force model.
export const PLANET_KM=6371,REBOOST_SECONDS=16,SYNC_SECONDS=4;
// Authored story phases, not universal physical recovery/atmosphere limits.
export const REENTRY_STORY_KM=350,HERO_APPROACH_SECONDS=2,HERO_DEPART_SECONDS=3,HERO_RESCUE_SECONDS=HERO_APPROACH_SECONDS+REBOOST_SECONDS+HERO_DEPART_SECONDS;
const clamp=x=>Math.max(0,Math.min(1,x));
export function inwardDecay(lossKm,age,dt,rho){
 const limit=(rho-1)*PLANET_KM,remaining=Math.max(0,limit-lossKm),growth=.085*30*Math.exp(Math.min(age/30,700)),increment=growth*Math.expm1(Math.min(dt/30,700));
 return {lossKm:Math.min(limit,lossKm+increment),age:age+dt,crashed:increment>=remaining,secondsToImpact:30*Math.log1p(Math.max(0,remaining-increment)/(growth*Math.exp(Math.min(dt/30,700))))};
}
export function reboostPlan(from,to,mu=1){
 if(!(from>0&&to>=from&&mu>0))throw RangeError('Outward transfer requires positive ordered radii');
 const a=(from+to)/2,e=(to-from)/(to+from),v1=Math.sqrt(mu/from),v2=Math.sqrt(mu/to);
 return {from,to,a,e,mu,deltaV1:v1*(Math.sqrt(2*to/(from+to))-1),deltaV2:v2*(1-Math.sqrt(2*from/(from+to))),halfPeriod:Math.PI*Math.sqrt(a**3/mu)};
}
export function reboostPose(plan,seconds){
 const u=clamp(seconds/REBOOST_SECONDS),M=Math.PI*u;let E=M;
 for(let i=0;i<12;i++)E-=(E-plan.e*Math.sin(E)-M)/(1-plan.e*Math.cos(E));
 const x=plan.a*(Math.cos(E)-plan.e),y=plan.a*Math.sqrt(1-plan.e**2)*Math.sin(E),radius=Math.hypot(x,y),v=[-Math.sin(E),Math.sqrt(1-plan.e**2)*Math.cos(E)],speed=Math.hypot(...v);
 return {progress:u,radius,angle:Math.atan2(Math.max(0,y),x),velocity:v.map(n=>n/speed),phase:u<.1?'boost':u<.9?'coast':u<1?'circularize':'complete',firing:u<.1||u>=.9&&u<1};
}
