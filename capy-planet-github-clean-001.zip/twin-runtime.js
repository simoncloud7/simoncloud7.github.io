import * as THREE from 'three';
import {twinStory,TWIN_DURATION,TWIN_INTRO_SECONDS,twinCameraBlend,twinReunionBlend} from './twin-story.mjs?v=cf9ebfe6af50';
import {comparisonCamera} from './comparison-view.js?v=cf9ebfe6af50';
import {ExperimentStage} from './experiment-stage.js?v=cf9ebfe6af50';
import {LANDING_X} from './flight.mjs?v=cf9ebfe6af50';
import {visibleExperimentBounds,visibleExperimentPoints} from './experiment-captions.js?v=cf9ebfe6af50';
const up=new THREE.Vector3(0,1,0),clamp=x=>Math.max(0,Math.min(1,x)),smooth=x=>{x=clamp(x);return x*x*(3-2*x)};
const boxPoints=root=>{const box=visibleExperimentBounds(root),points=[];for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z])points.push(new THREE.Vector3(x,y,z));return points};
function reunionCamera(points,direction,up,aspect){
 const target=new THREE.Box3().setFromPoints(points).getCenter(new THREE.Vector3()),z=direction.clone().normalize(),x=new THREE.Vector3().crossVectors(up,z).normalize(),y=new THREE.Vector3().crossVectors(z,x),tan=Math.tan(THREE.MathUtils.degToRad(43/2));let distance=0;
 for(const p of points){const d=p.clone().sub(target);distance=Math.max(distance,d.dot(z)+Math.max(Math.abs(d.dot(y))/tan,Math.abs(d.dot(x))/(tan*aspect))*1.15)}
 return {position:target.clone().addScaledVector(z,distance+.45),target,up};
}
function reunionCaptionPoints(root){
 const points=[];root.traverseVisible(n=>{if(!n.isMesh)return;if(!n.geometry.boundingBox)n.geometry.computeBoundingBox();const box=n.geometry.boundingBox.clone().expandByScalar(.06);for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z])points.push(new THREE.Vector3(x,y,z).applyMatrix4(n.matrixWorld))});return points;
}
export class TwinActor{
 constructor(root,elder){this.root=root;this.elder=elder;this.body=root.getObjectByName('twin-body-pivot');this.head=root.getObjectByName('head-pivot');this.arms=[-1,1].map(s=>root.getObjectByName('arm-'+s));this.legs=[-1,1].map(s=>root.getObjectByName('leg-'+s));this.features=[];root.traverse(n=>{if(n.isMesh){n.material=n.material.clone();if(/^elder-(beard|moustache|eyebrow|cane)/.test(n.name))this.features.push(n)}});}
 pose(age,time,{walking=false,seated=false,joy=false}={}){const old=this.elder?clamp((age-45)/20):0,wave=Math.sin(time*(old?3.4:7));this.body.rotation.x=.22*old;this.body.position.y=.65+.006*Math.sin(time*3);if(joy)this.root.position.y+=.25*Math.max(0,Math.sin(time*7));for(let i=0;i<2;i++){const side=i?1:-1;this.legs[i].rotation.x=seated?-1.25:walking?side*wave*(old?.12:.3):.035*wave*side;this.arms[i].rotation.x=seated?-.65:old&&i===1?-.5:walking?-side*wave*.30:joy?-1.2+.3*wave:-.15+.08*wave*side;this.arms[i].scale.y=1-(i?old*.2:0)}if(this.head)this.head.rotation.x=.04*old+.025*Math.sin(time*2);for(const n of this.features){const a=n.name.startsWith('elder-cane')?clamp((old-.25)/.75):old;n.visible=a>.01;n.material.transparent=a<.99;n.material.opacity=a;n.material.depthWrite=a>.9}}
}
export class TwinExperiment{
 constructor({scene,globe,flight,cloneAsset,assets,stage,fable,onCaptions=()=>{},onComplete=()=>{}}){
  Object.assign(this,{scene,globe,flight,fable,onCaptions,onComplete});this.active=false;this.time=0;
  // Share the actual launch-site frame: H is the meeting point, the other pad is the berth.
  this.site=new THREE.Group();flight.site.add(this.site);this.site.visible=false;
  this.home=new TwinActor(cloneAsset(assets.elder.id,.9).root,true);this.traveler=new TwinActor(cloneAsset(assets.young.id,.9).root,false);this.travelerOld=new TwinActor(cloneAsset(assets.elder.id,.9).root,true);this.site.add(this.home.root,this.traveler.root,this.travelerOld.root);
  this.meeting=new THREE.Vector3(LANDING_X,.26,.45);this.waiting=this.meeting.clone().add(new THREE.Vector3(.65,0,0));this.door=new THREE.Vector3(-.85,.248,1.1);
  const bounds=new THREE.Box3().setFromObject(flight.spacecraft),bottom= bounds.min.y-flight.spacecraft.position.y;
  this.start=new THREE.Vector3(0,.248-bottom,.55);this.far=this.start.clone().add(new THREE.Vector3(36,20,-7));this.cabin=new THREE.Vector3(0,.54,.48);
  this.audience=new ExperimentStage({...stage,clearPeople:true,reservedBounds:[8,6,20,15],dataKey:'twinStage'});
  this.airlocks=[...flight.spacecraft.children.filter(n=>n.geometry&&Math.abs(n.position.y-1.3)<.02&&Math.abs(n.position.z-.75)<.02),flight.spacewalk?.hatch].filter(Boolean).map(n=>[n,n.visible]);
 }
 begin(beta,distance){
  this.beta=beta;this.distance=distance;this.time=0;this.introTime=0;this.motionTime=0;this.active=true;this.completeSent=false;this.site.visible=true;this.frames=null;this.captionPhase=null;this.captionBounds=null;
  this.flight.setTwinBerth(true);this.fable?.setPerformance(true,false);this.audience.finishRelease();this.audience.begin();
  for(const [n] of this.airlocks)n.visible=false;this.update(0);
 }
 stop(){
  if(!this.active)return;this.active=false;this.site.visible=false;this.onCaptions(null);this.audience.stop();this.fable?.setPerformance(false);this.flight.setTwinMission(null);this.flight.setTwinBerth(false);
  for(const [n,visible] of this.airlocks)n.visible=visible;document.body.dataset.twinStory=JSON.stringify({active:false});
 }
 seek(t){this.introTime=TWIN_INTRO_SECONDS;this.time=Math.max(0,Math.min(TWIN_DURATION,t));this.motionTime=this.time;this.completeSent=false;this.update(0)}
 get travelerRoot(){return this.traveler.root.visible?this.traveler.root:this.travelerOld.root}
 update(dt,camera){
  if(!this.active){this.audience.update(dt);return}
  const introStep=Math.min(dt,TWIN_INTRO_SECONDS-this.introTime);this.introTime+=introStep;this.time=Math.min(TWIN_DURATION,this.time+dt-introStep);this.motionTime+=dt;
  const s=twinStory(this.time,this.beta,this.distance),intro=this.introTime<TWIN_INTRO_SECONDS;this.state=s;this.site.updateWorldMatrix(true,false);const siteQ=this.site.getWorldQuaternion(new THREE.Quaternion());
  const local=this.start.clone().add(new THREE.Vector3(36*s.route,10*s.lift+10*s.route,-7*s.route)),world=this.site.localToWorld(local.clone());
  const turn=this.time<17?0:this.time<19?Math.PI*smooth((this.time-17)/2):Math.PI,heading=(Math.atan2(1,-.2)+turn)*s.lift;
  const localQ=new THREE.Quaternion().setFromAxisAngle(up,heading).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1,0,0),(s.returning?.12:-.12)*s.lift)),q=siteQ.clone().multiply(localQ);
  this.flight.setTwinMission({position:world,quaternion:q,progress:s.progress,returning:s.returning});
  this.home.root.position.copy(this.meeting).add(new THREE.Vector3(-.65,0,0));this.home.root.rotation.y=Math.PI/2;this.home.pose(s.homeAge,this.motionTime);
  const cabin=this.cabin.clone().multiply(this.flight.spacecraft.scale).applyQuaternion(localQ).add(local),boarding=this.time<4,walking=!intro&&!s.complete&&!s.aboard;
  if(s.aboard){this.traveler.root.position.copy(cabin);this.traveler.root.quaternion.copy(localQ);this.traveler.root.scale.setScalar(.22);this.traveler.pose(s.travelerAge,this.motionTime,{seated:true})}
  else{
   // Walk across the open deck; only the final step enters the cabin.
   const u=boarding?s.boarding:1-s.disembark,entry=smooth((u-.8)/.2),pos=this.waiting.clone().lerp(this.door,clamp(u/.8)).lerp(cabin,entry);
   this.traveler.root.position.copy(pos);const yaw=boarding?Math.PI/2:-Math.PI/2;
   this.traveler.root.quaternion.setFromAxisAngle(up,yaw*(1-entry));this.traveler.root.scale.setScalar(THREE.MathUtils.lerp(.9,.22,entry));this.traveler.pose(s.travelerAge,this.motionTime,{walking,joy:s.complete&&s.travelerAge<45});
  }
  if(camera){const eye=this.site.worldToLocal(camera.position.clone());for(const actor of [this.home,...(intro||s.complete?[this.traveler]:[])]){const d=eye.clone().sub(actor.root.position);actor.root.rotation.y=Math.atan2(d.x,d.z)}}
  this.travelerOld.root.position.copy(this.traveler.root.position);this.travelerOld.root.quaternion.copy(this.traveler.root.quaternion);this.travelerOld.root.scale.copy(this.traveler.root.scale);this.travelerOld.pose(s.travelerAge,this.motionTime,{walking,seated:s.aboard});this.traveler.root.visible=s.travelerAge<45;this.travelerOld.root.visible=s.travelerAge>=45;
  this.site.updateWorldMatrix(true,true);const roots=[this.home.root,this.travelerRoot,this.flight.spacecraft],targets=roots.map(root=>visibleExperimentBounds(root).getCenter(new THREE.Vector3()));this.audience.update(dt,{camera,targets,subjects:roots});
  const captionPhase=intro?'intro':s.complete?'reunion':null;if(camera&&captionPhase!==this.captionPhase){
   this.captionPhase=captionPhase;this.captionBounds=captionPhase?new Map(roots.map(root=>{
    const points=captionPhase==='reunion'&&root!==this.flight.spacecraft?reunionCaptionPoints(root):visibleExperimentPoints(root,.35);
    if(captionPhase==='reunion'&&root===this.travelerRoot&&s.travelerAge<45){const vertical=up.clone().applyQuaternion(siteQ),hop=this.traveler.root.position.y-this.waiting.y;for(const p of points)p.addScaledVector(vertical,-hop);return [root,[...points,...points.map(p=>p.clone().addScaledVector(vertical,.25))]]}
    return [root,points];
   })):null;
  }
  this.onCaptions({subjects:roots,stable:!!captionPhase,bounds:this.captionBounds,items:[{root:this.home.root,anchor:targets[0],side:'below',title:'留在星球的卡皮',value:s.homeAge.toFixed(1)+' 歲 · +'+(s.earthYears*s.progress).toFixed(2)+' 年',color:'#a4d9dd'},{root:s.aboard?this.flight.spacecraft:this.travelerRoot,anchor:targets[1],side:'above',title:'搭船的卡皮',value:s.travelerAge.toFixed(1)+' 歲 · +'+(s.travelerYears*s.progress).toFixed(2)+' 年',color:'#f3cd88'}]});
  const phase=intro?'H 停機坪 · 同為 20 歲':s.phase;document.querySelector('#twin-story-phase').textContent=phase;document.querySelector('#twin-home-age').textContent=s.homeAge.toFixed(1);document.querySelector('#twin-traveler-age').textContent=s.travelerAge.toFixed(1);document.querySelector('#twin-story-progress').value=String(this.time);document.querySelector('#trip-dot').setAttribute('cx',String(30+195*(s.progress<.5?s.progress*2:(1-s.progress)*2)));document.querySelector('#trip-dot').setAttribute('cy',String(110-92*s.progress));document.querySelector('#trip-status').textContent=phase+' · 星球 '+(s.earthYears*s.progress).toFixed(2)+' 年 / 旅人 '+(s.travelerYears*s.progress).toFixed(2)+' 年';
  document.body.dataset.twinStory=JSON.stringify({active:true,...s,phase,intro,introTime:this.introTime,animationTime:this.motionTime,homeBodyLean:this.home.body.rotation.x,travelerY:this.traveler.root.position.y,beta:this.beta,distanceLy:this.distance,ship:world.toArray(),homeVisible:this.home.root.visible,travelerAboard:s.aboard,meeting:'H landing pad',berth:'vacated rocket launch pad',cameraBlend:twinCameraBlend(this.time)});
  if(s.complete&&!this.completeSent){this.completeSent=true;this.onComplete()}
 }
 cameraPose(aspect,reunion=false){
  this.site.updateWorldMatrix(true,true);const siteQ=this.site.getWorldQuaternion(new THREE.Quaternion()),direction=new THREE.Vector3(.15,.8,1.25).applyQuaternion(siteQ).normalize(),upWorld=up.clone().applyQuaternion(siteQ);
  if(!this.frames||this.frames.aspect!==aspect){
   const near=[];for(const x of [LANDING_X-1.6,LANDING_X+1.6])for(const y of [.2,3])for(const z of [-.4,1.3])near.push(this.site.localToWorld(new THREE.Vector3(x,y,z)));
   const wide=[];for(const x of [-18,18])for(const y of [-18,18])for(const z of [-18,18])wide.push(this.globe.localToWorld(new THREE.Vector3(x,y,z)));for(const x of [-3,3])for(const y of [-1,3])for(const z of [-3,3])wide.push(this.site.localToWorld(this.far.clone().add(new THREE.Vector3(x,y,z))));
   const close=[];for(const x of [LANDING_X-1.25,LANDING_X+1.25])for(const y of [.15,2.45])for(const z of [-.4,1.3])close.push(this.site.localToWorld(new THREE.Vector3(x,y,z)));
   this.frames={aspect,near:comparisonCamera(near,direction,upWorld,aspect),wide:comparisonCamera(wide,direction,upWorld,aspect),reunion:reunionCamera(close,direction,upWorld,aspect)};
  }
  const blend=reunion?0:twinCameraBlend(this.time),{near,wide}=this.frames,target=near.target.clone().lerp(wide.target,blend),position=near.position.clone().lerp(wide.position,blend);
  const closeBlend=reunion?1:twinReunionBlend(this.time);target.lerp(this.frames.reunion.target,closeBlend);position.lerp(this.frames.reunion.position,closeBlend);
  // During zoom transitions keep the real moving ship and both twins inside the frame.
  const roots=[this.home.root,this.travelerRoot];
  const points=roots.flatMap(root=>closeBlend>0?visibleExperimentPoints(root):boxPoints(root)),z=position.clone().sub(target).normalize(),x=new THREE.Vector3().crossVectors(upWorld,z).normalize(),y=new THREE.Vector3().crossVectors(z,x),tan=Math.tan(THREE.MathUtils.degToRad(43/2));let distance=position.distanceTo(target);
  const required=p=>{const d=p.clone().sub(target);return d.dot(z)+Math.max(Math.abs(d.dot(y))/tan,Math.abs(d.dot(x))/(tan*aspect))*1.16+.8};
  for(const p of points)distance=Math.max(distance,required(p));
  if(!reunion&&closeBlend<1){const shipDistance=Math.max(...boxPoints(this.flight.spacecraft).map(required));distance=Math.max(distance,THREE.MathUtils.lerp(distance,shipDistance,smooth(this.time/2)*(1-closeBlend)))}
  return {position:target.clone().addScaledVector(z,distance),target,up:upWorld};
 }
}
