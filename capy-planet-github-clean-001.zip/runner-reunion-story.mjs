export const RUNNER_REUNION_SPEED=.999;
export const RUNNER_REUNION_YEARS=60;
export const RUNNER_REUNION_DURATION=42;
export const clamp=x=>Math.max(0,Math.min(1,x));
export const ease=x=>{x=clamp(x);return x*x*(3-2*x)};

// An authored condensed journey, compared at the same surface radius. The
// common static gravity factor cancels. Turns and acceleration are omitted;
// the visible gait/road speed is staging, not kilometres per display second.
export function runnerReunionState(seconds){
 const time=Math.max(0,Math.min(RUNNER_REUNION_DURATION,seconds));
 const progress=ease((time-5)/22),cityYears=RUNNER_REUNION_YEARS*progress;
 const runnerYears=cityYears*Math.sqrt(1-RUNNER_REUNION_SPEED**2);
 const phase=time<5?'greeting':time<8?'depart':time<24?'rush':time<27?'brake':time<29?'settle':time<38?'reunion':'farewell';
 const names={greeting:'出發前 · 我們都是 20 歲',depart:'出發 · 城市疾跑',rush:'0.999 c · 街坊的歲月流逝',brake:'回到熟悉的街角',settle:'停步 · 收起電光',reunion:'老朋友，我回來了',farewell:'道別 · 城市恢復日常'};
 return {time,phase,phaseName:names[phase],beta:RUNNER_REUNION_SPEED,progress,cityYears,runnerYears,cityAge:20+cityYears,runnerAge:20+runnerYears,worldFrozen:phase==='rush',running:['depart','rush','brake'].includes(phase),afterimageStrength:phase==='rush'?1:phase==='depart'?ease((time-6)/2):phase==='brake'?1-ease((time-24)/2):0,wideBlend:ease((time-5)/3)*(1-ease((time-24)/5)),outro:ease((time-38)/4),complete:time>=RUNNER_REUNION_DURATION};
}
