import * as THREE from 'three';
import {BASE_Y,LANDING_X,launchPose} from './flight.mjs?v=5ca5871c34bf';
const Y=new THREE.Vector3(0,1,0),BACK=new THREE.Vector3(12,9,24).normalize(),RIGHT=new THREE.Vector3().crossVectors(Y,BACK).normalize(),SCREEN_UP=new THREE.Vector3().crossVectors(BACK,RIGHT),BASE_DISTANCE=Math.hypot(12,9,24);
function localBounds(root){
 root.updateWorldMatrix(true,true);const inverse=root.matrixWorld.clone().invert(),box=new THREE.Box3(),scratch=new THREE.Box3(),matrix=new THREE.Matrix4();
 root.traverse(mesh=>{if(!mesh.isMesh)return;if(!mesh.geometry.boundingBox)mesh.geometry.computeBoundingBox();matrix.multiplyMatrices(inverse,mesh.matrixWorld);box.union(scratch.copy(mesh.geometry.boundingBox).applyMatrix4(matrix))});return box.expandByScalar(.3);
}
// One site-relative direction, with continuous pullback and a usable screen band.
// Model bounds are cached once; no per-frame mesh traversal or GPU readback.
export class LaunchCamera{
 constructor({site,booster,upper,launchpad,landingPad}){
  Object.assign(this,{site,booster,upper});this.bounds=[booster,upper,launchpad,landingPad].filter(Boolean).map(root=>{const box=localBounds(root),corners=[];for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z])corners.push(new THREE.Vector3(x,y,z));return {root,corners,sphere:box.getBoundingSphere(new THREE.Sphere()),worldSphere:new THREE.Sphere(),center:new THREE.Vector3(),radius:0,visible:true}});
  this.point=new THREE.Vector3();this.delta=new THREE.Vector3();this.center=new THREE.Vector3();this.upperEnd=new THREE.Matrix4().compose(new THREE.Vector3(...launchPose(15-1e-8).upper),new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,0,1),-.25),upper?.scale||new THREE.Vector3(1,1,1));
 }
 pose({time=0,aspect=1,fov=43,zoom=Math.min(1,aspect),minY=-.38,maxY=.84}={}){
  this.site.updateWorldMatrix(true,false);const bodyHeight=this.booster.position.y+2.3*Math.cos(this.booster.rotation.z),groundContext=1-(1-THREE.MathUtils.smoothstep(maxY-minY,.7,1.2))*THREE.MathUtils.smoothstep(this.booster.position.y,BASE_Y+2,BASE_Y+8),height=THREE.MathUtils.lerp(bodyHeight+1,BASE_Y+3.3+Math.max(0,bodyHeight-(BASE_Y+2.3))*.55,groundContext),target=new THREE.Vector3(LANDING_X/2,height,0),pullback=THREE.MathUtils.smoothstep(time,3,11)*(1-THREE.MathUtils.smoothstep(time,26,33)),fy=zoom/Math.tan(THREE.MathUtils.degToRad(fov/2)),fx=fy/Math.max(.2,aspect),cy=(minY+maxY)/2;
  let distance=BASE_DISTANCE*(1+.85*pullback);this.center.set(0,2.3,0).applyEuler(this.booster.rotation).add(this.booster.position);
  for(const item of this.bounds){
   const isUpper=item.root===this.upper;if(isUpper&&time>=22)continue;item.root.updateMatrix();const matrix=isUpper&&time>=15?this.upperEnd:item.root.matrix,keep=isUpper?1-THREE.MathUtils.smoothstep(time,15,22):1;
   for(const corner of item.corners){this.point.copy(corner).applyMatrix4(matrix);if(isUpper&&keep<1)this.point.lerp(this.center,1-keep);if(item.root!==this.booster&&!isUpper&&groundContext<1)this.point.lerp(this.center,1-groundContext);this.delta.copy(this.point).sub(target);const x=this.delta.dot(RIGHT),y=this.delta.dot(SCREEN_UP),z=this.delta.dot(BACK);distance=Math.max(distance,z+Math.abs(x)*fx/.84,(fy*y+maxY*z)/(maxY-cy),(-fy*y-minY*z)/(cy-minY))}
  }
  distance+=.6;const localTarget=target.addScaledVector(SCREEN_UP,-cy*distance/fy),localPosition=localTarget.clone().addScaledVector(BACK,distance);
  return {position:this.site.localToWorld(localPosition.clone()),target:this.site.localToWorld(localTarget.clone()),up:Y.clone().transformDirection(this.site.matrixWorld),localPosition,localTarget,distance,pullback,groundContext,safeBand:[minY,maxY]};
 }
 subjects(){
  for(const item of this.bounds){item.visible=item.root.visible;item.worldSphere.copy(item.sphere).applyMatrix4(item.root.matrixWorld);item.center.copy(item.worldSphere.center);item.radius=item.worldSphere.radius}return this.bounds;
 }
}
