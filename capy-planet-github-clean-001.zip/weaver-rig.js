import * as THREE from 'three';
import {weaverHands} from './cape-motion.mjs?v=a3001c1e8f92';
const DOWN=new THREE.Vector3(0,-1,0);

// Follow the moving textile within the original shoulder's reach. No limb
// stretching or pulling lines; the same hand rig serves both scene viewers.
export function poseWeaverArms(model,motion,step=0,time=0){
 const pose=weaverHands(motion,step,time);
 for(const [name,side] of [['arm--1','left'],['arm-1','right']]){
  const arm=model.getObjectByName(name);if(!arm)continue;
  const rest=new THREE.Quaternion().setFromEuler(new THREE.Euler(...pose[side])),direction=new THREE.Vector3(...pose.targets[side]).sub(arm.position).normalize(),follow=new THREE.Quaternion().setFromUnitVectors(DOWN,direction);
  arm.quaternion.copy(rest).slerp(follow,pose.follow);arm.scale.set(1,1,1);
 }
 return pose;
}
