import * as THREE from 'three';
import {TwinActor} from './twin-runtime.js?v=41d10fd0dc43';
import {RunnerAfterimages} from './runner-afterimages.js?v=41d10fd0dc43';
import {setGaitPose} from './hero-style.js?v=41d10fd0dc43';
import {ExperimentStage} from './experiment-stage.js?v=41d10fd0dc43';
import {visibleExperimentPoints,visibleExperimentBounds} from './experiment-captions.js?v=41d10fd0dc43';
import {runnerReunionState,RUNNER_REUNION_DURATION,clamp,ease} from './runner-reunion-story.mjs?v=41d10fd0dc43';

const up=new THREE.Vector3(0,1,0),$=s=>document.querySelector(s);
const pointsForBox=box=>{const points=[];for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z])points.push(new THREE.Vector3(x,y,z));return points};

export class RunnerReunion{
 constructor({globe,cloneAsset,assets,twins,paths,frameAt,fable,stage,onCaptions=()=>{},onComplete=()=>{}}){
  Object.assign(this,{globe,frameAt,fable,onCaptions,onComplete});this.time=0;this.active=false;
  this.group=new THREE.Group();globe.add(this.group);this.group.visible=false;
  this.road=new THREE.CatmullRomCurve3(paths[0].map(([x,z])=>new THREE.Vector3(x,0,z)));this.homeU=.245;this.span=.51;
  const home=this.road.getPointAt(this.homeU),direction=this.road.getTangentAt(this.homeU),f=frameAt(home.x,home.z),x=new THREE.Vector3(direction.x,0,direction.z).applyQuaternion(f.q).normalize(),z=new THREE.Vector3().crossVectors(x,f.normal).normalize();
  this.group.position.copy(f.normal).multiplyScalar(18.25);this.group.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(x,f.normal,z));
  this.runner=new THREE.Group();this.group.add(this.runner);this.costume=cloneAsset(assets['capy-speed'].id,.85).root;this.runner.add(this.costume);
  this.afterimages=new RunnerAfterimages(this.group,this.costume,setGaitPose,{delay:.11});
  this.neighbors=Array.from({length:3},(_,i)=>{
   const actor=new TwinActor(cloneAsset(twins.elder.id,.78).root,true);this.group.add(actor.root);actor.root.position.set(-.7+i*1.42,0,2.15);actor.root.position.y=this.ground(actor.root.position.x,actor.root.position.z);
   // Clothing variation identifies the same three friends across the time cut.
   actor.root.traverse(n=>{if(n.isMesh&&/shirt|suit|clothes|tunic|jacket/.test(n.name)&&!n.name.startsWith('elder-')){n.material=n.material.clone();n.material.vertexColors=false;n.material.color.set([0x6b9a98,0xb18c72,0x9992b4][i])}});
   return actor;
  });
  this.home=new THREE.Vector3(-2.25,this.ground(-2.25,2.15),2.15);
  this.audience=new ExperimentStage({...stage,clearPeople:true,reservedBounds:[home.x-5,home.z-4,home.x+5,home.z+5],dataKey:'runnerReunionStage'});
  // Afterimages own their opacity; the story's final fade applies only to the
  // solid cast. Including the ghosts here would reset every trail to zero.
  this.opacityRecords=[];for(const root of [this.costume,...this.neighbors.map(a=>a.root)])root.traverse(n=>{if(!n.isMesh)return;const old=Array.isArray(n.material)?n.material:[n.material];n.material=old.map(m=>m.clone());if(old.length===1)n.material=n.material[0];for(const m of Array.isArray(n.material)?n.material:[n.material])this.opacityRecords.push([n,m,m.opacity,m.transparent,m.depthWrite])});
 }
 ground(x,z){return Math.sqrt(Math.max(1,18.25**2-x*x-z*z))-18.25}
 begin(){
  this.stop();this.time=0;this.active=true;this.group.visible=true;this.state=runnerReunionState(0);this.captionKey=null;this.frames=null;this.afterimages.reset();this.fable.setPerformance(true,false);this.fable.runnerStoryActive=true;this.audience.finishRelease();this.audience.begin();
  $('#runner-story-controls').hidden=false;$('#runner-story-stop').disabled=false;this.update(0);
  this.ambientControls=[...document.querySelectorAll('.story-clocks,#story-forward,#story-reset')].map(element=>[element,element.hidden]);for(const [element] of this.ambientControls)element.hidden=true;
 }
 stop(){
  if(!this.active)return;this.active=false;this.group.visible=false;this.afterimages.reset();this.onCaptions(null);this.audience.stop();this.fable.runnerStoryActive=false;this.fable.setPerformance(false);$('#runner-story-stop').disabled=true;$('#runner-story-controls').hidden=true;
  document.body.dataset.runnerReunion=JSON.stringify({active:false,restored:true,time:this.time});
  for(const [element,hidden] of this.ambientControls||[])element.hidden=hidden;this.ambientControls=[];
 }
 seek(seconds){if(!this.active)return;this.time=clamp(seconds/RUNNER_REUNION_DURATION)*RUNNER_REUNION_DURATION;this.afterimages.reset();this.seedTrail=true;this.captionKey=null;this.update(0)}
 get performanceActive(){return this.active||this.audience.releasing}
 isWorldFrozen(dt=0){return this.active&&runnerReunionState(this.time+dt).worldFrozen}
 roadPose(u,reverse=false){
  const point=this.road.getPointAt(clamp(u)),tangent=this.road.getTangentAt(clamp(u)).multiplyScalar(reverse?-1:1),f=this.frameAt(point.x,point.z),p=f.normal.clone().multiplyScalar(18.26),q=f.q.clone().multiply(new THREE.Quaternion().setFromAxisAngle(up,Math.atan2(tangent.x,tangent.z))),inverse=this.group.quaternion.clone().invert();
  return {position:p.sub(this.group.position).applyQuaternion(inverse),quaternion:inverse.multiply(q)};
 }
 motionPose(s){
  const start=this.roadPose(this.homeU);let p=this.home.clone(),q=new THREE.Quaternion(),stride=0;
  if(s.phase==='depart'){const u=ease((s.time-5)/3);p.lerp(start.position,u);q.slerp(start.quaternion,u);stride=u*14}
  else if(s.phase==='rush'){
   const cycles=(s.time-8)/16*4,cycle=Math.floor(cycles),u=cycles-cycle,leg=u<.5?ease(u*2):1-ease((u-.5)*2),reverse=u>=.5,offset=cycle===3&&reverse?.1+(this.span-.1)*leg:this.span*leg,pose=this.roadPose(this.homeU+offset,reverse);p=pose.position;q=pose.quaternion;stride=cycles*70;
  }else if(s.phase==='brake'){
   // A final short approach returns to the exact original greeting position.
   const u=ease((s.time-24)/3),approach=this.roadPose(this.homeU+.10*(1-u),true);p=approach.position.lerp(this.home,u);q=approach.quaternion.slerp(new THREE.Quaternion(),u);stride=28+u*9;
  }else if(['settle','reunion','farewell'].includes(s.phase)){q.identity();if(s.phase==='farewell')p.x-=ease((s.time-38)/4)*1.3}
  return {position:p,quaternion:q,stride};
 }
 motion(s){
  const {position:p,quaternion:q,stride}=this.motionPose(s);
  this.runner.position.copy(p);this.runner.quaternion.copy(q);this.runner.scale.setScalar(1);this.costume.visible=true;
  setGaitPose(this.costume,s.phase==='farewell'?(s.time-38)*5:stride,s.running);
  if(s.phase==='greeting'){const arm=this.costume.getObjectByName('arm--1');arm.rotation.x=-1.9;arm.rotation.z=.2+.22*Math.sin(s.time*6)}
  if(s.phase==='reunion'){this.costume.getObjectByName('arm-1').rotation.x=-1.25-.12*Math.sin(s.time*3);this.runner.position.y+=.08*Math.max(0,Math.sin((s.time-29)*4))}
  if(this.seedTrail&&s.afterimageStrength>0){this.afterimages.history=[];for(let j=24;j>=0;j--){const time=Math.max(0,s.time-j*.03),pose=this.motionPose(runnerReunionState(time));this.afterimages.history.push({time,position:pose.position,quaternion:pose.quaternion,stride:pose.stride})}}this.seedTrail=false;
  this.afterimages.update(this.runner,s.time,0,s.beta,stride,s.afterimageStrength);
  for(const [i,ghost] of this.afterimages.ghosts.entries())for(const material of ghost.materials)material.opacity=s.afterimageStrength*.46*(1-i/6);
  return stride;
 }
 update(dt,camera,satellite){
  if(!this.active){this.audience.update(dt);return}
  this.time=Math.min(RUNNER_REUNION_DURATION,this.time+dt);const s=this.state=runnerReunionState(this.time);this.motion(s);
  for(const [i,actor] of this.neighbors.entries()){
   actor.pose(s.cityAge,s.worldFrozen?8:s.time);
   for(const arm of actor.arms)arm.rotation.z=0;actor.head.rotation.y=0;
   actor.root.rotation.y=s.phase==='reunion'?-.25-.1*i:0;
   if(s.phase==='greeting'){const arm=actor.arms[0];arm.rotation.x=-1.7;arm.rotation.z=.15+.16*Math.sin(s.time*5+i)}
   if(s.phase==='reunion'){actor.arms[0].rotation.x=-.9;actor.head.rotation.y=-.22-.08*i}
  }
  for(const [n,m,opacity,transparent,depthWrite] of this.opacityRecords){const a=s.outro===0?1:1-ease((s.time-40)/2);if(n.name.startsWith('elder-')){m.opacity*=a;m.transparent=m.transparent||a<1;m.depthWrite=m.depthWrite&&a>.99}else{m.opacity=opacity*a;m.transparent=transparent||a<1;m.depthWrite=depthWrite&&a>.99}}
  this.group.updateWorldMatrix(true,true);const roots=[this.runner,...this.neighbors.map(a=>a.root)],targets=roots.map(root=>visibleExperimentBounds(root).getCenter(new THREE.Vector3()));
  this.audience.update(dt,{camera,targets,subjects:roots,satellite,freezeAudience:s.worldFrozen});
  for(const root of this.audience.faded.keys())root.traverse(n=>{if(n.isMesh)for(const m of Array.isArray(n.material)?n.material:[n.material])m.opacity=.035});
  const close=['greeting','reunion'].includes(s.phase);if(close&&this.captionKey!==s.phase){this.onCaptions(null);this.captionKey=s.phase;this.captionBounds=new Map(roots.map(root=>{const points=visibleExperimentPoints(root,.12),n=up.clone().applyQuaternion(this.group.getWorldQuaternion(new THREE.Quaternion()));return [root,[...points,...points.map(p=>p.clone().addScaledVector(n,.13))]]}))}
  if(s.outro<.5){const neighbor=this.neighbors[1].root;this.onCaptions({subjects:roots,stable:true,tracking:!close,bounds:close?this.captionBounds:null,items:[{root:this.runner,anchor:targets[0],side:'above',follow:!close,title:'卡皮電俠 · 0.999 c',value:s.runnerAge.toFixed(1)+' 歲 · 經過 '+s.runnerYears.toFixed(1)+' 年',color:'#f2c18c'},{root:neighbor,anchor:targets[2],side:'below',title:'留在城市的街坊',value:s.cityAge.toFixed(1)+' 歲 · 經過 '+s.cityYears.toFixed(1)+' 年',color:'#b8ded1'}]})}else this.onCaptions(null);
  $('#runner-story-phase').textContent=s.phaseName;$('#runner-story-progress').value=String(s.time);$('#city-age').textContent=s.cityAge.toFixed(1);$('#runner-age').textContent=s.runnerAge.toFixed(1);$('#speed-state').textContent='本次故事固定 0.999 c · 出發時同為 20 歲';
  document.body.dataset.runnerReunion=JSON.stringify({active:true,...s,neighbors:this.neighbors.map(a=>({lean:a.body.rotation.x,beard:a.features.some(n=>n.visible&&n.name.startsWith('elder-beard')),cane:a.features.some(n=>n.visible&&n.name.startsWith('elder-cane'))})),afterimages:this.afterimages.ghosts.filter(g=>g.root.visible).length,ambientAgesUnchanged:true,clockModel:'same-radius proper-time ratio sqrt(1-beta^2); condensed 60 city years; turns omitted'});
  if(s.complete){this.stop();this.onComplete()}
 }
 broadcastPose(){
  this.group.updateWorldMatrix(true,true);const roots=[this.runner,...this.neighbors.map(a=>a.root),...this.afterimages.ghosts.filter(g=>g.root.visible).map(g=>g.root)],bounds=roots.flatMap(root=>visibleExperimentPoints(root,.1)),target=new THREE.Box3().setFromPoints(bounds).getCenter(new THREE.Vector3()),q=this.group.getWorldQuaternion(new THREE.Quaternion()),normal=up.clone().applyQuaternion(q),forward=new THREE.Vector3(0,0,1).applyQuaternion(q);
  return {label:'電俠歲月重逢 · 0.999 c',group:this.group,anchor:target.clone().addScaledVector(normal,8).addScaledVector(forward,10),target,up:normal,bounds};
 }
 cameraPose(aspect){
  this.group.updateWorldMatrix(true,true);const q=this.group.getWorldQuaternion(new THREE.Quaternion()),n=up.clone().applyQuaternion(q),direction=new THREE.Vector3(0,.62,1.65).applyQuaternion(q).normalize(),s=this.state||runnerReunionState(0);
  // Fixed bounds make the greeting/reunion shot independent of waving and hops.
  if(!this.frames||this.frames.aspect!==aspect){
   const close=pointsForBox(new THREE.Box3(new THREE.Vector3(-2.95,-.6,1.45),new THREE.Vector3(2.85,2.15,2.95))).map(p=>this.group.localToWorld(p)),wide=[];
   for(let i=0;i<=32;i++){const pose=this.roadPose(this.homeU+this.span*i/32);for(const offset of [new THREE.Vector3(-.7,0,-.7),new THREE.Vector3(.7,2,.7)])wide.push(this.group.localToWorld(pose.position.clone().add(offset)))}
   const fit=points=>{const target=new THREE.Box3().setFromPoints(points).getCenter(new THREE.Vector3()),x=new THREE.Vector3().crossVectors(n,direction).normalize(),y=new THREE.Vector3().crossVectors(direction,x),tan=Math.tan(THREE.MathUtils.degToRad(43/2));let d=0;for(const p of points){const v=p.clone().sub(target);d=Math.max(d,v.dot(direction)+Math.max(Math.abs(v.dot(y))/tan,Math.abs(v.dot(x))/(tan*Math.min(aspect,1.5)))*1.3)}return {target,position:target.clone().addScaledVector(direction,d+.9)}};
   this.frames={aspect,near:fit(close),far:fit([...close,...wide])};
  }
  const {near,far}=this.frames,blend=Math.max(s.wideBlend,s.outro*.55),target=near.target.clone().lerp(far.target,blend),position=near.position.clone().lerp(far.position,blend);
  document.body.dataset.runnerReunionCamera=JSON.stringify({phase:s.phase,blend,position:position.toArray(),target:target.toArray(),stable:!s.running});return {position,target,up:n};
 }
}
