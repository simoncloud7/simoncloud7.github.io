import * as THREE from './vendor/three.module.js';

// Fit the angular bounds of the lake once for lens calibration, or on every
// exposure only when the user explicitly chooses automatic full-lake framing.
function fittedCamera(position,target,up,points,aspect){
 const camera=new THREE.PerspectiveCamera(60,aspect,.08,160);camera.position.copy(position);camera.up.copy(up);camera.lookAt(target);camera.updateMatrixWorld(true);
 const bounds=()=>{let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;const point=new THREE.Vector3();for(const p of points){point.copy(p).applyMatrix4(camera.matrixWorldInverse);if(point.z<-.1){const x=point.x/-point.z,y=point.y/-point.z;minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y)}}return {minX,maxX,minY,maxY}};
 for(let i=0;i<2;i++){const b=bounds(),direction=new THREE.Vector3((b.minX+b.maxX)/2,(b.minY+b.maxY)/2,-1).applyQuaternion(camera.quaternion);camera.lookAt(camera.position.clone().add(direction));camera.updateMatrixWorld(true)}
 const b=bounds(),tangent=Math.max(-b.minY,b.maxY,-b.minX/aspect,b.maxX/aspect);if(!(tangent>0&&Number.isFinite(tangent)))throw RangeError('Visible lake points required');
 camera.fov=THREE.MathUtils.radToDeg(2*Math.atan(tangent*1.04));camera.updateProjectionMatrix();return camera;
}
export function makeScenicCamera({position,referencePosition,target,up,points,mode='fixed',aspect=2400/2440}){
 if(!['fixed','full-lake'].includes(mode))throw RangeError('Unknown scenic lens mode');
 const camera=fittedCamera(position,target,up,points,aspect),reference=fittedCamera(referencePosition,target,up,points,aspect);
 const fittedFov=camera.fov;if(mode==='fixed'){camera.fov=reference.fov;camera.updateProjectionMatrix()}
 return {camera,mode,referenceFov:reference.fov,fittedFov};
}
