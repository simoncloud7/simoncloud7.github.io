import * as THREE from 'three';
import {blocksSubjectView,cloudViewOpacity} from './cloud-drift.mjs?v=e6c32348dbca';

// Cache each part separately so moving EVA crew are covered without expanding
// one enormous ship bound. Only the foreground assembly receives this fade.
export class LaunchViewClearance{
 constructor(root){
  this.root=root;this.fade={value:1};this.target=1;this.enabled=false;this.parts=[];this.materials=new Map();this.eye=new THREE.Vector3();this.sphere=new THREE.Sphere();this.offset=[0,0,0];this.subjects=[];
  root.traverse(node=>{
   if(!node.isMesh&&!node.isLine)return;if(!node.geometry.boundingSphere)node.geometry.computeBoundingSphere();this.parts.push({node,sphere:node.geometry.boundingSphere.clone()});
   const clone=original=>{
    if(this.materials.has(original))return this.materials.get(original);const material=original.clone(),previous=original.onBeforeCompile,key=original.customProgramCacheKey(),fade=this.fade;
    material.onBeforeCompile=function(shader,renderer){previous.call(this,shader,renderer);shader.uniforms.uLaunchViewOpacity=fade;shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nuniform float uLaunchViewOpacity;').replace('#include <opaque_fragment>','diffuseColor.a*=uLaunchViewOpacity;\n#include <opaque_fragment>')};
    material.customProgramCacheKey=()=>key+'|launch-view-opacity-1';this.materials.set(original,material);return material;
   };node.material=Array.isArray(node.material)?node.material.map(clone):clone(node.material);
  });
 }
 update(dt,{enabled,camera,subjects=[]}){
  this.enabled=!!enabled;this.target=1;let count=0;
  if(enabled){
   camera.getWorldPosition(this.eye);
   for(const subject of subjects){if(subject.visible===false)continue;const cached=this.subjects[count]??(this.subjects[count]={offset:[0,0,0],radius:0});subject.center.clone().sub(this.eye).toArray(cached.offset);cached.radius=subject.radius;count++}
   for(const {node,sphere} of this.parts){
    let visible=true;for(let p=node;p;p=p.parent){if(!p.visible){visible=false;break}if(p===this.root)break}if(!visible)continue;
    this.sphere.copy(sphere).applyMatrix4(node.matrixWorld);this.sphere.center.sub(this.eye).toArray(this.offset);
    for(let i=0;i<count;i++){const subject=this.subjects[i];if(blocksSubjectView(this.offset,this.sphere.radius,subject.offset,subject.radius)){this.target=.025;break}}
    if(this.target<1)break;
   }
  }
  this.fade.value=cloudViewOpacity(this.fade.value,this.target,dt);
  const fading=this.fade.value<1||this.target<1;if(fading!==this.fading){this.fading=fading;for(const [original,material] of this.materials){material.transparent=fading||original.transparent;material.depthWrite=fading?false:original.depthWrite;material.forceSinglePass=fading||original.forceSinglePass;material.needsUpdate=true}}
 }
 report(){return {enabled:this.enabled,viewOpacity:this.fade.value,targetOpacity:this.target,parts:this.parts.length}}
}
