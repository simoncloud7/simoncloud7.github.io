import * as THREE from 'three';
import {surfaceViewGeometry,surfaceLookDirection,surfaceLookAngles,subsatelliteAnchor} from './surface-observer.mjs?v=4f5f5d0b1547';
import {PLANET_NORTH} from './daylight.mjs?v=4f5f5d0b1547';
const $=s=>document.querySelector(s);
export class SurfaceObserver{
 constructor({scene,globe,moon,surfaces,presets,onView,sunDirection=null}){
  Object.assign(this,{scene,globe,moon,surfaces,presets,onView,sunDirection});this.enabled=false;this.selecting=false;this.anchor=null;this.siteName='';this.siteKey='';this.lastSightTime=-1;this.clearTerrain=true;this.autoTracking=true;this.viewActive=false;this.followSubpoint=false;this.subpointRadius=18.2;this.lastSubpointSample=-Infinity;this.elapsed=0;
  this.marker=new THREE.Mesh(new THREE.SphereGeometry(.13,16,12),new THREE.MeshBasicMaterial({color:0xffd393}));this.marker.userData.sensorOverlay=true;this.marker.visible=false;globe.add(this.marker);
  $('#tidal-observer-toggle').onclick=()=>{if(this.enabled){this.setEnabled(false);this.onView('planet',true)}else this.open()};
  $('#tidal-observer-site').onchange=e=>this.selectSite(e.target.value);
  $('#tidal-observer-pick').onclick=()=>{this.followSubpoint=false;this.setEnabled(true);this.selecting=true;document.body.classList.add('picking-observation-site');$('#tidal-observer-status').textContent='請點擊動畫區的星球表面；可先拖曳環繞選位置。';this.onView('planet',true)};
  $('#tidal-observer-track').onclick=()=>{this.autoTracking=true;this.track()};
  $('#tidal-observer-relocate').onclick=()=>this.selectSite('subsatellite');
  $('#tidal-observer-fov').oninput=()=>{if(this.anchor)this.track()};
  $('#tidal-observer-follow-subpoint').onchange=e=>this.setFollowSubpoint(e.target.checked);
  $('#tidal-observer-auto-track').onchange=e=>{this.autoTracking=e.target.checked;if(this.anchor)this.track()};
  for(const id of ['tidal-observer-azimuth','tidal-observer-elevation-angle'])$('#'+id).oninput=()=>{this.autoTracking=false;if(this.anchor)this.track()};
  this.setEnabled(false);
 }
 hitSurface(ray){return ray.intersectObjects(this.surfaces,false).find(hit=>{for(let node=hit.object;node;node=node.parent)if(!node.visible)return false;return true})}
 cancelPicking(){this.selecting=false;document.body.classList.remove('picking-observation-site')}
 syncControls(){
  const locked=this.viewActive&&this.autoTracking&&!this.selecting;
  $('#tidal-observer-track').disabled=!this.enabled||!this.anchor||locked;
  $('#tidal-observer-track').textContent=locked?'正在自動追蹤':this.viewActive?'對準並追蹤衛星':'返回地表並追蹤衛星';
  $('#tidal-observer-auto-track').checked=this.autoTracking;
  $('#tidal-observer-relocate').hidden=this.siteKey!=='subsatellite'||this.followSubpoint;$('#tidal-observer-follow-subpoint').checked=this.followSubpoint;
  $('#tidal-observer-camera-note').textContent=this.autoTracking?'自動追蹤中；調整左右轉向或抬頭／低頭，會切換為手動觀看。':'手動觀看中；按「對準並追蹤衛星」可重新對準目標。';
 }
 setViewActive(active){this.viewActive=!!active&&this.enabled;this.syncControls()}
 setEnabled(enabled){
  this.enabled=enabled;if(!enabled){this.viewActive=false;this.currentPose=null}this.cancelPicking();$('#tidal-observer-toggle').setAttribute('aria-pressed',String(enabled));$('#tidal-observer-toggle').textContent=enabled?'停用地表觀測':'啟用地表觀測';$('#tidal-observer-controls').hidden=!enabled;this.marker.visible=enabled&&!!this.anchor;this.syncControls();
  document.body.dataset.surfaceObservation=JSON.stringify({enabled,site:this.siteName||null,tracking:false});
  if(!enabled)$('#tidal-observer-status').textContent='地表觀測已停用。';if(enabled&&!this.anchor)$('#tidal-observer-status').textContent='請選擇觀測地點，或直接在星球上選點。';
 }
 open(){
  this.setEnabled(true);this.autoTracking=true;
  if(this.followSubpoint)this.selectSite('subsatellite',true);else if(this.siteKey==='subsatellite')this.selectSite('subsatellite');else if(this.anchor)this.track();
  this.showControls();
 }
 // Opening the page is separate from the explicit enable action. Preserve a
 // disabled observer and its saved site when returning via tabs or navigation.
 showControls(){this.syncControls();$('#surface-observer-settings').closest('.science').scrollTop=0}
 selectSite(key,keepFollowing=false){
  if(!keepFollowing)this.followSubpoint=false;
  if(key==='subsatellite'){
   this.scene.updateMatrixWorld(true);const normal=this.globe.worldToLocal(this.moon.getWorldPosition(new THREE.Vector3())).normalize();this.selectNormal(normal,this.followSubpoint?'衛星正下方（自動移動）':'目前衛星正下方','subsatellite',keepFollowing);return;
  }
  const preset=this.presets[key];if(preset)this.selectNormal(preset.normal,preset.name,key);
 }
 selectNormal(normal,name,key,keepFollowing=false){
  this.scene.updateMatrixWorld(true);const worldNormal=normal.clone().normalize().applyQuaternion(this.globe.getWorldQuaternion(new THREE.Quaternion())),ray=new THREE.Raycaster(worldNormal.clone().multiplyScalar(80),worldNormal.clone().negate(),0,160),hit=this.hitSurface(ray);
  this.selectWorld(hit?.point||worldNormal.clone().multiplyScalar(18.2),name,key,keepFollowing);
 }
 selectWorld(point,name='自選觀測點',key='custom',keepFollowing=false){
  if(!keepFollowing)this.followSubpoint=false;
  this.currentPose=null;this.anchor=this.globe.worldToLocal(point.clone());this.siteName=name;this.siteKey=key;this.autoTracking=true;this.marker.position.copy(this.anchor).addScaledVector(this.anchor.clone().normalize(),.035);$('#tidal-observer-site').value=key;this.lastSightTime=-1;this.setEnabled(true);this.track();$('#tidal-observer-status').scrollIntoView({block:'nearest',behavior:'smooth'});
 }
 setFollowSubpoint(enabled){
  this.followSubpoint=enabled;this.lastSubpointSample=-Infinity;
  if(enabled){this.autoTracking=true;this.selectSite('subsatellite',true)}else{this.siteName='星下點（已固定）';this.lastSightTime=-1;this.track()}
  this.syncControls();
 }
 updateSubpoint(){
  const localMoon=this.globe.worldToLocal(this.moon.getWorldPosition(new THREE.Vector3())),n=localMoon.clone().normalize();
  const shifted=!this.sampledSubpointNormal||n.angleTo(this.sampledSubpointNormal)>.004;
  if(shifted||this.elapsed-this.lastSubpointSample>.08){
   const worldNormal=n.clone().applyQuaternion(this.globe.getWorldQuaternion(new THREE.Quaternion())),ray=new THREE.Raycaster(worldNormal.clone().multiplyScalar(80),worldNormal.clone().negate(),0,160),hit=this.hitSurface(ray);
   this.subpointRadius=hit?this.globe.worldToLocal(hit.point.clone()).length():18.2;this.lastSubpointSample=this.elapsed;this.sampledSubpointNormal=n.clone();this.lastSightTime=-1;
  }
  this.anchor=new THREE.Vector3(...subsatelliteAnchor(localMoon.toArray(),this.subpointRadius));this.marker.position.copy(this.anchor).addScaledVector(n,.035);
 }
 aimAtSun(){
   if(!this.enabled||!this.anchor||!this.sunDirection)return false;const q=this.globe.getWorldQuaternion(new THREE.Quaternion()),normal=this.anchor.clone().normalize().applyQuaternion(q),sun=this.sunDirection(),north=new THREE.Vector3(...PLANET_NORTH).applyQuaternion(q),angles=surfaceLookAngles(normal.toArray(),sun.toArray(),north.toArray());if(angles.elevation<(this.currentPose?.geometry.horizonElevation||0)-1e-6)return false;
  this.autoTracking=false;$('#tidal-observer-azimuth').value=String(angles.azimuth);$('#tidal-observer-elevation-angle').value=String(angles.elevation);this.track();return true;
 }
 aimAtSky(azimuth,elevation,fov){
  if(!this.enabled||!this.anchor)return false;this.autoTracking=false;
  for(const [id,value] of [['azimuth',azimuth],['elevation-angle',elevation],['fov',fov]]){const input=$('#tidal-observer-'+id);input.value=String(Math.max(Number(input.min),Math.min(Number(input.max),value)))}
  this.track();return true;
 }
 track(){if(this.enabled&&this.anchor){this.cancelPicking();this.onView('tidal-observe')}}
 pose(){
  if(!this.anchor)return null;this.scene.updateMatrixWorld(true);if(this.followSubpoint)this.updateSubpoint();
   const globeRotation=this.globe.getWorldQuaternion(new THREE.Quaternion()),normal=this.anchor.clone().normalize().applyQuaternion(globeRotation),position=this.globe.localToWorld(this.anchor.clone()).addScaledVector(normal,.35),satellite=this.moon.getWorldPosition(new THREE.Vector3()),geometry=surfaceViewGeometry(position.toArray(),satellite.toArray(),normal.toArray()),northAxis=new THREE.Vector3(...PLANET_NORTH).applyQuaternion(globeRotation).toArray();
  const angles=this.autoTracking?surfaceLookAngles(normal.toArray(),geometry.lookDirection,northAxis):{azimuth:Number($('#tidal-observer-azimuth').value),elevation:Number($('#tidal-observer-elevation-angle').value)};
  if(this.autoTracking&&Math.abs(angles.elevation-90)<.001)angles.azimuth=this.stableAzimuth||0;else this.stableAzimuth=angles.azimuth;
  if(this.autoTracking){$('#tidal-observer-azimuth').value=String(angles.azimuth);$('#tidal-observer-elevation-angle').value=String(angles.elevation)}
  const look=new THREE.Vector3(...(this.autoTracking?geometry.lookDirection:surfaceLookDirection(normal.toArray(),angles.azimuth,angles.elevation,northAxis))),cameraUp=new THREE.Vector3(...surfaceLookDirection(normal.toArray(),angles.azimuth,angles.elevation+90,northAxis));
  return {position,target:position.clone().addScaledVector(look,10),up:cameraUp,localVertical:normal,satellite,geometry,angles,look};
 }
 update(elapsed,tracking){
  this.elapsed=elapsed;tracking=tracking&&this.enabled;this.viewActive=tracking;this.syncControls();if(!this.enabled||!this.anchor||this.selecting)return;const pose=this.pose(),g=pose.geometry;this.currentPose=pose;
  if(elapsed-this.lastSightTime>.2||this.lastSightTime<0){const ray=new THREE.Raycaster(pose.position,new THREE.Vector3(...g.direction),.03,g.distance-.1);this.clearTerrain=!this.hitSurface(ray);this.lastSightTime=elapsed}
  const visible=g.planetClear&&this.clearTerrain,status=visible?'衛星中心可見':!g.planetClear?'衛星中心在地平線下':'衛星中心被地形或設施遮蔽';
  $('#tidal-observer-status').textContent=this.siteName+' · '+status+(tracking?' · '+(this.autoTracking?'自動追蹤':'手動觀看'):' · 可返回地表觀測');$('#tidal-observer-elevation').textContent=g.elevation.toFixed(1)+'°';$('#tidal-observer-fov-value').textContent=Number($('#tidal-observer-fov').value).toFixed(0)+'°';$('#tidal-observer-azimuth-value').textContent=pose.angles.azimuth.toFixed(0)+'°';$('#tidal-observer-elevation-angle-value').textContent=pose.angles.elevation.toFixed(0)+'°';
   const local=this.anchor.clone().normalize();$('#tidal-observer-position').textContent='緯度 '+THREE.MathUtils.radToDeg(Math.asin(local.y)).toFixed(1)+'° · 經度 '+THREE.MathUtils.radToDeg(Math.atan2(local.x,local.z)).toFixed(1)+'°';
  document.body.dataset.surfaceObservation=JSON.stringify({enabled:this.enabled,tracking,autoTracking:this.autoTracking,followSubpoint:this.followSubpoint,observationMode:this.followSubpoint?'moving sub-satellite viewpoint':'fixed ground site',site:this.siteName,siteKey:this.siteKey,anchor:this.anchor.toArray(),position:pose.position.toArray(),direction:pose.look.toArray(),up:pose.localVertical.toArray(),cameraUp:pose.up.toArray(),satellite:pose.satellite.toArray(),viewAzimuth:pose.angles.azimuth,viewElevation:pose.angles.elevation,elevation:g.elevation,horizonElevation:g.horizonElevation,visible,planetClear:g.planetClear,terrainClear:this.clearTerrain,fov:Number($('#tidal-observer-fov').value),model:'instantaneous scene geometry; no light delay, refraction or relativistic imaging'});
 }
}
