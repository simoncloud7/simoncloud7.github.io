import * as THREE from 'three';

// Resolve a projected caption collision horizontally, with bounded offsets
// and a small per-frame step. The vertical attachment never changes.
export function clockCaptionOffsets(a,b,previous=[0,0],active=true){
 const dx=b.x+b.width/2-a.x-a.width/2,vertical=a.y<b.y+b.height+8&&a.y+a.height+8>b.y,overlap=(a.width+b.width)/2+8-Math.abs(dx),direction=Math.abs(dx)>20?Math.sign(dx):Math.sign(previous[1]-previous[0])||1,shift=active&&vertical&&overlap>0?Math.min(48,overlap/2):0,target=[-direction*shift,direction*shift];
 return previous.map((p,i)=>p+Math.max(-1.5,Math.min(1.5,(target[i]-p)*.14)));
}

// A world-space annotation attached to an actual sample point in the scene.
export class ClockMarker{
 constructor(color){
  this.group=new THREE.Group();this.dial=new THREE.Group();this.group.add(this.dial);this.color=new THREE.Color(color);this.last='';
  const face=new THREE.Mesh(new THREE.CircleGeometry(1.35,48),new THREE.MeshBasicMaterial({color:0x102633,side:THREE.DoubleSide,depthTest:false,depthWrite:false}));
  const rim=new THREE.Mesh(new THREE.RingGeometry(1.32,1.42,48),new THREE.MeshBasicMaterial({color,side:THREE.DoubleSide,depthTest:false,depthWrite:false}));
  face.renderOrder=rim.renderOrder=100;this.dial.add(face,rim);
  const ticks=[];for(let i=0;i<12;i++){const a=i/12*Math.PI*2;for(const r of [1.12,1.23])ticks.push(Math.sin(a)*r,Math.cos(a)*r,.02)}
  const tickLines=new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(Array.from({length:ticks.length/3},(_,i)=>new THREE.Vector3(...ticks.slice(i*3,i*3+3)))),new THREE.LineBasicMaterial({color,depthTest:false,depthWrite:false}));tickLines.renderOrder=101;this.dial.add(tickLines);
  this.hand=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0,0,.03),new THREE.Vector3(0,1.03,.03)]),new THREE.LineBasicMaterial({color,depthTest:false,depthWrite:false}));this.hand.renderOrder=102;this.dial.add(this.hand);
  this.canvas=document.createElement('canvas');this.canvas.width=640;this.canvas.height=330;this.ctx=this.canvas.getContext('2d');
  this.texture=new THREE.CanvasTexture(this.canvas);this.texture.colorSpace=THREE.SRGBColorSpace;
  this.label=new THREE.Sprite(new THREE.SpriteMaterial({map:this.texture,depthTest:false,depthWrite:false,toneMapped:false}));this.label.position.y=7;this.label.scale.set(18,9.28125,1);this.label.renderOrder=103;this.group.add(this.label);
 }
 update(camera,position,{title,seconds,period,detail}){
  this.group.position.copy(position);this.group.quaternion.copy(camera.quaternion);const pixels=innerWidth<700?135:180,worldPerPixel=2*camera.position.distanceTo(position)*Math.tan(camera.fov*Math.PI/360)/innerHeight;this.group.scale.setScalar(worldPerPixel*pixels/18);this.dial.scale.setScalar(this.worldDialRadius?this.worldDialRadius/(1.42*this.group.scale.x):1);this.hand.rotation.z=-seconds/period*Math.PI*2;
  const key=title+seconds.toFixed(3)+period+detail;if(key===this.last)return;this.last=key;
  const ctx=this.ctx;ctx.clearRect(0,0,640,330);ctx.fillStyle='rgba(10,27,39,.94)';ctx.beginPath();ctx.roundRect(3,3,634,324,28);ctx.fill();ctx.strokeStyle='#'+this.color.getHexString();ctx.lineWidth=3;ctx.stroke();
  ctx.textAlign='center';ctx.fillStyle='#'+this.color.getHexString();ctx.font='500 64px "Microsoft JhengHei",sans-serif';const width=ctx.measureText(title).width;if(width>590)ctx.font='500 '+Math.floor(64*590/width)+'px \"Microsoft JhengHei\",sans-serif';ctx.fillText(title,320,78);
  ctx.fillStyle='#f2f5e9';ctx.font='600 110px "Segoe UI",sans-serif';ctx.fillText(seconds.toFixed(3)+' s',320,184);
  ctx.fillStyle='#c3d5d4';ctx.font='44px "Microsoft JhengHei",sans-serif';ctx.fillText(detail,320,258);ctx.font='36px "Microsoft JhengHei",sans-serif';ctx.fillStyle='#91aeb7';ctx.fillText('每圈 '+period+' 秒',320,306);
  this.texture.needsUpdate=true;
 }
}
