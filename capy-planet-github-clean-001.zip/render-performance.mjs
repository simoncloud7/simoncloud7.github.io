// Low-frequency, local diagnostics. Measures JS/submission time, not GPU time
// or device temperature. No request is made and no data is persisted.
export class FrameWorkMeter{
 constructor({now=()=>performance.now(),report=()=>{}}={}){this.now=now;this.report=report;this.started=now();this.frames=0;this.work=0;this.peak=0}
 begin(){return this.now()}
 end(started,extra={}){
  const now=this.now(),ms=Math.max(0,now-started);this.frames++;this.work+=ms;this.peak=Math.max(this.peak,ms);
  const elapsed=now-this.started;if(elapsed<1000)return;
  this.report({...extra,fps:Math.round(this.frames*10000/elapsed)/10,workMsPerSecond:Math.round(this.work*10000/elapsed)/10,meanFrameMs:Math.round(this.work/this.frames*10)/10,peakFrameMs:Math.round(this.peak*10)/10});
  this.started=now;this.frames=0;this.work=0;this.peak=0;
 }
 reset(){this.started=this.now();this.frames=0;this.work=0;this.peak=0}
}

export const RENDER_QUALITY_KEY='planet-render-quality-v1';
export const RENDER_PROFILES=Object.freeze({
 saving:{label:'省電',fps:24,minFps:12,duty:.5,pixelRatio:1,pixelBudget:1200000,shadowSize:1024},
 balanced:{label:'均衡',fps:30,minFps:18,duty:.7,pixelRatio:1.25,pixelBudget:2500000,shadowSize:2048},
 smooth:{label:'流暢',fps:60,minFps:60,duty:1,pixelRatio:1.6,pixelBudget:5000000,shadowSize:4096}
});
export function renderPixelRatio(profile,width,height,deviceRatio=1){return Math.max(.5,Math.min(deviceRatio||1,profile.pixelRatio,Math.sqrt(profile.pixelBudget/Math.max(1,width*height))))}

// The admitted frame carries elapsed wall time, so limiting drawing does not
// divide animation/physics speed. A hidden page starts a new time origin.
export class FramePacer{
 constructor(fps=30){this.fps=fps;this.reset()}
 reset(){this.next=null;this.last=null;this.workInterval=0}
 adapt(workMs,profile){const requested=profile.duty<1?workMs/profile.duty:0;this.workInterval=Math.min(1000/profile.minFps,Math.max(1000/profile.fps,requested))}
 step(now){
  if(this.next!==null&&now+.5<this.next)return null;
  const dt=this.last===null?0:Math.min(.1,Math.max(0,(now-this.last)/1000)),interval=Math.max(1000/this.fps,this.workInterval);
  const late=this.next===null?0:Math.max(0,now-this.next)%interval;
  this.next=now+interval-late;this.last=now;return dt;
 }
}

export class SceneRenderLoop{
 constructor({onFrame,onQuality=()=>{},env=globalThis,storage}={}){
  if(storage===undefined)try{storage=env.sessionStorage}catch{}
  Object.assign(this,{onFrame,onQuality,env,storage});this.frame=null;this.disposed=false;this.quality='balanced';
  try{const saved=storage?.getItem(RENDER_QUALITY_KEY);if(Object.hasOwn(RENDER_PROFILES,saved))this.quality=saved}catch{}
  this.pacer=new FramePacer(this.profile.fps);
  this.meter=new FrameWorkMeter({now:()=>env.performance.now(),report:value=>env.document.body.dataset.renderPerformance=JSON.stringify(value)});
  this.tick=now=>{this.frame=null;if(this.disposed||env.document.hidden)return;const dt=this.pacer.step(now);if(dt!==null){const start=this.meter.begin(),extra=this.onFrame(dt,now)||{},cost=Math.max(0,env.performance.now()-start);this.meanCost=this.meanCost===undefined?cost:this.meanCost*.9+cost*.1;this.pacer.adapt(this.meanCost,this.profile);this.meter.end(start,{quality:this.quality,targetFps:this.profile.fps,adaptiveFps:Math.round(10000/this.pacer.workInterval)/10,...extra})}this.frame=env.requestAnimationFrame(this.tick)};
  this.resume=()=>{if(this.disposed||env.document.hidden||this.frame!==null)return;this.pacer.reset();this.meter.reset();this.meanCost=undefined;env.document.body.dataset.renderSuspended='false';this.frame=env.requestAnimationFrame(this.tick)};
  this.suspend=()=>{if(this.frame!==null)env.cancelAnimationFrame(this.frame);this.frame=null;this.pacer.reset();this.meter.reset();env.document.body.dataset.renderSuspended='true'};
  this.visibility=()=>env.document.hidden?this.suspend():this.resume();
  env.document.addEventListener('visibilitychange',this.visibility);env.addEventListener('pagehide',this.suspend);env.addEventListener('pageshow',this.resume);
  this.onQuality(this.profile);this.resume();
 }
 get profile(){return RENDER_PROFILES[this.quality]}
 setQuality(quality){if(!Object.hasOwn(RENDER_PROFILES,quality))return;this.quality=quality;this.pacer.fps=this.profile.fps;this.pacer.reset();this.meanCost=undefined;try{this.storage?.setItem(RENDER_QUALITY_KEY,quality)}catch{}this.onQuality(this.profile);this.meter.reset()}
 installControl(container){
  if(!container)return;const section=this.env.document.createElement('div');section.className='scene-reset-controls render-quality-control';
  const label=this.env.document.createElement('label');label.textContent='畫面效能';const select=this.env.document.createElement('select');select.id='render-quality';
  for(const [value,profile] of Object.entries(RENDER_PROFILES)){const option=this.env.document.createElement('option');option.value=value;option.textContent=profile.label+' · 最高 '+profile.fps+' FPS';select.append(option)}select.value=this.quality;select.onchange=()=>this.setQuality(select.value);label.append(select);
  const note=this.env.document.createElement('p');note.className='note';note.textContent='預設均衡；負載高時自動降低幀數，發燙可選省電。切到背景會暫停。';section.append(label,note);container.append(section);
 }
 dispose(){this.disposed=true;this.suspend();this.env.document.removeEventListener('visibilitychange',this.visibility);this.env.removeEventListener('pagehide',this.suspend);this.env.removeEventListener('pageshow',this.resume)}
}
