import {dot,normalize,seaDistance} from './marine.mjs?v=41d10fd0dc43';
export class OceanCurrentField{
 constructor(data,isWater){this.data=data;this.isWater=isWater;this.cache=new Map();this.obstacleKey=''}
 nearby(n){const d=this.data,x=((Math.round((Math.atan2(n[0],n[1])*180/Math.PI+180)/d.step_degrees)%d.width)+d.width)%d.width,y=Math.max(0,Math.min(d.height-1,Math.round((Math.asin(Math.max(-1,Math.min(1,n[2])))*180/Math.PI-d.min_latitude)/d.step_degrees))),ids=new Set();for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++){const yy=Math.max(0,Math.min(d.height-1,y+dy));ids.add(d.lookup[yy*d.width+(x+dx+d.width)%d.width])}return [...ids].sort((a,b)=>dot(n,d.nodes[b])-dot(n,d.nodes[a]))}
 clear(a,b,others=[]){const distance=seaDistance(a,b);if(distance<1e-8)return true;const steps=Math.max(2,Math.ceil(distance/.18)),fractions=[.01,.025,.05,.1].filter(v=>v<distance).map(v=>v/distance);for(let i=1;i<=steps;i++)fractions.push(i/steps);for(const t of fractions){const p=normalize(a.map((v,j)=>v+(b[j]-v)*t));if(!this.isWater(p)||others.some(o=>seaDistance(p,o)<Math.min(6.8,seaDistance(a,o))-1e-7))return false}return true}
 detour(start,goal,other){
  const key=start+':'+goal;if(this.cache.has(key))return this.cache.get(key);
  const d=this.data,queue=[[seaDistance(d.nodes[start],d.nodes[goal]),start]],cost=new Map([[start,0]]),prev=new Map();let found=false;
  while(queue.length){queue.sort((a,b)=>b[0]-a[0]);const [,i]=queue.pop();if(i===goal){found=true;break}
   for(const j of d.neighbors[i]){if(seaDistance(d.nodes[j],other)<7.2)continue;const g=cost.get(i)+seaDistance(d.nodes[i],d.nodes[j]);if(g>=(cost.get(j)??Infinity))continue;if(!this.clear(d.nodes[i],d.nodes[j],[other]))continue;cost.set(j,g);prev.set(j,i);queue.push([g+seaDistance(d.nodes[j],d.nodes[goal]),j])}
  }
  let path=null;if(found){path=[goal];while(path.at(-1)!==start)path.push(prev.get(path.at(-1)));path.reverse()}
  this.cache.set(key,path);return path;
 }
 sample(n,strength=1,others=[]){
  const zero=[0,0,0];zero.obstaclesResolved=true;if(strength===0)return zero;
  const d=this.data,obstacles=others.filter(o=>seaDistance(n,o)>.1),near=obstacles.find(o=>seaDistance(n,o)<13),key=others.map(o=>o.map(v=>Math.round(v*45)).join(',')).join(':');
  zero.vesselDeflection=!!near;if(key!==this.obstacleKey){this.cache.clear();this.obstacleKey=key}
  const candidates=this.nearby(n);let start=candidates.find(i=>d.root[i]>=0&&(!near||seaDistance(d.nodes[i],near)>=7.2)&&this.clear(n,d.nodes[i],obstacles));
  if(start===undefined)start=candidates.find(i=>d.root[i]>=0&&this.clear(n,d.nodes[i],obstacles));if(start===undefined)return zero;
  let path=[start];
  if(near){let phase=d.root[start],distance=0;while(distance<16){const next=(phase+1)%d.cycle.length;distance+=seaDistance(d.nodes[d.cycle[phase]],d.nodes[d.cycle[next]]);phase=next}let goal=d.cycle[phase];for(let k=0;k<d.cycle.length&&seaDistance(d.nodes[goal],near)<9;k++){phase=(phase+1)%d.cycle.length;goal=d.cycle[phase]}path=this.detour(start,goal,near)||path}
  else for(let k=0;k<6;k++){const next=d.next[path.at(-1)];if(next<0)break;path.push(next)}
  let target=null,edge=0,projection=d.nodes[path[0]],nearest=Infinity;
  for(let i=0;i<path.length-1;i++){const a=d.nodes[path[i]],b=d.nodes[path[i+1]],ab=b.map((v,j)=>v-a[j]),t=Math.max(0,Math.min(1,dot(n.map((v,j)=>v-a[j]),ab)/dot(ab,ab))),p=normalize(a.map((v,j)=>v+ab[j]*t)),distance=seaDistance(n,p);if(distance<nearest){nearest=distance;projection=p;edge=i}}
  // Advance from the projection, not a fixed node index: switching nearest
  // cells must not send the current back toward the preceding waypoint.
  const ahead=distance=>{let p=projection;for(let i=edge+1;i<path.length;i++){const q=d.nodes[path[i]],length=seaDistance(p,q);if(length>=distance)return normalize(p.map((v,j)=>v+(q[j]-v)*distance/length));distance-=length;p=q}return p};
  for(const distance of [2,1,.5,.2]){const p=ahead(distance);if(seaDistance(n,p)>.05&&this.clear(n,p,obstacles)){target=p;break}}
  if(!target&&seaDistance(n,projection)>.1&&this.clear(n,projection,obstacles))target=projection;
  if(!target){const p=d.nodes[start];if(seaDistance(n,p)>.05&&this.clear(n,p,obstacles))target=p}
  if(!target)return zero;
  const tangent=normalize(target.map((v,i)=>v-dot(target,n)*n[i])),flow=tangent.map(v=>v*strength);flow.obstaclesResolved=true;flow.vesselDeflection=!!near;flow.gyre=true;return flow;
 }
}
