import {clockRates} from './gravity.mjs?v=391fe0c7f1dc';
export const FLY_RADIUS=1.24,STORY_YEARS_PER_SECOND=1;
const smooth=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t)};
// Visual exposure only. Physical clock integration keeps the existing duty cycle.
export function runnerExposure(phase,beta){return phase<16?smooth(.9,2.1,phase)*(1-smooth(13.8,15.2,phase))*smooth(.2,.5,beta):0}
export function heroState(t,kind){
 const period=kind==='super'?31:28,phase=((t%period)+period)%period;
 if(kind==='super')return {phase,mode:phase<20?'flight':'hover',moving:phase<20};
 return {phase,mode:phase<16?'run':phase<18?'transform':phase<26?'walk':'transform',moving:phase<16||phase>=18&&phase<26};
}
// First stop and every third stop revisit the lake; other stops vary around the orbit.
// Cycle-based sampling is reproducible across frame rates and flight reversals.
export function superStop(cycle){
 cycle=Math.max(0,Math.floor(cycle));
 if(cycle%3===0)return {cycle,lake:true,angle:0};
 let seed=Math.imul(cycle+1,0x45d9f3b);seed=Math.imul(seed^(seed>>>16),0x45d9f3b);seed=(seed^(seed>>>16))>>>0;
 return {cycle,lake:false,angle:.5+(seed/4294967296)*(2*Math.PI-1)};
}
export function lakeArrival(start,velocity,remaining,progress,stopAngle=0){
 const direction=Math.sign(velocity)||1,target=(direction>0?Math.ceil((start+velocity*remaining*.7-stopAngle)/(2*Math.PI)):Math.floor((start+velocity*remaining*.7-stopAngle)/(2*Math.PI)))*2*Math.PI+stopAngle,u=Math.max(0,Math.min(1,progress));
 return {angle:start+(target-start)*(3*u*u-2*u*u*u)+velocity*remaining*(u*u*u-2*u*u+u),target};
}
export function storyClockRates(k,beta,superMode,speedMode){
 const speedBeta=speedMode==='run'?beta:speedMode==='walk'?1.4/299792458:0;
 return {city:1,super:clockRates(k,FLY_RADIUS,superMode==='flight'?beta:0,{reference:'surface'}).ratio,speed:clockRates(k,1,speedBeta,{reference:'surface'}).ratio};
}
export function advanceStory(clock,dt,rates){
 if(!Number.isFinite(dt)||dt<0)throw RangeError('Story time advances monotonically');
 return {city:clock.city+dt*rates.city,super:clock.super+dt*rates.super,speed:clock.speed+dt*rates.speed};
}
