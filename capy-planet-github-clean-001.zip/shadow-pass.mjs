// A camera pass that temporarily hides actors must not consume a pending
// main-view shadow update. A refreshed photo leaves the shared map dirty.
export function withSensorShadows(renderer,capture,{refresh=false}={}){
 const map=renderer.shadowMap,autoUpdate=map.autoUpdate,needsUpdate=map.needsUpdate;
 map.autoUpdate=refresh;map.needsUpdate=refresh;
 try{return capture()}
 finally{map.autoUpdate=autoUpdate;map.needsUpdate=refresh||needsUpdate||map.needsUpdate}
}
