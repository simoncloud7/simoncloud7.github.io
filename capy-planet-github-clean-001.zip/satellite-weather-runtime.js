import * as THREE from 'three';
import {foreheadStormState,STORM_PERIOD,STORM_START,STORM_DURATION} from './satellite-weather.mjs?v=2d2193a1a37f';

// Artistic dust weather, attached to the authored capybara forehead coordinates.
export class SatelliteForeheadStorm{
 constructor(parent){
  this.time=0;this.group=new THREE.Group();this.group.position.set(0,1.855,-.0744);
  this.group.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),new THREE.Vector3(0,.90,.44).normalize());
  this.group.visible=false;parent.add(this.group);this.swirl=new THREE.Group();this.group.add(this.swirl);
  const vertices=[],indices=[],steps=64;
  for(let arm=0;arm<3;arm++)for(let i=0;i<=steps;i++)for(const side of [-1,1]){
   const t=i/steps,r=.023+.19*t**1.3,a=arm*Math.PI*2/3+t*Math.PI*5+side*.09;
   vertices.push(Math.cos(a)*r,t*.55,Math.sin(a)*r);
   if(side===1&&i<steps){const n=arm*(steps+1)*2+i*2;indices.push(n,n+1,n+2,n+1,n+3,n+2)}
  }
  const funnelGeometry=new THREE.BufferGeometry();funnelGeometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));funnelGeometry.setIndex(indices);
  const bodyGeometry=new THREE.CylinderGeometry(.21,.023,.55,32,24,true),bodyPositions=bodyGeometry.attributes.position;
  for(let i=0;i<bodyPositions.count;i++){const t=THREE.MathUtils.clamp((bodyPositions.getY(i)+.275)/.55,0,1),a=Math.atan2(bodyPositions.getZ(i),bodyPositions.getX(i)),r=.023+.19*t**1.3;bodyPositions.setXYZ(i,Math.cos(a)*r+.012*Math.sin(t*7),t*.55,Math.sin(a)*r+.012*(Math.cos(t*7)-1))}bodyPositions.needsUpdate=true;
  this.body=new THREE.Mesh(bodyGeometry,new THREE.MeshBasicMaterial({color:0x9eacaa,transparent:true,opacity:0,side:THREE.DoubleSide,depthWrite:false}));this.swirl.add(this.body);
  this.funnel=new THREE.Mesh(funnelGeometry,new THREE.MeshBasicMaterial({color:0xc2c8c3,transparent:true,opacity:0,side:THREE.DoubleSide,depthWrite:false}));this.swirl.add(this.funnel);
  this.cloudMaterial=new THREE.MeshBasicMaterial({color:0xabb6b5,transparent:true,opacity:0,depthWrite:false});
  const cloudGeometry=new THREE.SphereGeometry(1,16,10);
  for(const [x,y,z,s] of [[0,.55,0,.13],[.10,.54,.02,.10],[-.10,.56,-.04,.11]]){const cloud=new THREE.Mesh(cloudGeometry,this.cloudMaterial);cloud.position.set(x,y,z);cloud.scale.set(s,.038,s*.85);this.swirl.add(cloud)}
  this.particleGeometry=new THREE.BufferGeometry();this.particleGeometry.setAttribute('position',new THREE.Float32BufferAttribute(new Float32Array(144*3),3));
  this.particleMaterial=new THREE.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{strength:{value:0},pixelScale:{value:innerHeight*Math.min(devicePixelRatio,1.6)}},
   vertexShader:'uniform float pixelScale;void main(){vec4 mv=modelViewMatrix*vec4(position,1.);gl_Position=projectionMatrix*mv;gl_PointSize=clamp(.025*pixelScale/-mv.z,1.5,6.);}',
   fragmentShader:'uniform float strength;void main(){float r=length(gl_PointCoord-.5);if(r>.5)discard;gl_FragColor=vec4(.88,.88,.82,strength*(1.-smoothstep(.10,.5,r))*.8);}'});
  this.particles=new THREE.Points(this.particleGeometry,this.particleMaterial);this.particles.frustumCulled=false;this.swirl.add(this.particles);
  const ringPoints=Array.from({length:48},(_,i)=>new THREE.Vector3(Math.cos(i/48*Math.PI*2)*.075,.012,Math.sin(i/48*Math.PI*2)*.075));
  this.ring=new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(ringPoints),new THREE.LineBasicMaterial({color:0xcbd0c5,transparent:true,opacity:0,depthWrite:false}));this.swirl.add(this.ring);
  this.group.traverse(n=>n.userData.assetName='潮汐衛星・灰岩卡皮巴拉');
 }
 trigger(){this.time=Math.floor(this.time/STORM_PERIOD)*STORM_PERIOD+STORM_START;this.previewEnd=this.time+STORM_DURATION}
 get performanceActive(){return this.enabled!==false&&this.previewEnd!==undefined&&this.time<this.previewEnd}
 update(dt,enabled){
  this.enabled=enabled;if(enabled)this.time+=dt;
  const state=foreheadStormState(this.time),s=enabled?state.strength:0;
  this.group.visible=s>.001;this.group.scale.setScalar(.75+.25*s);this.swirl.rotation.y=-this.time*4.8;
  this.body.material.opacity=.16*s;this.funnel.material.opacity=.48*s;this.cloudMaterial.opacity=.28*s;this.ring.material.opacity=.65*s;
  this.particleMaterial.uniforms.strength.value=s;this.particleMaterial.uniforms.pixelScale.value=innerHeight*Math.min(devicePixelRatio,1.6);
  if(s>0){const p=this.particleGeometry.attributes.position;for(let i=0;i<p.count;i++){const u=(this.time*.29+i*.61803398875)%1,r=.025+.195*u**1.3,a=i*2.399963+u*Math.PI*5; p.setXYZ(i,Math.cos(a)*r,u*.55,Math.sin(a)*r)}p.needsUpdate=true}
  const text={calm:'額頭平靜 · 偶爾出現風暴',forming:'額頭沙塵聚集',tornado:'額頭龍捲風暴 · 旋轉中',fading:'風暴漸散 · 沙塵落定'}[state.stage];
  document.querySelector('#tidal-storm-state').textContent=text;
  document.body.dataset.satelliteWeather=JSON.stringify({enabled,time:this.time,...state,visible:this.group.visible,particles:this.group.visible?144:0,model:'artistic satellite dust weather'});
 }
}
