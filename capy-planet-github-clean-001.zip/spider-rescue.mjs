// A causal signal demonstration in an initially stationary, flat reference
// frame. The drawn planet is scenery: gravity and rotation are excluded here.
// beta is a stipulated wave speed of fictional silk, not a real material claim.
export const RESCUE_C=299792458;
export const RESCUE_RADIUS_M=6371000;
export const SPIDER_RESCUE_DURATION=56;
export const RESCUE_SEND_TIMES=[11,30];
const clamp=x=>Math.max(0,Math.min(1,x));
export const rescueEase=x=>{x=clamp(x);return x*x*(3-2*x)};
export function rescueModel(sceneLength,{radius=18,waveBeta=.2}={}){
 if(!(sceneLength>0&&radius>0&&waveBeta>0&&waveBeta<1))throw RangeError('Positive length and sublight wave speed required');
 const lengthM=sceneLength/radius*RESCUE_RADIUS_M,lightSeconds=lengthM/RESCUE_C,forceSeconds=lightSeconds/waveBeta;
 return {lengthM,waveBeta,lightSeconds,forceSeconds,secondsPerDisplay:lightSeconds/2};
}
export function rescueState(time,model){
 const t=Math.max(0,Math.min(SPIDER_RESCUE_DURATION,time)),trial=t<26?0:1,send=RESCUE_SEND_TIMES[trial],age=Math.max(0,t-send),emitted=t>=send,seconds=age*model.secondsPerDisplay,light=emitted?clamp(seconds/model.lightSeconds):0,force=emitted?clamp(seconds/model.forceSeconds):0,lightArrived=emitted&&seconds>=model.lightSeconds-1e-12,forceArrived=emitted&&seconds>=model.forceSeconds-1e-12;
 // First tug only tests the locked receiver. Its vibration begins locally
 // after the wave arrives and settles before the second, stationary trial.
 const probe=trial===0&&forceArrived?.045*Math.sin((t-21)*9)*(1-rescueEase((t-23)/2)):0;
 const reel=trial===1&&forceArrived?rescueEase((t-40.5)/4):0,release=rescueEase((t-46.8)/1),drop=clamp((t-44.5)/2)**2;
 const phase=t<4?'碼頭橋端 · 救援艙卡在林果山頂':t<9?'腳尖直線噴絲 · 連接林果山救援艙':t<11?'一足輕拉測試 · 光與拉力準備同時出發':t<13?'同時發出 · 金色光先向前':t<21?'光已到達 · 救援艙仍在等待拉力':t<26?'拉力終於到達 · 卡住的救援艙只震動，拉不開':t<30?'改用八足合力 · 兩端重新靜止':t<32?'八足合力 · 光與拉力再次同時出發':t<40?'光又先到 · 八足沒有讓拉力超光速':t<40.5?'拉力到達 · 蜘豬準備收絲':t<44.5?'快速拉回！':t<46.5?'放鬆蛛絲 · 救援艙落向碼頭前方海面':t<46.8?'噗通！救援艙已落水':t<47.8?'落水後收絲 · 救援艙浮起':t<53?'卡皮安全，蜘豬出糗':'光先到，力量後到 · 遠端救援完成';
 return {time:t,trial,legs:trial===0?1:8,send,emitted,seconds,light,force,lightArrived,forceArrived,probe,reel,release,drop,extension:rescueEase((t-5)/3)*(1-release),extraLeads:rescueEase((t-26)/3),phase,complete:t>=SPIDER_RESCUE_DURATION};
}
