import {clearPlanetSight} from './sensor-visibility.mjs?v=fb41883b52d5';
const dot=(a,b)=>a.reduce((sum,v,i)=>sum+v*b[i],0);
const unit=a=>{const length=Math.hypot(...a);if(!(length>0))throw RangeError('Valid surface direction required');return a.map(v=>v/length)};
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
export function subsatelliteAnchor(satelliteLocal,radius){if(!Number.isFinite(radius)||radius<=0)throw RangeError('Positive surface radius required');return unit(satelliteLocal).map(v=>v*radius)}
function viewBasis(normal,northAxis){
 const up=unit(normal),project=axis=>axis.map((v,i)=>v-dot(axis,up)*up[i]);let north=project(unit(northAxis));
 if(Math.hypot(...north)<1e-6)north=project(Math.abs(up[0])<.9?[1,0,0]:[0,1,0]);
 north=unit(north);return {up,north,east:unit(cross(north,up))};
}
export function surfaceLookDirection(normal,azimuth,elevation,northAxis=[0,0,1]){
 const {up,north,east}=viewBasis(normal,northAxis),a=azimuth*Math.PI/180,e=elevation*Math.PI/180;
 return north.map((v,i)=>(v*Math.cos(a)+east[i]*Math.sin(a))*Math.cos(e)+up[i]*Math.sin(e));
}
export function surfaceLookAngles(normal,direction,northAxis=[0,0,1]){
 const {up,north,east}=viewBasis(normal,northAxis),look=unit(direction);
 return {azimuth:Math.atan2(dot(look,east),dot(look,north))*180/Math.PI,elevation:Math.asin(Math.max(-1,Math.min(1,dot(look,up))))*180/Math.PI};
}
export function surfaceViewGeometry(observer,target,normal,radius=18){
 const length=Math.hypot(...normal),delta=target.map((v,i)=>v-observer[i]),distance=Math.hypot(...delta);if(!(length>0&&distance>0))throw RangeError('Distinct target and valid surface normal required');
 const n=normal.map(v=>v/length),direction=delta.map(v=>v/distance),vertical=direction.reduce((s,v,i)=>s+v*n[i],0),elevation=Math.asin(Math.max(-1,Math.min(1,vertical)))*180/Math.PI;
 const horizon=-Math.acos(Math.min(1,radius/Math.hypot(...observer))),horizonElevation=horizon*180/Math.PI;let lookDirection=direction;if(elevation<horizonElevation){lookDirection=direction.map((v,i)=>v-vertical*n[i]);const tangent=Math.hypot(...lookDirection);if(tangent<1e-8){const seed=Math.abs(n[2])<.9?[0,0,1]:[1,0,0];const dot=seed.reduce((s,v,i)=>s+v*n[i],0);lookDirection=seed.map((v,i)=>v-dot*n[i])}const scale=Math.hypot(...lookDirection);lookDirection=lookDirection.map(v=>v/scale)}
 return {distance,elevation,horizonElevation,direction,lookDirection,planetClear:clearPlanetSight(observer,target,radius)};
}
