const sub=(a,b)=>a.map((v,i)=>v-b[i]),dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
// Keep a zoom step on the near side, including a step that skips the entire body.
export function exteriorCamera(previous,desired,center,radius,sweep=true){
 const relative=sub(desired,center),distance=Math.hypot(...relative),from=previous?sub(previous,center):null;
 if(sweep&&from&&Math.hypot(...from)>=radius-1e-8){const delta=sub(desired,previous),a=dot(delta,delta),b=2*dot(from,delta),c=dot(from,from)-radius*radius,discriminant=b*b-4*a*c;
  if(a>1e-16&&b<0&&discriminant>=0){const t=(-b-Math.sqrt(discriminant))/(2*a);if(t>=-1e-9&&t<=1){const safe=Math.max(0,t-1e-5/Math.sqrt(a));return {position:previous.map((v,i)=>v+delta[i]*safe),blocked:true}}}
 }
 if(distance<radius){const direction=distance>1e-10?relative:from&&Math.hypot(...from)>1e-10?from:[0,0,1],length=Math.hypot(...direction);return {position:center.map((v,i)=>v+direction[i]/length*(radius+1e-5)),blocked:true}}
 return {position:desired,blocked:false};
}
