import * as THREE from 'three';
import {portalBodyState,portalExteriorPoint,throatSection} from './portal-transit.mjs?v=093e498326f7';
import {capeMotion,clothRipple} from './cape-motion.mjs?v=093e498326f7';
import {isHeroCloth} from './hero-style.js?v=093e498326f7';
import {poseWeaverArms} from './weaver-rig.js?v=093e498326f7';
const Y=new THREE.Vector3(0,1,0),Z=new THREE.Vector3(0,0,1),X=new THREE.Vector3(1,0,0);
function sigil(){
 const group=new THREE.Group(),material=new THREE.LineBasicMaterial({color:0x85d8bb,transparent:true,opacity:.8,toneMapped:false});
 for(let j=0;j<4;j++){const p=Array.from({length:24},(_,i)=>{const t=i/23;return new THREE.Vector3(-.24+t*.48,(j-1.5)*.09+.04*Math.sin(t*Math.PI*2+j),.05*Math.sin(t*Math.PI))});group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(p),material))}return group;
}
export class PortalMage{
 constructor({clone,id,world,throatScene,appearance={}}){
  this.appearance={cape:'#a7a2d2',collar:'#ede3ca',suit:'#345f59',...appearance};this.roles={};
  for(const [name,parent,scale] of [['entry',world,1.5],['exit',world,1.5],['inside',throatScene,.46]]){
   const carrier=new THREE.Group(),rig=new THREE.Group(),model=clone(id,scale).root,planes=name==='inside'?[new THREE.Plane(),new THREE.Plane()]:[new THREE.Plane()],cloth=[],wrists=[];model.position.y=-1.05*scale;rig.add(model);carrier.add(rig);parent.add(carrier);
   model.traverse(n=>{if(!n.isMesh)return;n.material=n.material.clone();n.material.clippingPlanes=planes;n.material.clipShadows=true;
    if(n.name.startsWith('flowing-red-cape')||n.name.startsWith('mage-raised-collar')){n.material.vertexColors=false;n.material.color.set(this.appearance[n.name.startsWith('flowing-red-cape')?'cape':'collar']);n.material.roughness=.72}
    if(n.name.startsWith('weaver-cloak'))n.material.roughness=.85;
    if(n.name.startsWith('torso')){n.material.vertexColors=false;n.material.color.set(this.appearance.suit)}
    if(n.name.startsWith('mage-astrolabe')||n.name.startsWith('original-seven-star')){n.material.emissive.setHex(0xc37c29);n.material.emissiveIntensity=.25}
    if(n.name.startsWith('mage-wrist-rune'))n.visible=false;
    if(isHeroCloth(n.name)){n.geometry=n.geometry.clone();n.geometry.computeBoundingBox();cloth.push({mesh:n,base:n.geometry.attributes.position.array.slice(),center:n.geometry.boundingBox.getCenter(new THREE.Vector3()),size:n.geometry.boundingBox.getSize(new THREE.Vector3())})}
   });
   for(const side of [-1,1]){const arm=model.getObjectByName('arm-'+side),wrist=new THREE.Mesh(new THREE.OctahedronGeometry(.11,0),new THREE.MeshBasicMaterial({color:0xb6e5d9,transparent:true,opacity:.8,toneMapped:false,clippingPlanes:planes}));wrist.name='bound-weaver-shuttle-'+side;wrist.scale.set(.45,1.35,.45);wrist.position.set(side*.13,-.43,.06);arm.add(wrist);wrists.push(wrist)}
   const spell=sigil();spell.position.set(0,-.53,.20);model.getObjectByName('arm--1').add(spell);spell.traverse(n=>{if(n.material){n.material=n.material.clone();n.material.clippingPlanes=planes}});
   this.roles[name]={name,carrier,rig,model,planes,cloth,spell,wrists,scale};
  }
 }
 pose(role,distance,wallTime,active,motion,casting){
  const {carpet,hands,overhead}=motion,phase=distance*5.5,step=active?Math.sin(phase)*(1-carpet)*(1-hands):0;
  role.model.traverse(n=>{
   if(n.name==='head-pivot')n.rotation.x=-.10-.16*overhead;
   if(n.name==='leg--1'){n.rotation.x=-step*.60;n.rotation.z=-.06}
   if(n.name==='leg-1'){n.rotation.x=step*.45;n.rotation.z=.06}
  });
  poseWeaverArms(role.model,motion,step,wallTime);
  role.rig.rotation.x=active?.05*(1-carpet):0;role.rig.rotation.z=carpet*.018*Math.sin(wallTime*1.8);role.rig.position.y=carpet*.018*Math.sin(wallTime*2.3)+hands*.035;role.spell.rotation.z=.08*Math.sin(wallTime*2);role.spell.visible=casting;for(const wrist of role.wrists)wrist.visible=casting;
  let waveMin=Infinity,waveMax=-Infinity;
  for(const {mesh,base,center,size} of role.cloth){const p=mesh.geometry.attributes.position,m=role.name==='inside'?capeMotion(motion.progress,center.toArray()):capeMotion(0,center.toArray());
   for(let i=0;i<p.count;i++){const x=base[i*3],y=base[i*3+1],z=base[i*3+2],u=(x-center.x)/Math.max(.01,size.x/2),v=(y-center.y)/Math.max(.01,size.y/2),t=THREE.MathUtils.clamp((1.42-y)/1.02,0,1),r=clothRipple(u,v,wallTime,carpet,m.fold),wind=(1-carpet)*t;
    p.setXYZ(i,x+r.x+.04*wind*Math.sin(wallTime*4+t*5),y+r.y,center.z+(z-center.z)*(1-.92*carpet)+r.z+wind*(.09*Math.sin(wallTime*5+t*4+x*3)-.07));waveMin=Math.min(waveMin,r.height);waveMax=Math.max(waveMax,r.height)
   }p.needsUpdate=true;mesh.geometry.computeVertexNormals();
   mesh.rotation.set(m.rotation,0,m.twist);mesh.scale.fromArray(m.scale);mesh.position.fromArray(m.center).sub(center.clone().multiply(mesh.scale).applyQuaternion(mesh.quaternion));
  }
  role.waveRange=(waveMax-waveMin)*role.scale;role.motion=motion;
 }
 update({config,state,layout,gates,wallTime}){
  const body=portalBodyState(config,state),d=state.wormhole.distance;
  const entry=this.roles.entry,exit=this.roles.exit,inside=this.roles.inside;
  const forward=new THREE.Vector3(...layout.forward),right=new THREE.Vector3().crossVectors(Y,forward),q=new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(right,Y,forward));
  entry.carrier.position.fromArray(portalExteriorPoint(layout,'entry',body.entryOffset));entry.carrier.quaternion.copy(q);entry.carrier.visible=body.entryVisible||!config.gateOpen;
  exit.carrier.position.fromArray(portalExteriorPoint(layout,'exit',body.exitOffset));exit.carrier.quaternion.copy(q);exit.carrier.visible=body.exitVisible;
  for(const [role,gate] of [[entry,gates[0]],[exit,gates[1]]]){const facing=Z.clone().applyQuaternion(gate.group.quaternion).negate();role.planes[0].setFromNormalAndCoplanarPoint(facing,gate.group.position)}
  if(!config.gateOpen)entry.planes[0].constant=1e5;
  const l=-config.throat/2+body.entryOffset,p=new THREE.Vector3(...throatSection(l).center).multiplyScalar(2.4);
  inside.carrier.position.copy(p);inside.carrier.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(Z.clone().negate(),Y,X));inside.carrier.visible=body.insideVisible;
  inside.planes[0].setFromNormalAndCoplanarPoint(X,new THREE.Vector3(-config.throat/2*2.4,0,0));inside.planes[1].setFromNormalAndCoplanarPoint(X.clone().negate(),new THREE.Vector3(config.throat/2*2.4,0,0));
  const progress=state.wormhole.tunnelProgress,motion={...capeMotion(progress),progress},carpet=motion.carpet,active=config.gateOpen&&state.time>0&&!state.wormhole.arrived;
  for(const [name,role] of Object.entries(this.roles)){const m=name==='inside'?motion:{...capeMotion(0),progress:0},casting=active&&(name==='inside'?m.hands>.12:name==='entry'?body.entryOffset>-.9&&body.entryOffset<.6:body.exitOffset>-.6&&body.exitOffset<.9);this.pose(role,d,wallTime,active,m,casting)}
  this.body=body;this.active=state.wormhole.stage==='throat'?inside:body.exitOffset>=0?exit:entry;
  const entryAlignment=Y.clone().applyQuaternion(entry.carrier.quaternion).dot(Y.clone().applyQuaternion(gates[0].group.quaternion)),exitAlignment=Y.clone().applyQuaternion(exit.carrier.quaternion).dot(Y.clone().applyQuaternion(gates[1].group.quaternion));
  this.telemetry={...body,entryAlignment,exitAlignment,entryPlaneDistance:entry.planes[0].distanceToPoint(entry.carrier.position),exitPlaneDistance:exit.planes[0].distanceToPoint(exit.carrier.position),entryPosition:entry.carrier.position.toArray(),exitPosition:exit.carrier.position.toArray(),insidePosition:p.toArray(),insideAxisDistance:Math.hypot(p.y,p.z),insideRingRadius:throatSection(l).radius*2.4,carpetBlend:carpet,clothWaveRange:inside.waveRange,clothPhase:motion.stage,wristParents:inside.wrists.map(n=>n.parent.name),wristsVisible:inside.wrists.map(n=>n.visible),facing:forward.toArray(),travelMode:state.wormhole.stage!=='throat'?'披風步行':motion.stage,bodyAlignedWithGate:(!body.crossingEntry||entryAlignment>1-1e-8)&&(!body.crossingExit||exitAlignment>1-1e-8),clipping:true,appearance:this.appearance};
 }
 get cameraFrame(){const c=this.active.carrier;return {position:c.position.clone(),up:Y.clone().applyQuaternion(c.quaternion),forward:Z.clone().applyQuaternion(c.quaternion),right:X.clone().applyQuaternion(c.quaternion)}}
}
