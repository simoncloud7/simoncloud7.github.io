// Idealized special relativity and exterior static Schwarzschild clock examples.
export const C=299792458;
export const G=6.67430e-11,EARTH_MASS=5.9722e24,REFERENCE_RADIUS=6371000;
export function massExample(earthMasses){if(!Number.isFinite(earthMasses)||earthMasses<0)throw RangeError('Nonnegative mass required');const schwarzschildRadius=2*G*earthMasses*EARTH_MASS/(C*C),compactness=schwarzschildRadius/REFERENCE_RADIUS;return {schwarzschildRadius,compactness,rate:gravityRate(compactness)}}
export function lorentz(beta){if(!Number.isFinite(beta)||Math.abs(beta)>=1)throw RangeError('|v/c| must be below 1');return 1/Math.sqrt(1-beta*beta)}
export function twinTrip(beta,distanceLy=4){if(beta<=0||beta>=1||distanceLy<=0)throw RangeError('Positive sublight speed and one-way distance required');const earthYears=2*distanceLy/beta;return {earthYears,travelerYears:earthYears/lorentz(beta),contractedDistanceLy:distanceLy/lorentz(beta)}}
export function gravityRate(compactness){if(!Number.isFinite(compactness)||compactness<0||compactness>=1)throw RangeError('Require 0 <= rs/r < 1');return Math.sqrt(1-compactness)}
export function radialFrame(x,z,radius=18,mapScale=18){const lon=x/mapScale,lat=z/mapScale,cl=Math.cos(lat);return {normal:[Math.sin(lon)*cl,Math.cos(lon)*cl,Math.sin(lat)],east:[Math.cos(lon),-Math.sin(lon),0],south:[-Math.sin(lon)*Math.sin(lat),-Math.cos(lon)*Math.sin(lat),cl]}}
