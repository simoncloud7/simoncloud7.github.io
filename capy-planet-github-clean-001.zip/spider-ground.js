import * as THREE from 'three';

export function spiderFrame(up,forward){const f=forward.clone().projectOnPlane(up);if(f.lengthSq()<1e-8)f.set(0,0,1).projectOnPlane(up);f.normalize();return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3().crossVectors(up,f).normalize(),up,f))}

// Ground queries use terrain and roads, never an overhead roof or palm leaf.
// All cached points live in the rotating globe's own coordinate system.
export class SpiderGround{
 constructor({globe,surfaces=[],frameAt,radius=18.2}){Object.assign(this,{globe,surfaces,frameAt,radius});this.cache=new Map();this.supports=new WeakMap();this.ray=new THREE.Raycaster();this.point=new THREE.Vector3()}
 at(normal){
  const n=normal.clone().normalize(),key=n.toArray().map(v=>v.toFixed(6)).join(':');if(this.cache.has(key))return this.cache.get(key);
  let point=n.clone().multiplyScalar(this.radius),up=n.clone();this.globe.updateWorldMatrix(true,true);
  if(this.surfaces.length){const worldOrigin=this.globe.localToWorld(n.clone().multiplyScalar(48)),worldCenter=this.globe.getWorldPosition(new THREE.Vector3());this.ray.set(worldOrigin,worldCenter.sub(worldOrigin).normalize());const hit=this.ray.intersectObjects(this.surfaces,true)[0];if(hit){point=this.globe.worldToLocal(hit.point.clone());up=hit.face.normal.clone().transformDirection(hit.object.matrixWorld).transformDirection(this.globe.matrixWorld.clone().invert());if(up.dot(n)<0)up.negate()}}
  const ground={point,normal:up,radial:n,radius:point.length()};this.cache.set(key,ground);return ground;
 }
 atXZ(x,z){return this.at(this.frameAt(x,z).normal)}
 samples(root,feet=true){
  let result=this.supports.get(root);if(result)return result;result=[];root.traverse(n=>{if(n.isMesh&&(!feet||/^leg-(-?1)$/.test(n.name)))result.push(n)});if(!result.length)root.traverse(n=>{if(n.isMesh)result.push(n)});this.supports.set(root,result);return result;
 }
 clearance(root,ground,feet=true){
  root.updateWorldMatrix(true,true);const inverse=this.globe.matrixWorld.clone().invert();let lowest=Infinity;
  for(const mesh of this.samples(root,feet)){const matrix=inverse.clone().multiply(mesh.matrixWorld),p=mesh.geometry.attributes.position;for(let i=0;i<p.count;i++){this.point.fromBufferAttribute(p,i).applyMatrix4(matrix);lowest=Math.min(lowest,this.point.sub(ground.point).dot(ground.normal))}}
  return lowest;
 }
 place(root,ground,q,height=0,feet=true){
  this.globe.updateWorldMatrix(true,true);root.parent.updateWorldMatrix(true,false);const globeQ=this.globe.getWorldQuaternion(new THREE.Quaternion()),parentQ=root.parent.getWorldQuaternion(new THREE.Quaternion()),worldQ=globeQ.clone().multiply(q);root.quaternion.copy(parentQ.invert().multiply(worldQ));root.position.copy(root.parent.worldToLocal(this.globe.localToWorld(ground.point.clone())));
  const worldUp=ground.normal.clone().applyQuaternion(globeQ),localUp=worldUp.transformDirection(root.parent.matrixWorld.clone().invert()),offset=height-this.clearance(root,ground,feet);root.position.addScaledVector(localUp,offset);root.updateWorldMatrix(true,true);return this.clearance(root,ground,feet);
 }
}
