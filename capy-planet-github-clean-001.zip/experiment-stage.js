import * as THREE from 'three';
import {setGaitPose} from './hero-style.js?v=c38a92d35e93';

const smooth=x=>{const t=Math.max(0,Math.min(1,x));return t*t*(3-2*t)};
const rectOverlap=(a,b)=>a[0]<b[2]&&a[2]>b[0]&&a[1]<b[3]&&a[3]>b[1];
export class ExperimentStage{
 constructor({globe,walkers,people,occluders,mixers,config,getClips,clearPeople=false,reservedBounds,dataKey='experimentStage'}){
  Object.assign(this,{globe,walkers,people,occluders,mixers,config,getClips,clearPeople,dataKey});this.reservedBounds=reservedBounds||config.light_experiment_site.clear_bounds;this.active=false;this.releasing=false;this.age=0;this.faded=new Map();this.lastCheck=-Infinity;
  this.streetPoints=config.paths.flatMap(ps=>new THREE.CatmullRomCurve3(ps.map(([x,z])=>new THREE.Vector3(x,0,z))).getPoints(220).map(p=>[p.x,p.z]));
 }
 inside([x,z]){const poly=this.config.terrain.outline;let hit=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const [a,b]=poly[i],[c,d]=poly[j];if((b>z)!==(d>z)&&x<(c-a)*(z-b)/(d-b)+a)hit=!hit}return hit}
 clear(x,z,slots){const r=[x-.45,z-.45,x+.45,z+.45];return this.inside([x,z])&&!rectOverlap(r,this.reservedBounds)&&!this.streetPoints.some(([a,b])=>Math.abs(a-x)<1.15&&Math.abs(b-z)<1.15)&&!this.config.walkway_obstacles.some(o=>rectOverlap(r,o))&&!slots.some(p=>Math.hypot(p[0]-x,p[1]-z)<1.05)}
 begin(){
  this.active=true;this.releasing=false;this.age=0;this.records=[];const slots=[];
  for(const {root,p} of this.walkers){const n=root.position.clone().normalize(),x=Math.atan2(n.x,n.y)*18,z=Math.asin(n.z)*18;let slot=null;
   for(const radius of [1.4,1.8,2.3,2.8,3.5,4.5,5.5]){for(let j=0;j<24;j++){const a=j/24*Math.PI*2,p=[x+Math.cos(a)*radius,z+Math.sin(a)*radius];if(this.clear(...p,slots)){slot=p;break}}if(slot)break}
   const cleared=!!slot;if(!slot)slot=[x,z];slots.push(slot);const radius=root.position.length(),lon=slot[0]/18,lat=slot[1]/18,target=new THREE.Vector3(Math.sin(lon)*Math.cos(lat),Math.cos(lon)*Math.cos(lat),Math.sin(lat)).multiplyScalar(radius);
   const mixer=this.mixers.find(m=>m.getRoot()===root),clips=this.getClips?.(p.asset_id)||[];this.records.push({root,radius,cleared,originalPosition:root.position.clone(),idleClip:clips.find(c=>/idle|stand|rest/i.test(c.name)),walkClip:clips.find(c=>c.name===p.clip),settled:false,from:root.position.clone(),to:target,mixer,timeScale:mixer?.timeScale??1});
  }
  this.peopleRotations=this.people.map(root=>[root,root.quaternion.clone()]);
 }
 movePerson(root,eyes,points){
  if(this.records.some(r=>r.root===root))return;
  const n=root.position.clone().normalize(),x=Math.atan2(n.x,n.y)*18,z=Math.asin(n.z)*18,radius=root.position.length(),slots=this.records.map(r=>{const p=r.to.clone().normalize();return [Math.atan2(p.x,p.y)*18,Math.asin(p.z)*18]}),ray=new THREE.Ray();let target=null;
  for(const distance of [1.4,2,3,4,5.5,7,9]){for(let j=0;j<32;j++){const a=j/32*Math.PI*2,px=x+Math.cos(a)*distance,pz=z+Math.sin(a)*distance;if(!this.clear(px,pz,slots))continue;const lon=px/18,lat=pz/18,p=new THREE.Vector3(Math.sin(lon)*Math.cos(lat),Math.cos(lon)*Math.cos(lat),Math.sin(lat)).multiplyScalar(radius),world=this.globe.localToWorld(p.clone()),center=world.clone().addScaledVector(world.clone().normalize(),.9);let blocks=false;for(const eye of eyes)for(const point of points){const d=point.clone().sub(eye),length=d.length();ray.set(eye,d.normalize());if(center.distanceTo(eye)<length&&ray.distanceSqToPoint(center)<1.5**2)blocks=true}if(!blocks){target=p;break}}if(target)break}
  if(target)this.records.push({root,radius,cleared:true,fixed:true,started:this.age,originalPosition:root.position.clone(),originalQuaternion:root.quaternion.clone(),from:root.position.clone(),to:target,settled:false});
 }
 finishRelease(){if(!this.releasing)return;for(const r of this.records){if(r.originalPosition)r.root.position.copy(r.originalPosition);if(r.originalQuaternion)r.root.quaternion.copy(r.originalQuaternion)}this.releasing=false}
 face(root,target){const n=root.position.clone().normalize(),forward=target.clone().sub(root.position).addScaledVector(n,-target.clone().sub(root.position).dot(n));if(forward.lengthSq()<1e-6)return;forward.normalize();root.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3().crossVectors(n,forward).normalize(),n,forward))}
 stop(){if(!this.active)return;this.active=false;this.releasing=true;this.age=0;for(const r of this.records){r.from.copy(r.root.position);if(r.mixer){r.mixer.stopAllAction();if(r.walkClip)r.mixer.clipAction(r.walkClip).reset().play();r.mixer.timeScale=r.timeScale}}for(const [root,q] of this.peopleRotations)root.quaternion.copy(q);for(const [root,saved] of this.faded)this.restore(root,saved);this.faded.clear()}
 restore(root,saved){for(const [mesh,material,cast] of saved){const current=Array.isArray(mesh.material)?mesh.material:[mesh.material];for(const m of current)m.dispose();mesh.material=material;mesh.castShadow=cast}}
 fade(root){if(this.faded.has(root))return;const saved=[];root.traverse(n=>{if(!n.isMesh)return;saved.push([n,n.material,n.castShadow]);n.material=Array.isArray(n.material)?n.material.map(m=>m.clone()):n.material.clone();for(const m of Array.isArray(n.material)?n.material:[n.material]){m.transparent=true;m.opacity=.16;m.depthWrite=false}n.castShadow=false});this.faded.set(root,saved)}
 update(dt,{camera,targets=[],subjects=[],satellite,freezeAudience=false}={}){
  if(this.active){this.age+=dt;const f=smooth(this.age/3.4),target=targets[0]?.clone().applyQuaternion(this.globe.quaternion.clone().invert());
   for(const r of this.records){const progress=r.fixed?smooth((this.age-r.started)/2.5):f;r.root.position.copy(r.from).lerp(r.to,progress).normalize().multiplyScalar(r.radius);if(r.mixer){if(progress>=1&&!r.settled){r.mixer.stopAllAction();if(r.idleClip)r.mixer.clipAction(r.idleClip).reset().play();else r.mixer.setTime(0);r.settled=true}r.mixer.timeScale=progress<1||r.idleClip?r.timeScale:0}else setGaitPose(r.root,this.age*6,progress<1);if(target&&!freezeAudience)this.face(r.root,target)}
   if(target&&!freezeAudience)for(const root of this.people)this.face(root,target);
   if(camera&&performance.now()-this.lastCheck>150){this.lastCheck=performance.now();const blocked=new Set();this.globe.updateWorldMatrix(true,true);
    // Cover the whole performer, including feet and outstretched paws. Using
    // conservative object bounds also catches thin roofs and palm fronds when
    // their triangles miss the old single ray through the character's chest.
    const sightPoints=[...targets];for(const root of subjects){const box=new THREE.Box3().setFromObject(root);if(box.isEmpty())continue;for(const x of [0,.5,1])for(const y of [0,.5,1])for(const z of [0,.5,1])sightPoints.push(new THREE.Vector3(THREE.MathUtils.lerp(box.min.x,box.max.x,x),THREE.MathUtils.lerp(box.min.y,box.max.y,y),THREE.MathUtils.lerp(box.min.z,box.max.z,z)))}
    const bounds=this.occluders.filter(root=>root.visible).map(root=>[root,new THREE.Box3().setFromObject(root)]),ray=new THREE.Ray(),hit=new THREE.Vector3();
    if(this.clearPeople){const eyes=[camera.position],r=this.reservedBounds;for(const person of this.people){if(!person.visible||this.records.some(record=>record.root===person))continue;const n=person.position.clone().normalize(),x=Math.atan2(n.x,n.y)*18,z=Math.asin(n.z)*18,box=new THREE.Box3().setFromObject(person);let blocks=x>=r[0]&&x<=r[2]&&z>=r[1]&&z<=r[3];for(const eye of eyes)for(const p of sightPoints){const d=p.clone().sub(eye),length=d.length();ray.set(eye,d.normalize());if(ray.intersectBox(box,hit)&&hit.distanceTo(eye)<length-.1)blocks=true}if(blocks)this.movePerson(person,eyes,sightPoints)}}
    for(const [eye,source] of [[camera.position,null],...(satellite?[[satellite.getWorldPosition(new THREE.Vector3()),satellite]]:[])])for(const p of sightPoints){const d=p.clone().sub(eye),length=d.length();ray.set(eye,d.normalize());for(const [root,box] of bounds)if(root!==source&&!blocked.has(root)&&ray.intersectBox(box,hit)&&hit.distanceTo(eye)<length-.1)blocked.add(root)}
    for(const [root,saved] of this.faded)if(!blocked.has(root)){this.restore(root,saved);this.faded.delete(root)}for(const root of blocked)this.fade(root);
   }
  }else if(this.releasing){this.age+=dt;const f=smooth(this.age/3);for(const r of this.records){const target=r.fixed?r.originalPosition:r.root.position.clone();r.root.position.copy(r.from).lerp(target,f).normalize().multiplyScalar(r.radius);if(r.fixed&&f>=1)r.root.quaternion.copy(r.originalQuaternion)}if(f>=1)this.releasing=false}
  document.body.dataset[this.dataKey]=JSON.stringify({active:this.active,clearing:this.active&&this.age<3.4,spectators:this.records?.length||0,peopleMoved:this.records?.filter(r=>r.fixed).length||0,crowdCleared:this.records?.every(r=>r.cleared)??false,fadedObjects:this.faded.size,releasing:this.releasing});
 }
}
